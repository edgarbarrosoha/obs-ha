Edgar Barroso: Hola. David.

David Garza: ¿qué tal Edgar? ¿cómo estás muy.

Edgar Barroso: Bien, y tú.

David Garza: Bien, bien.

Edgar Barroso: Qué? Bueno, qué? Bueno.

David Garza: Si no, no, te diría que no te preocupes, me recomendó una reunión contigo entrevista con Edgar, etcétera. Pero ahorita que vi, dije, oye, no, no es para eso, dijo, no, sí.

Edgar Barroso: Sí.

David Garza: Oye, Yo creo que cerramos. Yo ya me voy, No, no. Pero porque voy abajo a ver la transición, así que cualquier cosa estoy en el Whatsapp Este, pues, bueno, pues yo creo que vamos a a comenzar este el.

David Garza: No creo, digo, en cuanto a tiempo ahorita Edgar. Nos Nos dices cuánto tiempo puede tomar esto, pero es más, no es yo creo que una media hora, 40 más. Son 30 min

David Garza: de lo que conversemos.

David Garza: La intención son 2 cosas particulares. Una, yo quisiera que la voz tuya

David Garza: sobre lo que te gustaría ver en el campus Monterrey

David Garza: se pierde porque te he escuchado. Nos has dado retroalimentación. Y pues si todo 1 notas, Pero, pues, bueno, la capacidad humana

David Garza: a veces, pues me puede rebasar ¿no? Entonces, y se vio que el apoyo de Edgar Barroso con su estatus de arquitectura de horizontes que que ya la ha estado llevando a cabo

David Garza: en varios foros y organizaciones, pues él me ofreció apoyarme para el plan Dos 1 030 del campus. Entonces, en junio del año pasado

David Garza: iniciamos el trabajo con el equipo directivo del campus Monterrey, en el Centro Eugenio Garza Sanz. Ahí estuvo César, el historiador nos platicó de la historia de don genio y del Tec y y oí escuchar al historiador muchas cosas que a veces no ves en lo que 1 lee.

David Garza: pero desde ahí nos acompañó un agente de inteligencia artificial que se llama Cynthia Hesinc, y con I A de de las letras finales que que Edgar y su equipo y su trabajo generó y ese agente, pues los los acompañó.

David Garza: Ordenó en una especie de artículo. Lo que dijo el historiador lo bien bonito ya se entrevistó a Juan Pablo.

David Garza: La Fe Tec ya ya participó también con Cynthia. El equipo directivo Hay un hizo edgar poeta tú explicas un poquito. Hay una burbujita que se que cintia que habla con nosotros

David Garza: entonces activó para tener una conversación. De hecho pláticas para practicar demasiado. ¿es tan amable cintia que no se saca ahí. Así que debemos ser todos.

Edgar Barroso: Sí.

David Garza: Entrevistando a cada directivo. Y este, como se llama, y pues está almacenando. Entonces esto, más que va a ser, no va a ser para hacer un vídeo, porque es para transformarse en algoritmo, ahorita ya lo explica mejor que yo. Y

David Garza: yo te platico. Un poquito. No sé si recuerdas el año pasado de esta entrevista, a lo mejor no lo recuerdas. Y te comenté que sería bueno que

David Garza: de Carlos Saldívar. Esto era también y espesor. También fue bueno. Juan Palo. Nos recomendó. Creo que vale la pena también incluir a José Antonio Fernández Este. Y entonces

David Garza: vamos después de ti, el día Ricardo. Tal vez, y José Antonio tiene tiene la disponibilidad. Estamos en eso memo Torre

David Garza: y Javier Guzmán.

David Garza: Porque si ves, son actores que tienen que ver con lo que pasa en Tec de Monterrey y el Monterrey, entonces queremos que ellos también nos ayuden a plasmar eso. Entonces, bueno, ese es un poco el contexto. Este simplemente que tu voz. No se nos diluya en tantas reuniones que podemos tener, y hemos tenido y podemos tener, pero Edgar Tesoro la palabra, y y me gustaría que, pues sí, él puede poner un contexto mejor de lo que va a

David Garza: pasar. Ahorita no ya.

Edgar Barroso: Sí, muchísimas, Pues muchísimas gracias, David, por darnos este tiempo. Sabemos que tu agenda está tremenda.

Edgar Barroso: pero sí la idea un poco y voy a aprovechar un poco la tu background de Computer Science. Lo que estamos haciendo. Básicamente, es un vector grandote de todas las voces que podamos considerar para justo construir esta visión hacia el 2 030 e incluso algunas de las cosas que hemos aprendido es poner las bases para el 2 000. 35 de una vez lo hicimos muy bonito en el sentido de que tienes iluminación.

Edgar Barroso: se está grabando, etcétera, porque creemos que también estos documentos son históricos.

Edgar Barroso: Es decir, imagínate que podamos regresar estos documentos en 20 en 30, en 40, en 50 años

Edgar Barroso: para saber por qué se tomaron las decisiones que se tomaron o hacia dónde quería. El cuál era el rumbo que tú querías, para el campus, para para el para para todo el grupo educativo y que se quede en una base de datos donde pueda ser accesada por por un agente de de inteligencia artificial que en esos años, ¿Quién sabe qué va a hacer algo que todavía no sabemos que va a existir. Por un lado, es un documento histórico muy lindo

Edgar Barroso: donde podemos ir documentando tus ideas. Y por otro lado, como decía María Adrián, pues son parte de un vector. Entonces la idea es que literalmente tus palabras se van a convertir en un vector dentro de un campo semántico. Y

Edgar Barroso: Y lo que vamos a hacer es que eso se ha tomado en cuenta a la hora de hacer, pues, la la consulta que estamos haciendo sobre el 2 030 hacia del campus del Tec de Monterrey. La idea es que estén las voces de las personas que, como tú están pensando en esto todo el tiempo. Además, tú has estado en diferentes lugares dentro de esta organización. Y creo que eso es súper valioso porque tienes una visión mucho más amplia, y hay muy

Edgar Barroso: pocas personas y no, no hay que estén pensando todo el tiempo en el futuro del Tec de Monterrey. En el caso sobre todo del campus. No

Edgar Barroso: me voy a enfocar en el campus, porque esa es la idea que tenemos con con María Adrián. Y de verdad, yo te diría que te relajaras que te que eso lo tomemos como si fuera una charla. Lo que queremos es entender tu tu la forma en la que tú expresas tus ideas, como decía María Adrián. Esto no lo vamos a para redes sociales. No lo vamos a publicar. Estos son documentos internos que son propiedad de María Adrián del Tec

Edgar Barroso: y que nada más nos sirven para ir alimentando este este sistema de inteligencia artificial que, pues hay 1 de los agentes de Cynthia. Pero detrás de eso hay toda una estructura muy interesante de información.

Edgar Barroso: Y lo que es para mí, muy importante es ver tu visión sistémica. Es decir.

Edgar Barroso: tú que ves todo esto. Tú que has hablado con tantas personas sobre el T, E. C, sobre el campus que has estado en el campus tantos años viendo cómo ha evolucionado. Es lo que queremos ver. Si podemos destilar en esta en esta entrevista.

Edgar Barroso: te te hace sentido.

David Garza: Sí, sí, sí, muy bien, sí buenísimo.

Edgar Barroso: Bueno, vamos a empezar. Vamos a empezar con algo muy, muy general que es más o menos. ¿cómo ves tú? Cuál es tu visión hacia 2 000. 30? Voy a empezar con algo muy general, y poco a poco voy a ir un poco más hacia el detalle

Edgar Barroso: cómo imaginas el campus Monterrey en 2 030.

David Garza: Mira el Sin duda planteamos que lo que queremos es ver la mejor universidad de América Latina y del mundo de habla hispana. Y eso te va a dar en la medida en que el campus Monterrey logre ser y logre realizar.

David Garza: Y en ese sentido. Parte de lo que veo es de oye, cómo ¿Cómo lo veo, diferente, ¿Qué aspectos son los que creo que debemos de estar moviendo la aguja en esos aspectos. Por un lado, precisamente para el 2 030 ya estamos inmersos en la era de la inteligencia artificial.

David Garza: Entonces, sin duda, como haber sido pioneros líderes en esa adaptación que tenemos como universidad como campus

David Garza: a esta era de la inteligencia artificial. Y no solo me refiero a los aspectos operativos, administrativos y de gestión. Esos son los más básicos.

Edgar Barroso: Mhm.

David Garza: Los elementos más coyunturales, más core con lo que es nuestra visión y con lo que es nuestro quehacer, que tiene que ver con la parte de educación y con la parte de de investigación y de incidencia

David Garza: en la parte de investigación. No me refiero a que seamos líderes en investigación, en la inteligencia artificial. Me refiero a que, efectivamente nos hayamos adaptado en nuestros propios procesos de investigación en cómo pudimos potenciar esto. Entonces, de alguna manera es

David Garza: esa adaptación hacia el mundo de ella y que tenemos como universidad. Cómo formamos.

David Garza: no solo en aspectos de competencia, sino en aspectos de modelos que debemos de tener para este entorno. Y esta nueva nueva era que vamos a tener incluso el cuestionamiento de decir oye, pues, dado que

David Garza: ahora en este mundo se van a necesitar este tipo de perfiles son perfiles que desarrollamos actual en la actualidad y si no, ¿qué tenemos que hacer para que eso se vea

David Garza: el otro gran elemento que veo tiene que ver sin duda con el tema de la investigación y la innovación asociada a la investigación.

Edgar Barroso: Mhm.

David Garza: Este aspecto de decir oye

David Garza: si Ca: Hoy en Campus Monterrey, tenemos la mayor concentración de investigadores. Sí, tenemos la mayor concentración de laboratorios, la mayor concentración de actividad y de recursos. Sí, pero

David Garza: ¿qué más tenemos que hacer para que efectivamente se note, se sienta y se vea ese impacto y esa incidencia de la de la investigación.

David Garza: En ese sentido, una de las cosas que yo creo que debe de estar pasando al final del día rumbo al 20 30. Ahora sí, ya hablando de temas muy transversales.

Edgar Barroso: Mejor talento que debemos de tener de nuestros profesores.

David Garza: Y de nuestros alumnos ahorita. ¿podría hacer algunos comentarios acerca de este tema de talento de profesores y alumnos que esto se va a dar en la medida que seamos también cada vez más selectivos en este tema.

David Garza: Ahorita. Puedo hacer comentarios también en temas de selectividad y de tamaño. Sí.

Edgar Barroso: Mhm.

David Garza: El otro aspecto también muy relevante que veo es el tema de nuestros, El la composición de nuestro Studenbody

David Garza: sí es opción que tenemos de estudiantes de profesional contra estudiantes de posgrado, particularmente los estudiantes de posgrado que contribuyen a la parte de investigación. Si decimos que queremos ser las mejores universidades del mundo. Si tu tomas las mejores 150 universidades del mundo.

David Garza: el Tec de Monterrey es el que tiene la proporción más baja por mucho de alumnos de posgrado. Y eso es con tantos todos nuestros alumnos de posgrado.

Edgar Barroso: En el.

David Garza: De investigación todavía, pues es menor entonces.

David Garza: Y no es que mágicamente pongan más alumnos, y ya eres, ya estás ahí no es un proceso, No viene al revés, ¿verdad? Pero el cómo lograr esa parte? Entonces sí veo que este tema de el cómo cambia ese perfil

David Garza: del campus Monterrey que no lo podemos hacer en todos los demás campus. Pero en este campus, definitivamente sí debemos de poder. Tenemos la capacidad para poder hacerlo y poder realizarlo.

David Garza: Obviamente, ahí también tuvimos una plática similar a esta con la parte de donde se vincula la parte de innovación, pues con nuestro distrito de de innovación, verdad que el pues hoy tenemos expedición fensa, vamos a abrir el Hall, pero.

Edgar Barroso: Mhm.

David Garza: Lo demás que queremos que ocurra. No me refiero a lo demás, solo por infraestructura física, sino al final del día esos aspectos del Brain Güere y del ecosistema que consideramos que se debe de estar de estar formando, y el otro elemento que veo también

David Garza: que debe de ser muy visible. Tiene que ver con

David Garza: el y quizás un efecto de este aspecto de la atracción de talento. Pero con ese ese aspecto internacional

David Garza: de Monterrey, es decir, el que logramos efectivamente atraer personas de distintas partes del mundo para que se vinculen a estudiar a

David Garza: o a ser parte de nuestra de nuestra facultad, en pues, mucha mayor proporción de lo que hoy de lo que hoy es y, de nuevo, no es de que agua no pon simplemente extranjeros y ya vamos a ser mejor, no es el hecho de que, dado que buscamos el mejor talento esté donde esté, pues resulta que esa esa búsqueda es global, esa atracción es global y logramos atraer personas, incluso aunque estén en otros diferentes lados lados del

David Garza: mundo, entonces esos aspectos de investigación, innovación, selectividad, mejor facultad, mejores alumnos. Internacionalización. Los veo muy relevantes

David Garza: para lograr estas transiciones hacia, pues una universidad

David Garza: si enfocada enfocada aún más en la de lo que hoy estamos en la investigación y sí aclarando investigación aplicada, ¿verdad?

Edgar Barroso: Sí.

David Garza: No, no perseguimos, porque claramente parte de lo que estamos convencidos es que tenemos que ser creativos en el modelo y en la manera y en la en el impacto que queremos tener. Y este otro aspecto de que

David Garza: fuimos el campus que logramos la Universidad de Reputación Internacional, Reputación nacional e internacional que más rápidamente pudimos adaptarnos evolucionar y transformarnos

David Garza: hacia para la era de la inteligencia artificial agregaría

David Garza: una oportunidad, Un elemento que creo que tenemos que potenciar más, que es la multidisciplinariedad

David Garza: a este campus tiene y que incluso es un diferenciador, quizá con otras universidades de otros.

Edgar Barroso: Mhm.

David Garza: Los lados

David Garza: sin perder de vista lo que ha sido nuestro distintivo: la ingeniería, pues ahora estamos impulsando de una manera importante las ciencias, en particularmente las ciencias de la salud, ¿verdad? La parte de los negocios. Entonces.

David Garza: como esos que han sido, pues, nuestras fortalezas, ¿Cómo podemos y debemos potenciarlas en el aspecto multidisciplinario. Esta convergencia de ingeniería con salud

David Garza: y, obviamente, tenemos la ventaja de que no sólo hoy no tenemos ingeniería, negocios y salud, sino que tenemos diferentes disciplinas, pero

David Garza: sí creo que tenemos que ser inteligentes en términos de decir en esa esa esa multidisciplinar, en esa interdisciplinar, interdisciplinaridad en donde la queremos cristalizar, cómo queremos potenciarla en qué tipo de iniciativas. ¿en qué tipo de proyectos

David Garza: es donde debemos dar? Porque, de nuevo, creo que es algo que nos que tiene el campus Monterrey, que nos lo han reconocido nacional e internacionalmente y que, pues, vimos con la pandemia. El caso de salud.

David Garza: cómo lo logramos potenciar y Por eso estamos teniendo una apuesta importante en el tema de salud, pero en la medida que podamos todavía potenciarlo más, nos va a ayudar.

Edgar Barroso: Oye. Me encanta. Me encanta lo que mencionas, porque es verdad. Siempre hay un potencial enorme, y eso ha salido mucho en las entrevistas tanto de de los este del de todas las personas que hemos estado entrevistando.

Edgar Barroso: Y creo que ahí hay un potencial gigantesco de mucho mayor conexión. Pero como dices, tú no se va a dar sola, sino hay que diseñarla.

Edgar Barroso: Y creo que esa parte de cuál es el rol del campus como como un entorno que puede empezar a articular mejor y por diseño, empezar a hacer una universidad mucho más integrada. Creo que está increíble ahora. Nos ayudaría mucho si nos ayudas a pensar cómo se ve eso en la práctica.

Edgar Barroso: cómo se da una universidad. Y voy a recordar un poco lo que mencionaste: cómo se ve una universidad que ya está utilizando inteligencia artificial, no nada más, como dices tú lo básico, sino está en la frontera de lo que se puede hacer y contribuyendo a cómo se puede usar inteligencia artificial aplicada para hacer investigación, para hacer gobernanza, para hacer estrategia y, por otro lado, ¿cómo hacemos que ese mismo ecosistema transitorio

Edgar Barroso: atraiga a las mejores mentes del mundo.

Edgar Barroso: Cuéntame un poquito cómo se ve eso en la práctica. En los estudiantes, los profesores.

David Garza: Mira el de, te voy a comentar

David Garza: en algunos a lo mejor puedo efectivamente, atender la pregunta concreta, en otros está mal retador y cómo voy a comentar al respecto. Por ejemplo, déjame decirte en este aspecto de decir oye cómo se ve la práctica el hecho de que logramos, estamos logrando atraer mejores alumnos, mejores profesores. El hecho de que estamos avanzando en investigación, innovación, el hecho de que en este tema tema internacional, por ejemplo.

David Garza: oye logramos tener alguna alianza alguna iniciativa con algún Partner internacional universidad que incluso

David Garza: ocasiona que esa universidad haga un coming ment

David Garza: de presencia física cercana aquí con nosotros, ¿verdad? O sea, imagínate el distrito de innovación. De repente, tenemos la presencia a ver, o si todos quisiéramos, a los de Maitismos, los Stanford, los caltecs, etcétera. Bueno, este

David Garza: ¿qué pasa si tenemos aquí la presencia de una de alguna universidad sí reconocida de Estados Unidos de Europa trabajando y con presencia, no no nada más colaborando con un investigador, sino con.

Edgar Barroso: Y con.

David Garza: De 5 o más años, ¿verdad? Trabajando porque está trabajando en una iniciativa o en un proyecto. Sí

David Garza: en el tema de la inteligencia artificial es donde está más retador, ahorita. Yo le decía tener una conversación con Juan Pablo, digo a ver, esto es algo que todos, pues estamos experimentando, piloteando.

Edgar Barroso: Y en realidad ese.

David Garza: Ese jonrón. Es difícil describirlo.

Edgar Barroso: Creo que cuando lo vea, voy a decir sí, ese es verdad. Aún hablando de esto, verdad.

David Garza: El, O sea, creo que lo que está muy, muy identificado. Lo que tengo más claro es los los qué cosas, ¿Para qué cosas tenemos que prepararnos, ¿verdad?

Edgar Barroso: Mhm.

David Garza: Cambiando el tema de la parte de las competencias que típicamente y tradicionalmente hemos formado en los estudiantes de eso, y esto siempre ha pasado en la historia de la humanidad, Sí, pero ahora está pasando a una velocidad sorprendente.

Edgar Barroso: Sí.

David Garza: Y las competencias que hemos dominado. Las universidades son las competencias duras.

David Garza: y esas competencias duras son las que ahora, con la inteligencia.

Edgar Barroso: Sí.

David Garza: Ya las está teniendo. Entonces.

David Garza: digo, el está, ese tema A está el tema. Entonces del bueno. Entonces, cuáles son esas esas definiciones, esas competencias, entonces es difícil el el poder visualizar

David Garza: a en concreto como esto, ¿verdad? Porque ya lo estuviéramos haciendo.

Edgar Barroso: Sí.

David Garza: Ya hubiera visto que algún equipo lo tuvo muy claro y nos convenció. Ya lo estaríamos implementando, pero pero sí el que podamos decir oye

David Garza: Ya estamos en el 20 30 y sin duda, los egresados del tecnológico de Monterrey son los que están están más preparados para todo lo que está sucediendo y están siendo incluso los que están teniendo liderazgo en esos cambios hacia adelante.

David Garza: Hablando en concreto del tema de de alumnos y de profesores. Déjame decirte comenzar con el tema de profesores, atención. Recientemente vi que que La Unam tiene el 20 por 100 de sus profesores con doctorado.

David Garza: Nosotros tenemos el 60 por 100. No sé quién Monterrey debe de andar por un poco más, un poco más alto de eso.

Edgar Barroso: Poco más, incluso.

David Garza: Entonces para mí es igual caray. O bien, si eso es un hace que tenemos.

David Garza: entonces, pero eso ya está ahí. ¿qué es lo que yo me gustaría ver? En concreto. Lo que sí veo es que sí, nos falta

David Garza: esos esos profesores con ese mindset.

David Garza: Y déjame ponerlo de esta manera en estos términos, tanto de un hambre, de ambición, de transformación

David Garza: de lo que es su su es su área que les apasiona.

Edgar Barroso: Su campo de estudio, no.

David Garza: Campo de estudio, de cómo eso

David Garza: puede tener un gran impacto. Y como ellos apasionan, por eso

David Garza: lo venden, te lo venden, nos lo venden no solo internamente.

Edgar Barroso: Si no lo venden externamente. Claro.

David Garza: Y son capaces de de emocionar y de

David Garza: y de incluso atraer recursos, entonces

David Garza: esa parte es la que me yo, pues ambiciono a verla, a que sea.

David Garza: a que sea el común, verdad en nuestros profesores. Si yo tengo una reunión, una comida, una sesión o si hay un invitado y tenemos alguna presentación, y nuestros profesores están platicando. Eso es lo que quisiera ver, verdad.

Edgar Barroso: Bueno.

David Garza: Si tenemos muy buenos profesores, muy comprometidos, etcétera.

David Garza: Pero creo que todavía no con esas habilidades, expertise perfil en esa parte.

David Garza: y en el tema de los de los alumnos

David Garza: ten a nivel nacional, pues si mal no recuerdo, Campus Monterrey está concentrando la mayor cantidad de alumnos sobresalientes, estos que les llamamos a los.

Edgar Barroso: Mhm.

David Garza: Pero aún tenemos un alto número que no son Applus. Entonces lo que sí me gustaría ver es oye no un cambio de que oye. Fíjate que hoy tenemos 32, y vamos a tener 34.

David Garza: Para mí, algo que sea transformacional

David Garza: tiene que verse un brinco 30 por 100. Me convence que es transformacional, entendiste, Va a cuestionar verdad que.

Edgar Barroso: Claro.

David Garza: Le movimos un 30 por 100 con respecto a donde estamos hoy al menos o un doble verdad.

Edgar Barroso: Sí.

David Garza: Que.

Edgar Barroso: Que se vea claro que sea transformacional, No, no que no sea un incremento marginal.

David Garza: Incremento marginal. Eso por un lado, y por otro lado, también que dices oye y ya se siente que todavía que hay más má, más alumnos internacionales. ¿verdad?

Edgar Barroso: Claro.

David Garza: Aquí, y se siente esa ese esa presencia de de de alumnos de posgrado en una mayor.

Edgar Barroso: Mhm.

David Garza: Que anima y que entusiasma a los alumnos de pregrado por esas cosas fumadas que están trabajando en su.

Edgar Barroso: Claro.

David Garza: Y que, y que ningún lado de México se está dando de Latinoamérica y que alumnos de los distintos campus del Tec de Monterrey, pues quisieran venir aquí por esto, porque hay.

Edgar Barroso: Mhm.

David Garza: Hay eso que se está dando entonces? Esa es la parte hablando de la parte de alumnos y de profesores de como de com, como ir evolucionando. Sí.

Edgar Barroso: Buenísimo.

David Garza: Y en la parte esa multidisciplinaria aquí, como que

David Garza: me gustaría ver como que algún y

David Garza: bueno, parte tanto multidisciplinaria como disciplinaria, porque ahorita. También voy a contar un tema.

David Garza: Creo que si tenemos que tener así un big boat

David Garza: initiative projects, verdad a ver que tenemos ya 1 con el proyecto origen

David Garza: de ciencias de la salud del de T E. C salud, que nos ha abierto puertas nos ha posicionado, etcétera, y que es algo que oye este. Esto no está en ningún otro lado. Tuvimos las capacidades, y es algo que es de interés que podemos poner en la mesa

David Garza: y que otros dicen: ¡Ah, caray, eso es valioso. Me interesa hacer algo contigo.

Edgar Barroso: Mhm.

David Garza: ¿cuál es eso que tenemos similar, por ejemplo, en el área de ingeniería.

Edgar Barroso: ¿verdad?

David Garza: Ha sido nuestro nuestro estandarte, ¿verdad? Como como institución, Entonces, por eso te digo, si toco más, la parte ahora ahorita, dice, disciplinar y oye. Y a lo mejor tiene que ver con algo que es el el core. Es ingeniería.

David Garza: pero tiene elementos de otras áreas. No lo sé, ¿verdad? Pero lo que sí estoy convencido en términos concretos es que necesitamos algo que podamos decir esto.

David Garza: No hay otro lugar donde se esté haciendo o se esté realizando, ya sea por el contexto país que tenemos, O sea, que

David Garza: fíjate que estamos viendo esto, porque aquí en México hay estas plantas especiales que.

Edgar Barroso: Sí.

David Garza: Sólo se dan aquí y, por lo tanto, lo estamos viendo aquí, etcétera. De alguna manera, este tema de que haga sentido que respondamos. Por qué el test está haciéndolo, por qué ha sido en México, y eso que está haciendo es de valor para otros.

Edgar Barroso: Claro.

David Garza: Era de mí.

David Garza: Entonces, yo creo que ese es el otro elemento que creo que también debiese de ser parte de lo que viéramos, verdad en el 20, 30.

Edgar Barroso: Sí que es estudiar también cuáles son las ventajas comparativas, no que tiene el tec perdón. María, anti interrumpido, discúlpame.

David Garza: Ahorita que le digo al jonrón David es que el jonrón no es hasta que no lo ves.

Edgar Barroso: Sí.

David Garza: Pero hasta que no lo ves, que es ese entonces voy atravesando lo que dices hasta que no lo vea, va a ser con.

Edgar Barroso: Sí oye, Pues David, muchísimas gracias. Mira la siguiente pregunta: Es un poquito ya ver la parte, A,

Edgar Barroso: pues de tensión, no que tensiones ves tú o qué cosas tendríamos que cambiar. O si tú ves alguna contradicción a esta visión que tú tienes que tenemos que corregir si tú dijeras algo que me gustaría cambiar de lo que hay ahora, ¿Qué sería para ti?

David Garza: Mira, yo creo que

David Garza: se me viene a la mente que tiene que ver mucho con cuestiones de mindsets. Voy a dar ejemplos de Mindset que creo que tenemos que evolucionar o cambiar. Un mind

David Garza: oye la investigación es una cosa y la educación, vamos por separado. El campus Monterrey tiene que ser, pues, ese ejemplo, donde efectivamente

David Garza: somos un campus que le estamos apostando y evolucionando en investigación en modelos diferentes de como otras universidades Top, lo han decidido hacer, que es investigación básica. Nosotros estamos en investigación aplicada.

David Garza: y eso lo vemos como algo que enriquece, que nos beneficia, que nos prestigia y que nos ayuda en la parte educativa y no nada más de red de

David Garza: retórica de mensajes, sino también en hechos concretos que podemos que podemos mencionar. Entonces yo diría este mainzet

David Garza: de que bueno es que son 2 cosas que tenemos que verlos y nos quitan recursos. En lugar de poder dedicar más recursos para tener más jóvenes que puedan estar atendiendo de manera adecuada a nuestros a nuestros estudiantes. Yo creo que ese ese mindset es 1 que tenemos que que evolucionar.

David Garza: Creo que hay otras. Hay un par de cosas que, si bien no puedo dar ahorita datos duros, pero tengo las la percepción, la sensibilidad y voy a tratar de hacer este año un esfuerzo para también tener interacciones para ver, pues, en donde estamos en esto, que voy a comentar.

David Garza: pero de repente tengo también la sensación de que, desde el punto de vista como como universidad, hemos

David Garza: perdido colegialidad.

Edgar Barroso: Mhm.

David Garza: En las discusiones en las conversaciones académicas

David Garza: que deben de estar ocurriendo a nivel de los departamentos académicos.

Edgar Barroso: Mhm.

David Garza: ¿a qué me refiero con esto?

David Garza: A que en este tipo de universidades, a las cuales aspiro yo que estemos

David Garza: en un departamento académico. Se está hablando de las temáticas educativas

David Garza: y de investigación que son relevantes.

David Garza: que hay que avanzar, y los retos que hay pedagógicos con las nuevas generaciones, con hacia donde está evolucionando el mundo, etcétera, pues esas conversaciones se se tienen en estas universidades a nivel de los departamentos y de las escuelas. En fin.

David Garza: tengo la sensación de que estamos en la activitis. Estamos en las en los departamentos es, oye, te toca esta clase de esta clase y apagando fuegos operativos.

Edgar Barroso: Mhm.

David Garza: Y te pregunto: ¿qué tantos departamentos tienen

David Garza: reuniones semanales o quincenales y que discuten en esas.

Edgar Barroso: Claro.

David Garza: Reuniones semanales o quincenales.

David Garza: y que separan si separamos lo que es administrativo, gestión. Y si vemos lo que tiene que ver con educación, investigación, futuro, etcétera, entonces creo que eso también

David Garza: es algo que debemos de evolucionar

David Garza: y otro otro de los temas también que creo que tenemos que que evolucionar.

David Garza: Creo que también ahora, ya hablando desde el punto de vista de gestión.

David Garza: a lo mejor también estamos en una situación. Estamos también a veces con un mindset de que.

David Garza: ah es que hay que hacer esto a pues automáticamente necesito, Lo puedo hacer si solo si tengo más recursos.

David Garza: sí,

David Garza: y el también presionarnos y cuestionarnos. Okay, se van a necesitar recursos. Cuántos de esos recursos. ¿puedo yo mismo poner en la mesa, porque veo que lo que quiero hacer

David Garza: es de más valor agregado que esto que hoy estoy haciendo. Y no porque lo que hoy estoy haciendo no sea de valor agregado, sino por lo que quiero apostar. Creo que es de mayor valor agregado. Ah, Bueno, yo creo que podría yo poner en la mesa

David Garza: estos recursos y todavía me faltan estos otros. Pues que si hay que ver de dónde.

Edgar Barroso: De dónde sale. No.

David Garza: De dónde sale? Sí.

David Garza: Entonces tengo muchos de los puntos. Los estoy viendo más principalmente desde Mindset. El otro diría yo, tiene que ver con este Mindset de los profesores que describía al inicio.

Edgar Barroso: Mhm.

David Garza: Que se sientan que se ven que se sientan suficientemente tanto empoderados como este como responsables de

David Garza: pues tengo que proyectar a la institución

David Garza: con lo que hago. Tengo que vender a la institución hacia afuera con otros, platicando de las grandes historias de de cómo estoy transformando con mi microuniverso de de lo que es mi área.

David Garza: Y por cierto, también, como quiero ser, soy muy ambicioso, y la la institución me apoya sólo con esto o voy a conseguir recursos de fuera.

Edgar Barroso: Claro.

David Garza: Amplificar y amplificar esto entonces, y

David Garza: creo que ahí, pues entonces, pues hay hay tensiones. Son todos esos son temas de tensión, ¿verdad? Porque oye, Pues es que bueno, pues ese ese profesor, pues ese perfil de profesor cuesta más caro, y hoy tenemos una escala que demanda mucha tensión en el salón de clases para los aspectos más básicos, ¿verdad?

Edgar Barroso: Mhm: Sí, claro.

David Garza: Ojo, ¿no? Por decir qué es aspectos más básicos.

Edgar Barroso: Quiere decir que no son relevantes, Claro.

David Garza: Este yo, algo que he dicho. Lo más sagrado que hay es cuando un profesor está frente a un alumno. Si

David Garza: entonces este no faltan clases, así es verdad. Entonces oye, se debe darle que que eso se dé, que tengamos un profesor frente a clase y que ese profesor pueda inspirar a los alumnos, pueda retarlos, etcétera, pues todo eso se tiene que dar. Pero

David Garza: y aquí es donde vienen. Esas hablando concreto de esas tensiones. Somos hoy un campus que tiene una alta proporción de profesores de cátedra.

David Garza: comparativamente con los profesores de planta.

Edgar Barroso: Mhm.

David Garza: Y mucho de lo que estamos diciendo

David Garza: se basa en que podamos tener perfiles más altos y quizá

David Garza: puede que más de los que tenemos para poder hacer realidad esto. Y la otra, la otra parte, sí de tensión

David Garza: que veo y que, y que creo que para movernos más rápido vamos a tener que tomarnos la píldora es

David Garza: el que creo que tratamos de ser muy democráticos.

David Garza: más que democráticos, pero creo que tratamos de ser muy equitativos

David Garza: en términos de que oigan. Tenemos que avanzar en investigación, y queremos hacer esto y hay estos recursos. Bueno, pues los distribuyo entre las.

Edgar Barroso: Sí, los.

David Garza: De manera equitativa, a lo mejor de manera equitativa. No quieres, no, no refiriéndome a igual. Todos te reciben lo mismo. Pero, ah, pues, de acuerdo a su tamaño, de acuerdo a esto.

David Garza: más que de manera estratégica y de decir

David Garza: es que aquí es donde vamos a necesitar hacer la gran apuesta.

David Garza: Entonces se da el efecto de lo que lo que yo le llamo es, pues, Sí, puedes decir avanzando.

David Garza: Voy a poner el ejemplo del contexto. Hablamos de nuestras escuelas, un enfoque, es decir, cómo todas nuestras escuelas

David Garza: van avanzando, pero van.

Edgar Barroso: Poco a poco.

David Garza: Poco a poco versus

David Garza: oye, es que voy a decidir que de aquí a los 5 años voy a hacer una apuesta sustancial en esto.

Edgar Barroso: No.

David Garza: Quiere decir que las demás se van a caer.

Edgar Barroso: No, no, no.

David Garza: Pero siempre decir que, de nuevo, hablando de transformación aquí, sí vi que algo pasó de aquí a acá

David Garza: las demás, pues a ver, deben de subir, todas, Deben de subir. No es mi expectativa que nadie baje.

Edgar Barroso: Claro.

David Garza: Bueno es que quiero que todas vayan de donde están avanzando más o menos la misma cantidad. Entonces yo creo que esa es una tensión que tenemos.

Edgar Barroso: Mhm.

David Garza: Y que tenemos que decidir. Oye

David Garza: Nos conviene decir oye de aquí a 5 años, va por aquí 5 años. Ahora va a ser, acá. Va a ser acá

David Garza: reiterando, sin descuidar de que no tengan progreso. Si entonces.

Edgar Barroso: No por.

David Garza: Puedes hacer banvisisteres o quieres que alguna de ellas haga un long yoump.

Edgar Barroso: A ver.

David Garza: Puedes decir pues sí los demás a avanzar? Sí.

Edgar Barroso: Claro, porque si no se diluyen los recursos y entonces vas avanzando gradualmente, que es lo que justo lo que habías mencionado que eso es quizá no lo que necesitamos para 2 030,

Edgar Barroso: pero quizás ver cuáles son las fortalezas que tenemos de ahí. Y a partir de esa fortaleza, tener esos primeros y dieses. Y además, hacer que eso jale a las demás escuelas o las demás unidades.

Edgar Barroso: Me parece buenísimo. Vamos a entrar a la segunda, el segundo bloque. Y aquí te voy a hacer 3 preguntas en una

Edgar Barroso: en esta visión que acabas de describir David.

Edgar Barroso: ¿Cómo llegamos ahí? ¿qué tiene que pasar y qué es no negociable.

David Garza: El a ver no negociable es el tema de talento, ¿verdad? En que oye. No. Fíjate que sí puedo hacer, pero no voy a mejorar en el talento que tengo que que hacer y que voy a tener.

Edgar Barroso: Es un.

David Garza: También ese el tema de, oye, bueno, sí, pero este fíjate que no vamos a avanzar en en en nuestra investigación que sea más reconocida

David Garza: internacionalmente, ¿verdad? Porque más bien vamos a enfocarnos a esto. O sea, yo creo que ahí es donde está el diferenciador de el campus Monterrey con la.

Edgar Barroso: Mhm.

David Garza: Los demás campos. Y esas cosas, pues se tienen. Se tienen que dar a

David Garza: decías que qué tiene que pasar? Yo creo que 1 de los aspectos.

David Garza: el el que tiene que ver con lo que están haciendo. Gracias por atender esta petición de que si tengamos una claridad, poder llegar a una claridad y decir: hoy estamos aquí, y así nos vemos

David Garza: ya dentro de 5 años. Entonces quede claro: en estos íbamos a mover la aguja considerablemente

David Garza: esto. Otro, a lo mejor va a ser la misma inercia que traemos y estamos, Ok, con eso. Pero estos

David Garza: sí vamos a tener ese cambio. Entonces, para mí también es clave esa claridad.

David Garza: Y luego el Otro aspecto que es clave para ejecutar la ejecución es.

David Garza: Quiénes son los Champions responsables de qué iniciativas al final del día, para que esto se haga realidad. Tiene que ver mucho con las personas. La van a estar liderando estas diferentes iniciativas.

David Garza: El tus 3 preguntas. Una. No sé si la segunda, cuál era de.

Edgar Barroso: La segunda es: ¿cómo llegamos ahí.

David Garza: Okay Okay, Sí, te Yo creo que lo tenemos que tener nosotros.

David Garza: El el poder primero en el equipo de liderazgo, estar convencidos

David Garza: del de esa, de ese engame que estamos viendo de corto plazo. Me gusta que lo veamos más hacia el 20, 35 y de entrada al 20 30. Estamos viendo este corte.

Edgar Barroso: Sí.

David Garza: Obviamente, también tenemos que

David Garza: seguir un proceso de convencer a nuestro, a a nuestro Consejo y se viene un tema importante que tiene que ver con porque esto va a ser bueno para

David Garza: todo el tecnológico de Monterrey y no sólo para el campus Monterrey, ¿verdad?

David Garza: El el el convencimiento y el a ver yo yo. Si yo sí veo que esto nos va a llevar

David Garza: a que cosas que hoy suceden y que hoy son transparentes, como una movilidad estudiantil y becas y perfiles de alumnos y de profesores

David Garza: va a ser diferente y, por lo tanto, cosas que hoy sí que podrías hacer de una movilidad, simplemente sí vete. Para acá no hay problema, vete para allá. Eso no necesariamente va a suceder, y eso duele.

Edgar Barroso: Qué te.

David Garza: Entonces el poder, efectivamente, estar convencidos

David Garza: de que de que vamos a tener que gestionar eso

David Garza: para poder llegar llegar allá, entonces también veo esos esos elementos. A ver. Sin duda se viene un tema de

David Garza: y cuánto cuesta esto, ¿verdad? Este, ¿Cuánto es esto y de dónde van a venir nuestros recursos.

Edgar Barroso: Entonces.

David Garza: Yo diría a ver, yo creo que siempre como Tec.

David Garza: esa ha sido como que la última que respondemos.

Edgar Barroso: Sí.

David Garza: Porque yo diría que parte de lo que nos ha caracterizado es ¿qué queremos?

David Garza: ¿cuál es la ambición que tenemos?

David Garza: Hay muchas preguntas. No vamos a poder responder todas.

Edgar Barroso: Mhm.

David Garza: Ahorita. No te respondí todas.

David Garza: pero con que tengamos la convicción de algunas y de una orientación de que más o menos va por aquí, pues ahora sí a

David Garza: como ha sido característico, darle echarle y comprometernos, y vamos a lograr algo muy bueno, Y esto ha sido por la historia Tech a lo largo de de décadas.

Edgar Barroso: Sí, sin duda, y creo que eso es lo que ha hecho que el textil Tec también. ¿no? Que primero ven la visión. Y luego ven cómo cómo hace que suceda.

David Garza: Sí.

Edgar Barroso: Una pregunta más.

David Garza: Pero sintetizaría también de una manera de esta parte de esta ambición, visión. Y yo la verdad.

David Garza: escucho muy consistentemente cuando, sobre todo cuando tengo interacciones con colegas extranjeros, etcétera, igual ese el Tech, La verdad, que es el secreto mejor guardado, ¿verdad? Sí,

David Garza: podemos dejar de escuchar eso. Y si eso lo escuchamos hoy con lo que ya somos. Pero como que sea, quizá lo mejor, mucho tiene que ver con el liderazgo educativo, lo innovadores, lo que andamos pensando, lo que andamos implementando, etcétera.

David Garza: Pero ¿cómo puede ser de que de aquí al 20 30, no sea de que no es que no no conocía el Tec. No sabía del Tec, sino que sea a

David Garza: que gente de fuera diga, saben que en el Tec está pasando esto esto. Y esto, y están haciendo este proyecto, que es muy único, muy particular. Etcétera, Pues yo la verdad, Pues sí aspiro a que cuando

David Garza: vaya, ahora voy trayendo a la voz, ¿verdad? Este que sea tú vienes del Tech donde están haciendo esto.

Edgar Barroso: Claro que ya sepan qué es lo que se está haciendo en el Tec. No.

David Garza: Sí.

Edgar Barroso: Buenísimo. Oye David, hay algunos proyectos específicos del plan. Dos 1 030 que me gustaría. No sé. María Adrián, si quieres mencionar algunos y y escuchar tu tu

Edgar Barroso: tu reacción sobre estos proyectos. ¿qué te gustaría ver específicamente? Un comentario muy breve por cada 1 o algo así sería muy útil para para para saber cómo qué cosas te emocionan a ti. David.

David Garza: Si recuerdas, la última conversión es que es transformador, dejamos lo que es el distrito de innovación, los posgrados presenciales y la selectividad.

David Garza: En la última conversación con Juan Pablo del del plan del campus nos pidió agregar el cuarto, que es facultad.

David Garza: Entonces hay 1 más que facultad. Creo que hace mucho sentido. Porque, pues, bueno, entre selectividad, de repente nos juntamos a los alumnos y perdemos un poco la parte de abajo. Tanto son esos 4 elementos distinto. Innovación, este lo que viene siendo posgrados presenciales que hay ahí, los profesionalizantes y los científicos.

David Garza: los procesantes en legales, por ejemplo, y los científicos en ingeniería. Y también está la selectividad. Este y también la parte, facultad un dato muy rápido que te doy el 20 30, ya está a la vuelta.

David Garza: O sea, ahorita. Tenemos que estar viendo al 2 030, porque no estar viviendo 31 Hoy también un dato importante de los pilotos. El primero de enero, la prepa cumbres

David Garza: llegó a su meta y tenía 50 y tantos 60 plus

David Garza: y ahorita. Tenemos 63 de Applus, y ya llegamos a la meta. Y si cambiamos un proceso de admisión, empezamos con los con los primeros y está funcionando. Hay que ver cómo termina en agosto, porque todavía falta mucho y y en en el en el bachilor de administración y finanzas

David Garza: van al 40, pero van arriba de lo que traemos, porque tenemos un ritmo más largo como el año pasado. Pero, bueno, esos sobre esos 4 elementos, esos 4 pilares, este alguna cosa en concreto. Aquí quisieras compartirles

David Garza: el a ver. No. Bueno, me encanta que hayan agregado. Facultad. Yo creo que de facultad ya les hice comentarios de más de lo que veo. La selectividad va muy relacionada con la parte de lo los alumnos que les decía, yo creo que ahí nada más. Lo que les diría es que toda el a veces, cuando platico con algunos alumnos de alto perfil, los alumnos de alto perfil sienten

David Garza: que el ellos generalizan y dicen, no es que los alumnos del Tec es muy fácil entrar al Tech. Y y muchos de los alumnos del tecno son tan buenos.

David Garza: Los al eso dicen los alumnos.

Edgar Barroso: Mhm.

David Garza: Claro.

David Garza: ¿verdad? Entonces, oye, ¿cómo podemos efectivamente convertirnos verdad en en que, pues ¡Ah, caray, no está tan fácil entrar al gato en Monterrey. Es verdad.

Edgar Barroso: Mhm.

David Garza: Al rato. Te hago un comentario del tema de escala, ¿verdad? Este

David Garza: del tema del instinto de innovación.

David Garza: el punto de emprendimiento a ver emprendimiento ha estado desde nuestro nacimiento. Es algo que nos reconocen

David Garza: y de nuevo, yo creo que ahora, en esta etapa y lo que se debe de distinguir campus Monterrey nos es no solo por la parte educativa que tenemos que seguirla mejorando, realizando y el espíritu emprendedor que tenemos que impregnar en nuestros estudiantes, sino por los casos concretos de este emprendimiento de base científica o tecnológica. Verdad

David Garza: que oye. Algunos se darán. Algunos no se darán, pero el proceso de estar ahí con esa obsesión y nos va a ayudar, como como institución en Mindset, en en atraer talento de nuevo en muchos muchos otros aspectos.

David Garza: Yo te diría también agregaría a quizá dentro de esos elementos. El tema internacional.

Edgar Barroso: Mhm.

David Garza: O sea, creo que también, o sea, lo escuchamos cuando la gente viene y dice, oye, pues veo aquí. No estoy en México, ¿verdad? Es el Quinto Pilar. El esa internacionalización, verdad del campus Monterrey. O sea que

David Garza: y de nuevo oye, no es tanto, la movilidad estudiantil es la atracción.

Edgar Barroso: Claro.

David Garza: Los ojos las iniciativas, los proyectos.

David Garza: el sin duda profesores. He visto que últimamente, en la parte de profesores internacionales que atraemos en las nuevas contrataciones. Cada vez hemos incrementado de una manera importante. Entonces ya se empieza empieza a ver ahí una cierta inercia. Entonces este elemento de decir oye si se siente un campus aún más internacional de lo que hoy

David Garza: de lo que oyes, verdad Okay.

Edgar Barroso: Sin duda, creo que eso ha sido consistente desde desde el inicio de la entrevista y también en lo que hemos recopilado información. Dos preguntas más muy breves.

Edgar Barroso: Si tuvieras que conectar todo lo que hemos hablado hoy

Edgar Barroso: en una sola idea, ¿cuál sería? David, Sí.

David Garza: Prestigio internacional ganado por el impacto de investigación traducida en innovación.

Edgar Barroso: Buenísimo clarísimo y ahora otra, que ya más bien, es para ver qué le dirías a una de 2 030 que, quién sabe cómo va a ser si un modelo de 2 030 de inteligencia artificial tuviera que aprender de esta conversación, ¿Qué te gustaría que fuera Lo que aprendí en esta idea y de esta conversión.

David Garza: Claro que el el tecnológico de Monterrey piensa en grande.

David Garza: Ok, te reta

David Garza: aún, Y a los contextos retadores que pudiera haber locales o globales. Nos gusta pensar en grande y hacer realidad

David Garza: el lo incluso proyectos e iniciativas complejas, entonces

David Garza: debemos ser así de ambiciosos. Siempre muy Bolt no dijiste la palabra Bold hace ratito, pues mira de mi lado, es todo. Me encantó. Muchísimas gracias. David, La verdad es que luego yo, como profesor del Tec, también me emociono mucho.

Edgar Barroso: Porque veo también que es una universidad muy especial.

Edgar Barroso: y creo que yo, al menos aquí en Suiza, cuando cuando se menciona. La verdad es que todo mundo conoce el Tec a lo mejor. Y además, hay una comunidad tremenda aquí de de de exatex que los que vienen a Suiza vienen a trabajos muy especializados, súper interesantes.

Edgar Barroso: Y nada me emociona mucho pertenecer a esta organización, y Muchísimas gracias. María Adrián y David, de mi parte es todo.

David Garza: Si no. Muchas gracias. Este punto muy rápido. Este

David Garza: digo, es mi percepción. No tengo fundamentos, pero creo que Edgar, como profesor, creo que es el que veo más avanzado en el uso de la en el Tec.

David Garza: tiene un startup Este y aunque es músico.

Edgar Barroso: Sí.

David Garza: Then, The Harvard.

David Garza: o sea, el programa y tiene un equipo de ingenieros. Este es importante alrededor. Entonces digo lo comento por por.

Edgar Barroso: qué amable! No sé si sabías madre mía, pero David

Edgar Barroso: me invitó cuando yo estaba estudiando, o sea, una a dar una charla justo de de colaboración transiplinaria. Así que, bueno, también tengo muy buenos recuerdos. David de yo estaba, sí, ya sé, hace un buen rato.

Edgar Barroso: Y creo que la verdad es que nosotros pasamos por el proceso de V C, T,

Edgar Barroso: y vamos muy bien. David, no sé si yo voy en febrero a México. Ojalá que tengamos unos minutitos, pero la verdad es que el startup va volando. Tenemos clientes en Europa, en Costa Rica, en Méjico.

Edgar Barroso: y va bastante bien. El Start Up. Y bueno, eso gracias por el comercial. No era la intención para nada, pero.

David Garza: Siempre iban a regresar. Tengo un 1 000 000 de pesos de regalidad y me decía con valor, ¿no? Pero es que tengo el dinero que los cobran con el técnico, pues es que nosotros lo buscamos, no tantos, porque estén, ellos tienen negocios muy grandes y los buscamos. Pero, bueno, va a redituar, y ojalá que haya muchas de esas. Finalmente, yo quiero comentarte David, que este

David Garza: yo, en lo personal y del equipo, hacemos que las cosas sucedan.

David Garza: Pero para no hacer cosas que no queremos que sucedan, el Steinside que nos diste ahorita, ayuda mucho a que si hagamos que las cosas sucedan, pero las que tú estás visualizando y en.

Edgar Barroso: Mhm.

David Garza: Entonces ahorita que hablaste también del Minds, el de los profesores.

David Garza: Yo soy un producto de ese mindset porque siempre que fui profesor. Voy más allá y aquí estoy con ese mismo Midd. Y ese mind lo vamos a desplegar en el campus Monterrey, y vamos a hacer que suceda. Eso es como 1 de los compromisos. Entonces, bueno, muchas gracias. Espero que

David Garza: sentido cómodo, ¿no? Muchas gracias. Este yo para cerrar también. Gracias. Edgar. Yo creo que también tenemos que tener más conversiones, porque precisamente en este tema de ella hay, pues, una de las cosas que estamos empujando es Oye, cuál va a ser nuestro jonrón. ¿cómo sería un Ai First University.

Edgar Barroso: Mhm.

David Garza: Es hoy. Así como tuvimos una iniciativa de hoy. Hay que evolucionar un modelo. Tech 21. No sabemos cómo se va a ver, pero hay que hacerlo.

David Garza: Yo siento que ahorita también. Ya vamos tarde y ya debiésemos de tener ese mismo mindset, pues hay que ser un modelo a first. ¿qué quiere decir o a I Ready, etcétera. Oye de nuevo, eso va a caer en la institución Tec de Monterrey en la en algunas otras de las instituciones del grupo. No lo sé.

David Garza: Lo que sí sé es que hay que estar avanzando muy rápido en esta en esta parte y manuel también, pues gracias. Este. Precisamente tenemos la el otro día, pues la

David Garza: cena de los 40 años de edad, y yo.

Edgar Barroso: Voy a.

David Garza: La ambición, la aspiración y los logros que hubo hace con esa visión, algo que inició hace 40 años y que.

Edgar Barroso: El le.

David Garza: Es esa parte de esa ambición. Y por eso quise cerrar. Con esto que te dije, oye pensar en grande, no se nos.

Edgar Barroso: Sí, Sí, Sí.

David Garza: El que piense en grande hoy? ¿no? Pero ¿cómo vamos a poder ser una universidad reconocida? No somos de Mait, no tenemos los recursos. Ya lo sé y ya sé lo que no tenemos.

Edgar Barroso: Claro, eso no.

David Garza: Ya.

Edgar Barroso: Lo que importa es a dónde queremos llegar. Luego vemos cómo le hacemos claro.

David Garza: Podrías venir rápidamente para cerrar lo que dijo David de hace 40 años con la Dg y división de grados e investigación. Ya tuvimos un jonrón en investigación y a nivel internacional.

Edgar Barroso: Qué maravilla!

David Garza: Y entonces ya lo hicimos.

David Garza: ¿por qué no hacerlo? Ahorita exactamente.

Edgar Barroso: Claro, no, sí.

David Garza: Oye, somos somos la casona. Ahora.

Edgar Barroso: Sí, claro, son la cazuelas.

David Garza: En Monterrey.

Edgar Barroso: Claro.

David Garza: Luego el campus Montreal, que fue el primer campus universitario. Entonces, de nuevo ahorita, ¿qué es eso? O sea, hemos sido líderes en sí, cosas que no se pueden, que no existían en México, en Latinoamérica, pues hemos dicho, pues sí, pero vamos a ver cómo lo hacemos, ¿verdad?

Edgar Barroso: Claro.

David Garza: Se hizo el Setec. Estás viendo la construcción. Ahora está Expedition Hope.

Edgar Barroso: El Hobbes. Claro, no es increíble lo que ha logrado. Se los digo como ciudadano. Como profesor de verdad, el Tec es una inspiración para todo el país, y creo que en un momento de

Edgar Barroso: geopolítico como el que estamos viviendo hoy con el vecino que tenemos y, tal, yo creo que es importantísima lo que vaya a hacer el Tec los próximos 10 años.

David Garza: Hablando de Suiza. Que decía, pues sí Digo, nos invitan a la voz porque pues sí conoce verdad.

Edgar Barroso: Claro.

David Garza: Lo que.

Edgar Barroso: Bien. David, no pasas a Zúrich.

David Garza: Fíjate que nada más aterrizó.

Edgar Barroso: Mhm.

David Garza: Aterrizo ahí rápido. Sí.

Edgar Barroso: Bueno será para la otra. Entonces.

David Garza: Ocasión ándale.

Edgar Barroso: Sí.

David Garza: Gracias. Gracias, David.

Edgar Barroso: Hacerlo bien, cuídense mucho. Muchas gracias.

David Garza: Gracias. Edgar. Nos estamos viendo.

Edgar Barroso: Hasta luego.

## Connections
- [[02-community-ncm]]
