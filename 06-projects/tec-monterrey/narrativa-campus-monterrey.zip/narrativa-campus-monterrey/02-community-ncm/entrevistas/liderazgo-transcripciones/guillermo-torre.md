
Horizons Architecture Systems: Hola, Guillermo. Buenos días.

Edgar Barroso - Mario Adrián Flores: Puedes venir aquí a donde supongo, es la entrevista esta. Porque para ver lo de los diferentes, ¿a qué horas tenemos que.

Edgar Barroso - Mario Adrián Flores: Le daremos de media hora.

Edgar Barroso - Mario Adrián Flores: Muchas gracias. Este.

Edgar Barroso - Mario Adrián Flores: Es que me.

Edgar Barroso - Mario Adrián Flores: De emergencia. Me sale un consentimiento. Todo esto el cuadro cuadruplicando cosas a la vez. No te pones este, y lo entendemos muy bien, pero la verdad, Muchas gracias.

Edgar Barroso - Mario Adrián Flores: Y sí, este va un poco el contexto.

Edgar Barroso - Mario Adrián Flores: Dentro de lo que tú vas a ver también cuando están cuando presentan el liderazgo, el plano.

Edgar Barroso - Mario Adrián Flores: Lo que estamos haciendo es que la voz de los líderes.

Edgar Barroso - Mario Adrián Flores: No se pierda esto que estamos haciendo del plan. Entonces.

Edgar Barroso - Mario Adrián Flores: Ya tuvimos una entrevista con Juan Pablo.

Edgar Barroso - Mario Adrián Flores: David Garza Ricardo, saldívar.

Edgar Barroso - Mario Adrián Flores: Ayer Javier Guzmán, ahora tú.

Edgar Barroso - Mario Adrián Flores: Y Toni Fernández.

Edgar Barroso - Mario Adrián Flores: No está apoyando Edgar Barroso que el esfuerzo de la Escuela de Ciencias Sociales del Gobierno.

Edgar Barroso - Mario Adrián Flores: Él tiene un estado con una plataforma que se llama arquitectura de horizontes.

Edgar Barroso - Mario Adrián Flores: Y es de las personas que mejor manejan la inteligencia artificial.

Edgar Barroso - Mario Adrián Flores: Entonces ésta esta grabación.

Edgar Barroso - Mario Adrián Flores: No es una grabación para hacer un video y sacarlo en redes.

Edgar Barroso - Mario Adrián Flores: O sea, siéntete con la tranquilidad que solo insumo.

Edgar Barroso - Mario Adrián Flores: Para el plan de manejo interno. Entonces más una charla que algo.

Edgar Barroso - Mario Adrián Flores: Que hay que se va a grabar. Esto se va a poner en un vector de inteligencia artificial, y de ahí se va a alimentar, pero entonces no es para redes. No es para el vídeo este, pero pero bueno, entonces y la conversación, este Edgar. No sé si pudieras presentarte rápidamente y irnos hacia la conversación.

Edgar Barroso - Mario Adrián Flores: Hay una media hora aproximadamente, entonces para para sacarle todo el provecho. Memo.

Horizons Architecture Systems: Sí.

Horizons Architecture Systems: Y.

Edgar Barroso - Mario Adrián Flores: Vengo con toda la tranquilidad, pero sí me interesa mucho mi auto, pues en particular.

Edgar Barroso - Mario Adrián Flores: Tú que eres la parte de ser la verdad, un líder y un referente en la parte de salud y más allá de salud.

Edgar Barroso - Mario Adrián Flores: Este. Yo te la encomienda de que Carlos Montreal, Carlos Usignia.

Edgar Barroso - Mario Adrián Flores: Está loca el pozo de la salud.

Edgar Barroso - Mario Adrián Flores: Pero también hay proyectos de salud. Desde sobre ingeniería que tú sabes, este hay cosas en el expedition.

Edgar Barroso - Mario Adrián Flores: Traemos el proyecto distinto de innovación.

Edgar Barroso - Mario Adrián Flores: Yo quisiera que de alguna manera haya conexión y en cuanto se ejercen proyectos.

Edgar Barroso - Mario Adrián Flores: Entonces me gustaría es que a lo mejor pudiéramos.

Edgar Barroso - Mario Adrián Flores: Conectar, excepto las iniciativas de salud.

Edgar Barroso - Mario Adrián Flores: Con una visión como la tuya, y que no traigamos ahí los las piezas un poquito sueltas. Eso un poquito de inquietud para ustedes. Yo asumo que Edgar ya tienen preguntas que me van encaminar. Sí.

Horizons Architecture Systems: Absolutamente Sí, completamente.

Edgar Barroso - Mario Adrián Flores: El es.

Horizons Architecture Systems: Muchas gracias, María Adrián.

Edgar Barroso - Mario Adrián Flores: Este allá de donde vive y viene regularmente. Es músico.

Edgar Barroso - Mario Adrián Flores: Doctorado en composición musical de Carroll.

Edgar Barroso - Mario Adrián Flores: Este, pero es el profesor más avanzado de la historia internacional. Tiene un equipo de ingenieros y es un caso muy padre. Este pero.

Edgar Barroso - Mario Adrián Flores: A la.

Horizons Architecture Systems: Ya no sé que tienes poquito tiempo, así que justo nada más decirte que esta conversión es más para tener vectores.

Horizons Architecture Systems: Lo que hacemos ahora es que tomamos esta información, la convertimos en vectores de un cuadro mucho más amplio donde están las ideas de Juan Pablo Murra, de David Garza, de Ricardo, zaldívar de María Adrián, de José Antonio Fernández y de liderazgo del Tec que nos ayudan a entender hacia donde podemos ir. Y justo donde hay esta proximidad vectorial en estos en esta visión hacia 2 030.

Horizons Architecture Systems: Para que no sea nada más retórica, sino sea científica, o sea, que podamos medir matemáticamente cuál es la distancia semántica que hay entre las opiniones dentro de los distintos liderazgos.

Horizons Architecture Systems: Por eso es súper importante. Pero al mismo tiempo queremos simplemente escuchar tu experiencia. Lo que tú has vivido, has conocido lo que Ricardo Housman le llama el conocimiento productivo que viven las personas.

Horizons Architecture Systems: Entonces, sin más me arranco.

Horizons Architecture Systems: La idea, como te dijo María Adrián, es entender cómo podríamos imaginar las iniciativas de salud y el campus Monterrey. ¿cuál va a ser esta relación hacia 2 030.

Edgar Barroso - Mario Adrián Flores: A ver. Yo creo que tenemos una oportunidad increíble en el Tech.

Edgar Barroso - Mario Adrián Flores: Porque somos. Probab: Bueno, sin lugar a dudas, la única universidad privada en México, que tiene una escuela de medicina.

Edgar Barroso - Mario Adrián Flores: Que tiene un campus de ciencias de la salud.

Edgar Barroso - Mario Adrián Flores: Que tiene aparte carreras en ingeniería que que confrontan y que buscan salidas en temas de salud.

Edgar Barroso - Mario Adrián Flores: Tenemos la oportunidad de de generar un modelo que sea único en la calidad de la atención.

Horizons Architecture Systems: Mhm.

Edgar Barroso - Mario Adrián Flores: Y en ese proceso, el ser el mejor modelo formativo en ciencias de la salud, no en medicina. Nada más.

Horizons Architecture Systems: Mhm.

Edgar Barroso - Mario Adrián Flores: Yo creo que podemos ir disecando qué significa cada una de esas oportunidades. Pero.

Edgar Barroso - Mario Adrián Flores: Creo que el eje central es la oportunidad de generar el mejor modelo formativo.

Edgar Barroso - Mario Adrián Flores: Partiendo de la premisa que la forma de llegar a eso es mucho más fácil.

Edgar Barroso - Mario Adrián Flores: Si garantizamos la calidad de la atención, porque, a fin de cuentas, eso es lo que queremos.

Edgar Barroso - Mario Adrián Flores: Ahora, ¿qué significa ahí que en ese proceso de garantizar la calidad del en los hospitales en donde somos proveedores de salud.

Edgar Barroso - Mario Adrián Flores: Tenemos estudiantes en diferentes niveles, de forma y en diferentes carreras que están.

Horizons Architecture Systems: Mhm.

Edgar Barroso - Mario Adrián Flores: Participando en atención, pero también en un modelo de aprendizaje.

Edgar Barroso - Mario Adrián Flores: Aparte como un elemento muy distintivo y particularmente para el campus a la hora para el campus Monterrey, integrando salud.

Edgar Barroso - Mario Adrián Flores: Hemos hecho un compromiso grande de no solo ser transmisores de conocimiento.

Edgar Barroso - Mario Adrián Flores: Sino generadores de nuevo conocimiento en investigación aplicada.

Edgar Barroso - Mario Adrián Flores: Y creo que esa es una variable extremadamente importante en todo este proceso.

Edgar Barroso - Mario Adrián Flores: Porque lo que vamos a lograr no solamente siendo.

Edgar Barroso - Mario Adrián Flores: Un gran.

Edgar Barroso - Mario Adrián Flores: Educador, vamos a no solamente a.

Horizons Architecture Systems: Mhm.

Edgar Barroso - Mario Adrián Flores: A participar de la capacidad de generar nuevo conocimiento, sino también, al mismo tiempo, instalar en los jóvenes y en los maestros en la facultad, esta oportunidad de ser copartícipes de un nuevo descubrimiento. Entonces yo creo que todos esos elementos realmente nos dan.

Edgar Barroso - Mario Adrián Flores: No solamente una oportunidad de generar el mejor modelo de calidad educativo de investigación en salud.

Edgar Barroso - Mario Adrián Flores: Pero realmente de proveer ese liderazgo al resto del país, porque.

Edgar Barroso - Mario Adrián Flores: Estamos en un momento muy crítico. Yo creo que.

Horizons Architecture Systems: Sí.

Edgar Barroso - Mario Adrián Flores: Cuando la gente nos ve.

Edgar Barroso - Mario Adrián Flores: Con esa capacidad de creatividad, de formación, de liderazgo, pues empujamos a los demás a ir avanzando. Creo que es otra de las grandes responsabilidades que tenemos en el Ted.

Edgar Barroso - Mario Adrián Flores: Si en el Tec decimos que nuestro propósito es mejorar la calidad de vida de las personas y las comunidades a través de la educación.

Edgar Barroso - Mario Adrián Flores: Cuando vemos el tema central de salud.

Edgar Barroso - Mario Adrián Flores: Yo siempre digo perfecto, con la educación y además.

Edgar Barroso - Mario Adrián Flores: En la salud, entonces yo creo que ese puede ser un buen.

Edgar Barroso - Mario Adrián Flores: Comentario introductorio.

Horizons Architecture Systems: Es buenísimo, porque, además, es congruente, además, con con las otras entrevistas donde nos han dicho que justo en este momento histórico, donde todo está tan incierto.

Horizons Architecture Systems: El Tec puede ser esta esta roca no que está ahí ahora como cómo se ve en la práctica.

Horizons Architecture Systems: La conexión entre estos elementos que acabas de mencionar entre la investigación, la formación de estudiantes, la atención a los pacientes con cómo te la imaginas, cómo se ve en la práctica ya en el día a día para que para que María Adrián pueda tener esa visión también.

Edgar Barroso - Mario Adrián Flores: La verdad es que esto es un continuo. Por ejemplo, te voy a dar un ejemplo muy concreto. Tenemos proyectos hoy combinando ingeniería.

Edgar Barroso - Mario Adrián Flores: Y alumnos de ingeniería y alumnos de medicina, profesores de otras escuelas para resolver un problema que es de salud.

Edgar Barroso - Mario Adrián Flores: Pero la capacidad de resolver problemas en salud no es.

Edgar Barroso - Mario Adrián Flores: De una área temática en medicina.

Edgar Barroso - Mario Adrián Flores: Si no es como conjugas diferentes áreas para resolver un problema.

Horizons Architecture Systems: Mhm.

Edgar Barroso - Mario Adrián Flores: Un tema en particular que estamos queriendo resolver es cuando la gente muy enferma.

Edgar Barroso - Mario Adrián Flores: Que decimos nosotros. Técnicamente, están en un estado de choque donde no hay suficiente sangre que lleva los tejidos, Sacamos una propuesta para protocolos entre ingeniería y medicina que nos propongan soluciones.

Edgar Barroso - Mario Adrián Flores: Tanto, para mejorar la la fluidez, el volumen sanguíneo de alguna forma con dispositivos o con estrategias.

Edgar Barroso - Mario Adrián Flores: Farmacológicas, pero también medir el efecto de estos entonces Vemos, por ejemplo, recibido 15 propuestas.

Horizons Architecture Systems: Ahh.

Edgar Barroso - Mario Adrián Flores: Ese ejemplo es un ejemplo muy claro que conjuga la habilidad de tener la oportunidad de diferentes.

Edgar Barroso - Mario Adrián Flores: Áreas temáticas que están enfocadas en la resolución de un problema. No solamente estos son protocolos que vayan a investigación, tenemos la.

Edgar Barroso - Mario Adrián Flores: Y la ilusión o la esperanza de que ahí nazca también emprendimiento, porque no tocamos ese tema.

Horizons Architecture Systems: Mhm.

Edgar Barroso - Mario Adrián Flores: En este momento. Pero otra de las áreas fundamentales. Cuando yo hablo de investigación e innovación aplicada.

Edgar Barroso - Mario Adrián Flores: Muy particularmente, significa crear nuevas soluciones que den la oportunidad de generar un valor en la sociedad a través de emprendimiento.

Horizons Architecture Systems: Claro.

Edgar Barroso - Mario Adrián Flores: Y tenemos ejemplos de eso en.

Edgar Barroso - Mario Adrián Flores: En proceso que no existirían.

Edgar Barroso - Mario Adrián Flores: Si no están viviendo en una comunidad que tiene el proceso de salud. La parte formativa, la multidisciplinarial en el campus, como lo vivimos.

Edgar Barroso - Mario Adrián Flores: Y particularmente ingeniería, medicina.

Edgar Barroso - Mario Adrián Flores: Pero también por política pública, ¿verdad? Tenemos.

Edgar Barroso - Mario Adrián Flores: Hemos extendido temas en una.

Edgar Barroso - Mario Adrián Flores: Tenemos un esfuerzo dentro del texto que se llama el texto network.

Horizons Architecture Systems: Mhm.

Edgar Barroso - Mario Adrián Flores: Que es una estrategia de afiliación de hospitales pequeños que no tienen educación, no tienen.

Edgar Barroso - Mario Adrián Flores: Investigación y nos den a nosotros como.

Edgar Barroso - Mario Adrián Flores: Como potenciales formadores de de sus pequeñas.

Horizons Architecture Systems: Claro.

Edgar Barroso - Mario Adrián Flores: Esfuerzos, pero eso nos está también permitiendo generar una política de transparencia en resultados.

Edgar Barroso - Mario Adrián Flores: De la práctica clínica, que es muy importante para mejorar continua.

Edgar Barroso - Mario Adrián Flores: Pero lo que queremos hacer es no decir a la gente, Oye, queremos transparencia, Queremos que la transparencia de resultados se convierta en una política pública para el país, entonces tenemos gente delegada trabajando en ese componente. Entonces.

Edgar Barroso - Mario Adrián Flores: La realidad es que practicamos ingeniería platicamos emprendimiento, practicamos de temas de política pública. Eso solamente puede existir.

Horizons Architecture Systems: Mhm.

Edgar Barroso - Mario Adrián Flores: En el contexto de tener todo agrupado en un campus.

Edgar Barroso - Mario Adrián Flores: Como lo que queremos hacia el futuro.

Edgar Barroso - Mario Adrián Flores: En en un tener un canto, su insignia en Monterrey, en donde.

Edgar Barroso - Mario Adrián Flores: Honestamente, yo creo que distinguirnos en los temas de salud no solamente.

Edgar Barroso - Mario Adrián Flores: Lo veo como una gran oportunidad, sino también, lo creo, prioritario para el país.

Edgar Barroso - Mario Adrián Flores: Porque no veo a nadie hoy en el entorno de él ni de educación ni de salud, ni de investigación, con la capacidad de hacer lo que nosotros hoy podemos hacer.

Horizons Architecture Systems: Sí, Sin duda, ahora déjame ir un poquito a la parte de las tensiones. No digamos esto que nos cuentas. Es una visión increíble. Además, me encanta esta parte de la interdisciplina del del lugar único que que se puede en donde se pueden hacer estas cosas. Pero hoy en día.

Horizons Architecture Systems: Qué tensiones o qué cosas te gustaría cambiar para lograr esta visión excelencia clínica, accesibilidad, investigación, Atención. ¿cómo le podemos, ¿Qué tensiones ves hoy que tendríamos que atender para que justo lleguemos ahí?

Edgar Barroso - Mario Adrián Flores: Bueno, no sé si te refieres a instituciones internas o externas. Yo creo que ten tensiones que no controlamos, que son externas desde Monterrey.

Horizons Architecture Systems: Y.

Edgar Barroso - Mario Adrián Flores: Yo creo que el ambiente político del país en donde hay una división entre.

Edgar Barroso - Mario Adrián Flores: Entre.

Edgar Barroso - Mario Adrián Flores: El sector público, el sector privado.

Edgar Barroso - Mario Adrián Flores: Entre instituciones como las nuestras y las públicas, pues genera a veces una dificultad operativa.

Horizons Architecture Systems: Mhm.

Edgar Barroso - Mario Adrián Flores: Yo creo que la política del país fuera un poco más abierta. Independientemente de quién nos pague los sueldos.

Edgar Barroso - Mario Adrián Flores: Yo creo que tendríamos una mejor oportunidad de desarrollo.

Edgar Barroso - Mario Adrián Flores: Yo voy a ser como una problemática, no como un problema que no puede solucionarse. De hecho, creo que el hay más de un ejemplo en el Tech de Monterrey que siempre buscamos crear.

Horizons Architecture Systems: Mhm.

Edgar Barroso - Mario Adrián Flores: Puentes y enlaces constructivos. Pero este tema importante.

Horizons Architecture Systems: Claro.

Horizons Architecture Systems: Mhm.

Edgar Barroso - Mario Adrián Flores: Que creo que si no existiera, pues sería mucho más fácil.

Edgar Barroso - Mario Adrián Flores: El otro tema externo también, pues, es la realidad económica del país.

Horizons Architecture Systems: Mhm.

Edgar Barroso - Mario Adrián Flores: Nosotros no tenemos fondeo gubernamental, aunque puede existir modelos en otros países, y ese a veces genera un problema.

Edgar Barroso - Mario Adrián Flores: En donde tenemos que balancear.

Edgar Barroso - Mario Adrián Flores: Dentro de nuestra institución debido a la problemática económica del país.

Edgar Barroso - Mario Adrián Flores: Pues, ¿dónde ponemos los recursos entonces.

Edgar Barroso - Mario Adrián Flores: La atención interna, yo te diría.

Edgar Barroso - Mario Adrián Flores: Generada por la economía del país.

Edgar Barroso - Mario Adrián Flores: Nos fuerza a hacer a tener que priorizar.

Edgar Barroso - Mario Adrián Flores: Y y tener que hacer decisiones que a veces nos exigen renuncias.

Edgar Barroso - Mario Adrián Flores: Yo. Cuando estas conversaciones salen, yo siempre digo que yo no soy el que renuncia. Yo soy el que siempre empuja y empuja.

Horizons Architecture Systems: Y.

Edgar Barroso - Mario Adrián Flores: Porque si renuncia no se va a quedar cortito.

Horizons Architecture Systems: Ya.

Edgar Barroso - Mario Adrián Flores: Yo digo, apunta a lo más alto. Y pues donde llegue es maravilloso. Yo batallo con un tema de renuncias, Pero la realidad es que, de facto por la problemática económica nos hace intuitivamente tener que priorizar y enfocarnos en algunas áreas y no enfocarnos en otras. Yo creo que las naciones más importantes.

Horizons Architecture Systems: Sí. De acuerdo.

Edgar Barroso - Mario Adrián Flores: Yo yo me gustaría agregar a lo mejor. No sé si llamar las tensiones, pero.

Edgar Barroso - Mario Adrián Flores: Son 2. Una.

Edgar Barroso - Mario Adrián Flores: Más alumnos por los menos alumnos, porque si no estás test, es una atención a ver Bien, bien. Bueno, creo que Mario va en el mismo tema económico.

Horizons Architecture Systems: Mhm.

Edgar Barroso - Mario Adrián Flores: Yo creo que nosotros, en el Tec, la verdad, La gente quiere venir al Tec. Entonces tú puedes ir por poner más alumnos y.

Edgar Barroso - Mario Adrián Flores: Y más alumnos de generar un impacto en la población. Yo creo que es algo bueno.

Edgar Barroso - Mario Adrián Flores: Pero también nos genera más economía y nos permite libertad.

Edgar Barroso - Mario Adrián Flores: Yo creo que si hablamos de generar un campo insignia.

Edgar Barroso - Mario Adrián Flores: Tenemos que tener menos alumnos y los mejores alumnos del país. Esa es mi opinión particular.

Horizons Architecture Systems: Mhm.

Edgar Barroso - Mario Adrián Flores: Porque creo que no hay instituciones como la nuestra. Y creo que lo que nos debe de distinguir es realmente generar los líderes. Cuando hablamos de cantidades, grandes.

Edgar Barroso - Mario Adrián Flores: Se complica. Y entonces te estás volviendo.

Edgar Barroso - Mario Adrián Flores: Una buena universidad que hace un rol.

Edgar Barroso - Mario Adrián Flores: Pero nosotros tenemos la oportunidad de hacerlo. En diferentes momentos tenemos otros campos. Tenemos el milenio cuando vemos el Tec de Monterrey como un grupo educativo, tenemos la oportunidad de generar un modelo que realmente se insigne.

Edgar Barroso - Mario Adrián Flores: Y eso requiere un compromiso mayor de nuestra para una decisión estratégica crítica. Yo quisiera menos.

Horizons Architecture Systems: Mhm.

Edgar Barroso - Mario Adrián Flores: Pero los mejores yo quisiera es que cualquiera que salga de aquí pueda hacer lo que yo haría.

Edgar Barroso - Mario Adrián Flores: O que puede ser como yo o muchos, como yo, quisieron, una carrera muy importante en el extranjero, no porque tiene que ser en el extranjero, pero.

Edgar Barroso - Mario Adrián Flores: La realidad es que cuando va alguien en el extranjero de nosotros y hace competidor internacional, levanta el nombre de México y del P E, C.

Edgar Barroso - Mario Adrián Flores: Y creo que eso es importante. Necesitamos más de eso.

Horizons Architecture Systems: Mhm.

Edgar Barroso - Mario Adrián Flores: Yo creo que en un campo de oficina como Stella de Monterrey quisiéramos tener.

Edgar Barroso - Mario Adrián Flores: Es de priori la prioridad más importante.

Edgar Barroso - Mario Adrián Flores: Realmente los mejores, pero no los mejores de la Comunidad, los mejores que tengan competitividad internacional, y creo que.

Horizons Architecture Systems: Mhm.

Edgar Barroso - Mario Adrián Flores: Nos falta algo para lograr eso. Y nos falta porque.

Edgar Barroso - Mario Adrián Flores: Atendemos a muchos. Se nos diluye un poquito esa fuerza. Yo creo que deberíamos de tenernos claro. Muy buen punto, 1 más. Y te dejo tocar.

Horizons Architecture Systems: Mhm.

Horizons Architecture Systems: Tranquilo. Madre.

Edgar Barroso - Mario Adrián Flores: Ayúdanos. Ayúdame o Ayúdanos.

Edgar Barroso - Mario Adrián Flores: A entender cuál va a ser la diferencia en salud entre si lo que se va a hacer en Ciudad de México.

Edgar Barroso - Mario Adrián Flores: Y lo que vamos a hacer, lo que estamos haciendo y lo que va a seguir pasando aquí en Monterrey. Este. Yo creo que escucho que la poesía está en salud, pero yo acá. Estoy en campos de la salud. Entonces yo no no alcanzo a distinguir. No, yo creo que hemos estratégicamente dividido algunas áreas que van a ser sinergia.

Edgar Barroso - Mario Adrián Flores: Cuando vemos el panorama global, no vamos a tener en Ciudad de México lo que tenemos hoy aquí. Vamos a tener. Tenemos un hospital que se distingue en nuestra Comunidad, como se.

Edgar Barroso - Mario Adrián Flores: Un hospital realmente con un perfil académico que ya nos está viendo. La gente como capaces de resolver, como los temas más complejos de salud, de nuestro ambiente.

Horizons Architecture Systems: Mhm.

Edgar Barroso - Mario Adrián Flores: Ven la oportunidad que existe aquí de tener un modelo que también genere educación, que la la Comunidad ya lo ve como un valor y ve como un valor en el proceso de atención de ellos. Eso no lo vamos a tener yo en México.

Edgar Barroso - Mario Adrián Flores: Vamos a tener alianzas. Vamos a tener un modelo en donde los jóvenes puedan. Pero vamos a utilizar este campus para que todos los que se entrenan en salud en el ten a nivel nacional puedan participar de esta experiencia.

Edgar Barroso - Mario Adrián Flores: Entonces, cuando hablamos de los temas de investigación.

Edgar Barroso - Mario Adrián Flores: México tiene una oportunidad única porque el campo Ciudad de México están enclavado en hospitales públicos de primer nivel en México.

Edgar Barroso - Mario Adrián Flores: Entonces lo que estamos queriendo lograr es generar.

Edgar Barroso - Mario Adrián Flores: Un modelo de laboratorio.

Edgar Barroso - Mario Adrián Flores: En donde podamos hacer ciencia aplicada.

Edgar Barroso - Mario Adrián Flores: Para generar un valor.

Edgar Barroso - Mario Adrián Flores: Del Tec de Monterrey hacia los Campos de Ciencias de la Salud, de los Institutos de Salud de México.

Edgar Barroso - Mario Adrián Flores: Y que haga sinergia con lo que hacemos en Monterrey.

Edgar Barroso - Mario Adrián Flores: Entonces nosotros vemos la investigación aplicada en México.

Edgar Barroso - Mario Adrián Flores: Como haciendo sinergia con la estrategia que tenemos en nuestra atención clínica en Monterrey.

Horizons Architecture Systems: Mhm.

Edgar Barroso - Mario Adrián Flores: Aparte, tenemos la oportunidad de colaborar muy importante para investigación aplicada con los Institutos de Salud de México.

Edgar Barroso - Mario Adrián Flores: Lo que hagamos en México es complementar lo que tenemos en Monterrey. No vamos a estar haciendo investigación que se Alistan a preguntar aquí. Va a que hay investigadores y en México también.

Edgar Barroso - Mario Adrián Flores: Que van a investigar en un lado y el otro.

Edgar Barroso - Mario Adrián Flores: El la las áreas estratégicas en Monterrey, la aplicación de.

Edgar Barroso - Mario Adrián Flores: Trasplantes que se llama Sinotransplantation, sino trasplantes.

Edgar Barroso - Mario Adrián Flores: Tenemos un programa específico.

Edgar Barroso - Mario Adrián Flores: Para explorar y hacer investigación en el trasplante.

Edgar Barroso - Mario Adrián Flores: De animales está hacia humanos. Toda esta es un área grande importante que va a tener un impacto público muy relevante en nuestro país, porque si logramos.

Edgar Barroso - Mario Adrián Flores: Democratizar el uso de órganos que estén disponibles todo el tiempo para resolver el problema de falla renal en el país vamos a tener una contribución enorme. Ese es un gran.

Edgar Barroso - Mario Adrián Flores: La otra era de de de muy importante que es un problema público, y en parte con el Instituto de obesidad que tenemos en Etel es el mejoramiento de la atención en pacientes con diabetes.

Edgar Barroso - Mario Adrián Flores: Tenemos. Vamos a tener una una gran experiencia en investigación clínica aplicada.

Edgar Barroso - Mario Adrián Flores: Pero también el desarrollo de terapias avanzadas para diabetes.

Edgar Barroso - Mario Adrián Flores: Utilizando terapia celular.

Edgar Barroso - Mario Adrián Flores: Un foco en particular es explotar.

Edgar Barroso - Mario Adrián Flores: El trasplante de Islote de páncreas.

Edgar Barroso - Mario Adrián Flores: En la cámara anterior del ojo como algo de gran innovación.

Edgar Barroso - Mario Adrián Flores: Con el potencial de no necesitaremos una supresión, que es un gran problema. No quiero andar en tecnicismos.

Horizons Architecture Systems: No estoy superinteresante.

Edgar Barroso - Mario Adrián Flores: Yo, como tema grande, diría.

Edgar Barroso - Mario Adrián Flores: El El otro gran detalle es investigación en áreas cardiometabólicas, con un proyecto muy particular de gran innovación.

Edgar Barroso - Mario Adrián Flores: Que resolvería la problemática de o que atenta responder a la problemática de diabetes en el país.

Edgar Barroso - Mario Adrián Flores: Luego, como tercer área importante.

Edgar Barroso - Mario Adrián Flores: Tenemos terapia celular para otras indicaciones.

Edgar Barroso - Mario Adrián Flores: Por ejemplo, enfermedades neurodegenerativas y cáncer.

Horizons Architecture Systems: Mhm.

Edgar Barroso - Mario Adrián Flores: Y tenemos 2 grupos muy importantes con una historia ya de tradición aquí en el Perú.

Edgar Barroso - Mario Adrián Flores: En donde el uso de células en diferentes composiciones y en diferentes zonas.

Edgar Barroso - Mario Adrián Flores: Nos ha permitido detener enfermedades neurodegenerativas.

Edgar Barroso - Mario Adrián Flores: Y ahora, con la contratación de un profesor que es facultad últimos del Ted.

Edgar Barroso - Mario Adrián Flores: Tenemos todo el desarrollo de terapia para el cáncer. Entonces, en Monterrey vamos a tener seno trasplante, senotrasplante para enfermedad renal. Un programa muy grande, cardiometabólico con un programa.

Edgar Barroso - Mario Adrián Flores: Insignia que va a ser el trasplante de islotes de páncreas y terapia celular para cáncer y para no degenerativas en México.

Edgar Barroso - Mario Adrián Flores: Estamos hablando de Air For Youth.

Edgar Barroso - Mario Adrián Flores: En donde vamos a explotar la data de origen.

Edgar Barroso - Mario Adrián Flores: Que es este programa que hicimos de más de 100 000 mexicanos con una base genómica estadística y bioclínica que nos ha generado un valor relacional extraordinario en el mundo, diría yo.

Horizons Architecture Systems: Mhm Mhm Mhm Mhm.

Edgar Barroso - Mario Adrián Flores: Pero ahí vamos a tener investigadores para minar la data, para resolver problemas puntuales.

Edgar Barroso - Mario Adrián Flores: Origen hoy es o fue. Ya terminamos.

Edgar Barroso - Mario Adrián Flores: El recolector de la información.

Edgar Barroso - Mario Adrián Flores: La información ya está disponible. Ya tenemos más de 80 000.

Edgar Barroso - Mario Adrián Flores: Personas completamente secuenciados.

Horizons Architecture Systems: Ahh.

Edgar Barroso - Mario Adrián Flores: Y la data tiene que ser ahora estudiada. Entonces ella ha informado.

Horizons Architecture Systems: Mhm.

Edgar Barroso - Mario Adrián Flores: Está centrado en Ciudad de México, y eso es un pilar fundamental. Y no es medicina, ¿verdad? Son ingenieros que son capaces de usar salud. Es un tema de salida.

Horizons Architecture Systems: No.

Edgar Barroso - Mario Adrián Flores: Tenemos un tema importante en ingeniería biofármacos donde la Escuela de Ingeniería Mixter, donde están trabajando en conjunto. Entonces, en México. Interesantemente, prácticamente todos los proyectos están en conjunción en ingeniería y salud.

Edgar Barroso - Mario Adrián Flores: Porque aparte, no lo hemos comentado.

Edgar Barroso - Mario Adrián Flores: Tanto Femi como en Mis Alonso. Yo los he forzado un poquito, pero he trabajado con ellos para generar en el futuro un programa único de ingeniería y medicina.

Edgar Barroso - Mario Adrián Flores: Que sería otro otro de los planes insignia que tenemos para Monterrey.

Edgar Barroso - Mario Adrián Flores: Porque la combinación de ingeniería se ha convertido hoy. Probablemente no quiero sonar egoísta en el sentido de que otras, pero es una de las tareas más importantes de innovación y emprendimiento en las universidades más renombradas en el mundo. Si tú vas a ser Haití, probablemente energías un tema, sostenibilidad, pero innovación en salud se convierte en el epicentro de innovación, emprendimiento y generación de recursos.

Horizons Architecture Systems: Mhm.

Edgar Barroso - Mario Adrián Flores: Pero no es medicina. No es Kenzi.

Horizons Architecture Systems: Claro.

Horizons Architecture Systems: Es Health.

Edgar Barroso - Mario Adrián Flores: Es ingeniería, es tecnología legal, y es de policy.

Edgar Barroso - Mario Adrián Flores: En mi T No tiene hospitales. Y la mayor parte de lo que haces es lotes. Sí, oye el galón de japonés más cerca. A lo mejor tú puedes ir cerrando. Ahorita con la siguiente.

Horizons Architecture Systems: Mhm.

Edgar Barroso - Mario Adrián Flores: Platicando con Javier Guzmán.

Edgar Barroso - Mario Adrián Flores: Él ve que podríamos acercarnos a una Airway Versuty.

Edgar Barroso - Mario Adrián Flores: Y con los análisis que se han hecho, pues parece que no estamos tan lejos por la densidad de investigadores que hay aquí en Monterrey, que es un porcentaje alto comparado con todo el país.

Edgar Barroso - Mario Adrián Flores: El equival.

Edgar Barroso - Mario Adrián Flores: También si se pasara en Monterrey fundando todo lo que hay aquí.

Edgar Barroso - Mario Adrián Flores: O sea, como la percepción de que pudiera ser que avance también de manera importante.

Edgar Barroso - Mario Adrián Flores: Tú ¿Cómo ves eso? Este Crees que son las aspiración o de pagos.

Edgar Barroso - Mario Adrián Flores: Como pies de plomo. No lo sé.

Edgar Barroso - Mario Adrián Flores: Yo creo que ese debe ser una inspiración.

Edgar Barroso - Mario Adrián Flores: Yo creo que nos falta avanzar en una cultura.

Edgar Barroso - Mario Adrián Flores: De investigación para poder estar en ese nivel de competitividad.

Edgar Barroso - Mario Adrián Flores: Obviamente tenemos gente buena.

Edgar Barroso - Mario Adrián Flores: Obviamente, hay gente que tiene potencial y queremos desarrollar.

Edgar Barroso - Mario Adrián Flores: Pero generar una cultura de investigación es que todos entendamos el valor de la investigación no solamente en la investigación, sino cómo es un motor importante para generar educación de primer nivel.

Horizons Architecture Systems: Mhm.

Edgar Barroso - Mario Adrián Flores: Y eso nos va a requerir tener inversiones. Hablamos de esas pensiones externas.

Edgar Barroso - Mario Adrián Flores: Yo creo que tenemos que invertir más estratégicamente.

Edgar Barroso - Mario Adrián Flores: En general, no números.

Edgar Barroso - Mario Adrián Flores: No decir, tengo 600 investigadores, pero tengo 50 que son de primer nivel.

Edgar Barroso - Mario Adrián Flores: Yo observo este ejemplo. Muchos, como sabes, tenemos una relación con Raibon en en el I T.

Edgar Barroso - Mario Adrián Flores: Reino. Tiene 30 34 vestidos viales.

Edgar Barroso - Mario Adrián Flores: Es 1. Es un instituto que tiene.

Horizons Architecture Systems: Mhm.

Edgar Barroso - Mario Adrián Flores: Un budget anual de más de un 1 000 000 000 000 de dólares en investigación.

Edgar Barroso - Mario Adrián Flores: Pero no tiene 600.

Edgar Barroso - Mario Adrián Flores: Ni te dice, tengo 600 entonces.

Edgar Barroso - Mario Adrián Flores: Tenemos que concentrar un esfuerzo en este nuevo campo. Se insignias 2 030 en tener investigadores de esa competitividad.

Edgar Barroso - Mario Adrián Flores: No, 500.

Horizons Architecture Systems: Mhm.

Edgar Barroso - Mario Adrián Flores: Consigue 50 de ese nivel. Aquí transformamos en de porque esos van a infectar a los profesores porque van a hacer que nuestro equipo directivo, todos estemos alineados en el rol en importancia. Yo creo que.

Edgar Barroso - Mario Adrián Flores: Eso nos falta, entonces podemos hablar de numeraria de papers de gente sin por los criterios que tenemos. Pero si queremos tener competitividad internacional, necesitamos tener gente aquí que se pueda parar en la.

Edgar Barroso - Mario Adrián Flores: En la Asociación Americana de Manufactura y sea el leading speaker que se pueda parar en el tema de ambiente, nos ha invitado a platicar con los directivos que se paren como el Pleno electric del mitin.

Edgar Barroso - Mario Adrián Flores: Eso no lo tenemos todavía.

Edgar Barroso - Mario Adrián Flores: Creo que hay potencial. Vamos encaminados. Pero me dices, quiero ser.

Edgar Barroso - Mario Adrián Flores: Like, a Stanford Lifemant.

Edgar Barroso - Mario Adrián Flores: Nos falta eso, porque no es nada más. La numeraria.

Horizons Architecture Systems: Mhm.

Horizons Architecture Systems: Claro.

Edgar Barroso - Mario Adrián Flores: Es calidad y la cultura no es lo mismo. Mira, no es lo mismo caminar en el pasillo y ver a alguien que esté haciendo research.

Horizons Architecture Systems: La cultura, la cultura.

Edgar Barroso - Mario Adrián Flores: Que esté en Boston y te platica, o sea, en ese futuro. Aquí nos falta.

Edgar Barroso - Mario Adrián Flores: Mira ahorita. Me tardé un poquito porque subí el elevador y se me pegó un muchacho que está aquí todavía en la escuela medicinal.

Edgar Barroso - Mario Adrián Flores: Y se me pega porque sabe que yo vine a Estados Unidos doctor oye que digo no se acercan con tanta. Pero este muchacho luego no vino. Es que quiero ir a Houston 3 meses. Voy a estar ahí.

Edgar Barroso - Mario Adrián Flores: Eso te hace porque me ven aquí caminando en el Pacífico. Eso necesitamos con 50 investigadores en el campus.

Edgar Barroso - Mario Adrián Flores: En Monterrey que se tomen el café que lo vean en una cafetería que se respire. Entonces está en Michigan. Pos No me gusta.

Edgar Barroso - Mario Adrián Flores: Yo quiero 50 en el campus.

Horizons Architecture Systems: Mhm.

Edgar Barroso - Mario Adrián Flores: Yo, el primer paper que hice en investigación.

Edgar Barroso - Mario Adrián Flores: No el primero, 1 muy importante.

Edgar Barroso - Mario Adrián Flores: Salió de una conversación.

Edgar Barroso - Mario Adrián Flores: En el en el café. Yo estuve en la Universidad de Chicago.

Edgar Barroso - Mario Adrián Flores: Cuando estuve haciendo mi doctorado, tenían una tradición.

Edgar Barroso - Mario Adrián Flores: Que la agarraron de Oxford.

Edgar Barroso - Mario Adrián Flores: Y a las 4. Todo el mundo iba a tomar café y galletas.

Edgar Barroso - Mario Adrián Flores: Una sala como esto. Una sala de conferencias era era como que el dogma se sentaba, tomaba un café.

Horizons Architecture Systems: Mira.

Horizons Architecture Systems: Mhm.

Edgar Barroso - Mario Adrián Flores: Entonces ahí platicamos con los otros investigadores, con los otros estudiantes. Y ahí me salió una idea que convertí en Mi primer paper importante es la inspiración, bueno. Pero si estás sentado y no ves eso.

Edgar Barroso - Mario Adrián Flores: Pues no todas las 3.

Horizons Architecture Systems: Claro.

Edgar Barroso - Mario Adrián Flores: Por eso yo he insistido mucho. Yo cada vez que hago factores de mi.

Edgar Barroso - Mario Adrián Flores: Franco que va a ser que no estén aquí de tiempo completo.

Edgar Barroso - Mario Adrián Flores: No a ver, no se ha generado un valor. No quiero minimizar eso.

Edgar Barroso - Mario Adrián Flores: Pero hasta ahí va a llegar, no para llevarnos a este nivel, y eso nos genera papers y.

Edgar Barroso - Mario Adrián Flores: No, no de perdón. Y y mira, yo termino, ahorita este.

Edgar Barroso - Mario Adrián Flores: Las 4 apuestas transformadas que vimos con David es atracción de profesores de alta calidad.

Edgar Barroso - Mario Adrián Flores: Esa identidad de la luz que tú comentaste, impulsar los posgrados presenciales doctorados y universidades presenciales. No los voy a tomar.

Edgar Barroso - Mario Adrián Flores: Y el distrito de innovación de Monterrey, en donde la investigación y negocio de la inteligencia van a ver.

Edgar Barroso - Mario Adrián Flores: Mi duda es.

Edgar Barroso - Mario Adrián Flores: ¿cómo podemos, como ves, tu conectar al campus de la salud.

Edgar Barroso - Mario Adrián Flores: Con el distrito de innovación Monterrey, que se está forjando al lado del campus Monterrey en que hacer pan. Yo lo que te di. Un ejemplo es este programa que hicimos de los propósitos para resolver problemáticas de shock. Ahí lo hicimos.

Edgar Barroso - Mario Adrián Flores: Juntamos ingeniería, juntamos los problemas de salud. Trajimos gente de fuera que nos ayudara a tener un por un momento de inspiración académica en el tema. Y la idea sí que esto no es como un emprendimiento y vaya a salir de ahí. Llegamos, por otro lado, generando este valor es que yo creo que me están presionando, porque ahí tengo otros, sí, pero pero eso ahí se va a dar.

Edgar Barroso - Mario Adrián Flores: No se va de aquí, se va de ahí.

Edgar Barroso - Mario Adrián Flores: Okay, la la interdisciplinaridad. Ahí está. Somos parte de una misma.

Horizons Architecture Systems: Mhm.

Edgar Barroso - Mario Adrián Flores: Eso es muy valioso, Pero yo creo que para que termines con la frase, no con esto ya te dejamos. Pero si quieres.

Horizons Architecture Systems: Sí. Sí. La última pregunta. Guillermo es.

Horizons Architecture Systems: Si un modelo de inteligencia artificial en 2 030.

Horizons Architecture Systems: Tuviera que aprender algo de esta conversación.

Horizons Architecture Systems: Qué cosas serían no negociables? ¿cuál sería el principio que querrías transmitirle sobre estas ideas.

Edgar Barroso - Mario Adrián Flores: Pues, yo creo que a aceptar el compromiso de que vamos a hacer.

Edgar Barroso - Mario Adrián Flores: La universidad o el campos más importante en México y América Latina.

Edgar Barroso - Mario Adrián Flores: Por la oportunidad de generar conocimiento que avanza la ciencia, que avanza la salud y avanza en la formación.

Edgar Barroso - Mario Adrián Flores: Y creo que eso debe de traducirse en grandes innovaciones.

Edgar Barroso - Mario Adrián Flores: Tecnológicas que generen emprendimiento de valores. Eventualmente.

Horizons Architecture Systems: Súper Listo, fantástico. Guillermo.

Edgar Barroso - Mario Adrián Flores: Es que está Javier Guzmán. Yo no sé quién, pero pero bueno.

01:00:09.000 --> 01:00:12.000
Edgar Barroso - Mario Adrián Flores: Este. Muchísimas gracias. Bueno, muchas gracias.

## Connections
- [[02-community-ncm]]
