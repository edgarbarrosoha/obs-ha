Edgar Barroso: Hola, Juan Pablo, ¿cómo estás.

Juan Pablo Murra: Bien, bien, tú.

Edgar Barroso: Bien, qué? Bueno, verte.

Juan Pablo Murra: Qué parte del mundo andás Esto es?

Edgar Barroso: Todavía en Suiza, Pero la próxima semana voy a Ciudad de México.

Juan Pablo Murra: Sí, claro.

Edgar Barroso: Ahí con Miguel.

Juan Pablo Murra: Qué padre tienes algo específico.

Edgar Barroso: Si fíjate que tenemos un grand que nos ganamos con Welcome, que es esta Fundación de Inglaterra sobre los sistemas globales de salud

Edgar Barroso: con la investigadora, abril, campos. Entonces, abril y yo vamos a estar trabajando en ese simposio.

Juan Pablo Murra: Yo padre.

Edgar Barroso: Sí va a estar bueno.

Juan Pablo Murra: Oye, me imagino, involucran ahí a la gente de texa salud y de la escuela de medicina. Y eso no.

Edgar Barroso: Yo me imagino que sí. Aunque es más de policy, ¿ Vienen vienen de toda América Latina

Edgar Barroso: y del Caribe, o sea, es un es un simposium regional.

Edgar Barroso: y la idea de Wellcome es tener información de Latinoamérica sobre cómo debería de ser la arquitectura global de salud. Tá: Bueno, el proyecto.

Juan Pablo Murra: Oye Diego, aunque sea de policia, pues luego los colegas están metidos de ahí de por nutrición, por psicología, por el Instituto de Obesidad tienen Sistemas de Policía también.

Edgar Barroso: Sí, ¿verdad? Bueno, abril es una de ellas. De hecho, en.

Juan Pablo Murra: Abril es una de ellas para luego perdón, para darte cuenta que andamos luego el mundo separado.

Edgar Barroso: Sí, es verdad. Es verdad.

Juan Pablo Murra: Avísenle, si no a quién no les interesa, pues, ya que no que no vayan.

Edgar Barroso: Si cuenta con ello. Yo le digo abril y les avisamos claro, muy bien, mira esa es un buen punto de partida. Esta conversación.

Juan Pablo Murra: No sé.

Edgar Barroso: Sí.

Juan Pablo Murra: Pues ya estamos aquí, este Aquí estoy con Juan Pablo. Si quieres, vamos a comenzar también expectativas de tiempo, digo que no se sea tan extenso, pero tampoco que nos quedemos cortos. No sé cómo andas con palo porque me bloquearon hasta las 11 hasta las 11, Entonces digo a lo mejor 30 min, cualquier cualquier duda me gusta las 11.

Edgar Barroso: Perfecto.

Juan Pablo Murra: Voy a mover tantito las lámparas para que les dé un poquito más de frente. Y también

Juan Pablo Murra: oye. Y Y bueno la también este. Sin cortar. Me comentaba Juan Pablo Edgar.

Edgar Barroso: Sí.

Juan Pablo Murra: Clarificar que esta grabación es para uso interno.

Edgar Barroso: Sí.

Juan Pablo Murra: Para uso público no va a ser para para generar mensajes.

Edgar Barroso: No, no, no para nada para nada.

Juan Pablo Murra: Este y y bueno, tiene que ver con la intención muy clara de de la consulta del del plan estratégico, 20, 30 del campus Monterrey y y a mí me gustaría que nos platicaras un poco el mecanismo que estamos siguiendo con el uso de arquitectura, horizontes y y el agente de allá, y no.

Edgar Barroso: Sí. Claro que sí.

Juan Pablo Murra: La parte visual debería ser menos importante. Sí, yo creo que la organización sí sí sí,

Juan Pablo Murra: o sea, es para nada más. Grabar el audio para usarlo no es que se vaya a usar para nada. Esa es la palabra que me preocupa. Por Eso sí. Bueno, no es la, no es la intención principal, pero de aquí se va. ¿qué haríamos con esto si quieres que.

Edgar Barroso: Sí.

Juan Pablo Murra: La palabra. Por favor.

Edgar Barroso: Sí, claro que sí. Juan Pablo entiendo muy bien la preocupación, es muy legítimo, pero mira, no es para uso interno completamente.

Edgar Barroso: Pero como tú sabes, ahora, con los sistemas de inteligencia artificial, el texto se ha vuelto mucho más importante que antes, porque el texto antes era como A. Bueno. Es lo que yo me acuerdo de la entrevista. Esto fue lo que dijo Juan Pablo y se tomaba literalmente.

Edgar Barroso: Pero lo que hacen ahora los sistemas de Yai es que pueden tomar la información de muchas personas platicándolos con lenguaje natural, y eso poderlo convertir en una función de un sistema, literalmente como si fuera código, haz de cuenta que lo que estamos haciendo es

Edgar Barroso: tú? Nos vas a platicar hoy de tu visión de este, de esta consulta que estamos haciendo y ese pedazo de código de texto lo vamos a subir a un sistema mucho más amplio.

Edgar Barroso: También es muy importante. Por eso las luces y por eso el video No es para que salga redes sociales, pero sí queremos cambiar la idea de que cuando alguien nos pregunta internamente oye. Pero ¿cómo llegaron esta decisión o como a quién se le ocurrió esta idea o cómo fue este proceso.

Edgar Barroso: podamos decir. Ah, mira, es que si es una consulta donde Juan Pablo nos dio una entrevista, Mario Adrián y un montón de actores. Y conforme todos fueron tenía estas ideas, pudimos hacer un sistema de Yai que podía hacer por proximidad semántica, una idea mucho más clara colectivamente

Edgar Barroso: y, por otro lado, queríamos vi que es turístico. Ricardo Haussman no recientemente.

Edgar Barroso: Uno de sus conceptos más importantes de complejidad económica es el conocimiento productivo

Edgar Barroso: que es ese conocimiento de las instituciones que está depositada en las personas. Ese no está en un manual, no está en ningún lado. No sí. Él pone El ejemplo de Mercedes dice: Oye, si queremos ser un coche Mercedes, pues no, no hay un manual de cómo hacer un coche Mercedes, sino es el equipo que hace coches el que logra hacerlo. No tú podrás hacer un manual. Pero a mí me hace un manual de cómo hacer un coche, no tendría ni idea.

Edgar Barroso: Y por otro lado, queremos extraer ese conocimiento productivo, porque sabemos que tú, literalmente, todos los días estás viendo el panorama general, estás platicando con personas de todo el mundo, estás pensando en cómo hacer al Tec de Monterrey, pues una gran institución. Entonces lo que te quisiera pedir ya entrando es

Edgar Barroso: que te sintieras como si estuviéramos platicando en un café tranquilamente y que dejes que tus ideas simplemente vayan fluyendo, es solo para documentar. Pero esta información, si la vamos a tomar en cuenta en el sistema y tu opinión.

Edgar Barroso: Tu conocimiento productivo es súper importante porque es la síntesis, la destilación de miles de conversaciones que has tenido con muchísimas personas interesantes.

Juan Pablo Murra: Buenísimo.

Edgar Barroso: Del late órale, pues mira, empieza muy sencillo. Voy a hacer una pregunta muy general y podemos ir viendo poco a poco. Son 3 preguntas generales y podemos ir profundizando en cada una de ellas.

Edgar Barroso: Pero como decía Marío Adrian, esto es la idea de es tener una consulta hacia este este proceso que estamos haciendo 2 030. Así que, de manera general, ¿cómo te imaginas al campus Monterrey en 2 030.

Juan Pablo Murra: Sí, yo. Gracias. Edgar

Juan Pablo Murra: es muy buena pregunta también. Por otro lado, quiero no quiero minimizar, pero también el 20 30. Está a la vuelta de la esquina.

Edgar Barroso: Sí es mañana.

Juan Pablo Murra: Entonces y en los en los los alumnos que van a estar aquí en el 20 30, pues ya los admitimos, ¿verdad? Entonces, si soy, si si soy una buena buena parte de los que van a estar aquí en el 20 30 ya están.

Juan Pablo Murra: entonces creo que tendríamos que estar pensando en el más que ¿cómo va a estar el campus en el 20 30? Ya en ese momento es que semillas. Vamos a som a sembrar de aquí al 20 30 para que el campo de Monterrey en el 20 30, este mejor, pero en el 20, 35 y 20 40, este, creo que tenemos que que tener una visión de

Juan Pablo Murra: de un poquito más de largo plazo. Yo sé que nuestros planes son este cada 5 años, y entonces queremos ver el impacto para el 20 30. Pero mire, por ejemplo, ahorita. Estamos viendo el plan financiero de los próximos 5 años.

Edgar Barroso: Mhm.

Juan Pablo Murra: Por ejemplo, decisiones ya tomadas como el plan. El plan de estudios de arquitectura va a pasar de 4 años a 5, pues eso no va a mover la matrícula total hasta el 20, 31.

Edgar Barroso: Mhm.

Juan Pablo Murra: Lo digo como contexto, porque a veces esperamos que que las cosas se muevan más rápido de lo que de lo que realmente se pueden mover en una institución educativa con los ciclos que tenemos hoy en el en el Tec, ¿no? Pero, bueno, Dicho eso.

Juan Pablo Murra: ¿qué me gustaría de ver en el campus Monterrey, en el 2 030?

Juan Pablo Murra: Para mí, las el tema principal en cualquier universidad es

Juan Pablo Murra: el calibre del talento que atrae.

Juan Pablo Murra: Y Y si me me me dices el segundo, yo creo que son un tema de de la cultura que se vive en la en la universidad.

Juan Pablo Murra: Entonces del calibre del talento, pues es: estamos atrayendo cada vez a mejores estudiantes que tengan no solo las capacidades académicas.

Juan Pablo Murra: sino la disposición y la voluntad de convertirse en agentes de cambio de convertirse en estos líderes con espíritu emprendedor que crean valor en la en la comunidad, hacerlo desde su disciplina. No. Este habrá unos que serán médicos, otros abogados, otros emprendedores, otros van a participar en actividades de investigación.

Juan Pablo Murra: pero cualesquiera que sea su disciplina o su manera de tener impacto que sean de altos estándares de clase mundial y con la capacidad de crear valor en la sociedad.

Juan Pablo Murra: Y

Juan Pablo Murra: yo tengo, digo, esto, son estas cosas que hay que decir con cuidado, no en una clase que llevé yo en la en la en la maestría, hizo. Era de decision modos de modelos de promociones

Juan Pablo Murra: y la mejor variable para predecir el sueldo de un egresado de M. B. Y en Estados Unidos no era la universidad la que fue. Era su G. I M A, T.

Edgar Barroso: Mira.

Juan Pablo Murra: Entonces las mejores universidades atraen a los mejores alumnos, después nos los descomponen. Y ahí, pero yo sí creo, honestamente que parte del futuro del té y de la capacidad de incidir

Juan Pablo Murra: que vamos a tener es asegurarnos que traemos a los mejores estudiantes.

Juan Pablo Murra: Y eso pasa por tener una buena. O sea, obviamente, para hacer eso, pues tienes que tener buenos profesores, buenas instalaciones, buenos programas de estudio, buenas oportunidades de internacionalización, espacios para que hagan investigación, etcétera, etcétera, ¿no? Y Y no solo hay que hacerlo, hay que comunicarlo de manera adecuada.

Edgar Barroso: Mhm.

Juan Pablo Murra: Que también eso es un tema que no hemos hecho bien. Creo que hacemos más cosas de valor de las que luego se enteran los estudiantes o los estudiantes prospectos. Entonces el tema de alumnos para mí es fundamental.

Juan Pablo Murra: Segundo, profesores.

Juan Pablo Murra: Yo sí creo que tener profesores

Juan Pablo Murra: muy buenos, no solo por sus credenciales académicas, que es importante, sino por su compromiso con la enseñanza, porque creen en la misión educativa del Tec, porque abrazan el modelo educativo del techno, que es distinto al de otras universidades y disfruten el aprendizaje basado en retos y el desarrollo de competencias y que la investigación que hagan sean sea de impacto, es es distinto al perfil

Juan Pablo Murra: otros profesores. Entonces no sólo queremos profesores muy buenos en términos generales, sino profesores muy buenos para el modelo del Tec. Ahora estuve la semana pasada en Londres.

Edgar Barroso: Y una pro trajeron. Una profesora. Obviamente debe ser de las profesoras Rockstars, verdad de College.

Juan Pablo Murra: Es una chava en gente. Su Undergroud es en arte y su, pero después, su doctorado es en física y es profesor de física cuántica.

Juan Pablo Murra: pero se dedica. Esta mujer ha escrito libros de infantiles, de temas de Nano y de no sé de este tema también tiene el tema de promover a las mujeres en la ciencia, y se dio cuenta leyó una investigación que hizo mi T,

Juan Pablo Murra: de que si agarrar un frente bien interesante agarrar 5 temas, no me acuerdo qué disciplina, pero era una disciplina. Es tema

Juan Pablo Murra: y generaron artículos en Wikipedia y de otros 5 que más o menos en ese momento se publicaba el mi del al mismo nivel en los que sí y en los que no, no los publicaron en Wikipedia. Y 3 años después vieron que pasó, y los temas publicados en Wikipedia se publicaron 2 X o 3 X más artículos. Entonces en Wikipedia, Humeble Wikipedia influye en la en la conversación de la ciencia.

Juan Pablo Murra: Entonces ella se puso a generar 2 500 páginas de mujeres científicas.

Edgar Barroso: Buah.

Juan Pablo Murra: Y una de las que generó después era una mujer de 92 años se sacó, se sacó un premio el dios Metl de no sé qué cosas. Este porque esta chava, entonces lo digo porque es el tipo de profesores que creo que

Juan Pablo Murra: no amigo tiene P. HD. De Oxford. Pues, qué? Bueno va. Pero ¿qué hace con lo que con lo.

Edgar Barroso: Claro.

Juan Pablo Murra: Oye 50 de esos te transforma en Campus Monterrey.

Edgar Barroso: Acuerdo y si.

Juan Pablo Murra: Perdón. Ya Ya me he hecho muchos.

Edgar Barroso: No, pero estuvo buenísimo porque es muy conciso. No te digo, suena obvio, pero no lo es. Es Es obvio, de ninguna manera es cómo hacemos eso. No.

Juan Pablo Murra: Hacemos eso.

Edgar Barroso: Exacto.

Juan Pablo Murra: Yo el tema, Obviamente, profesores y alumnos, ese me van a ser muy necio. Va a ser mi prioridad. Obviamente, la creación de un distrito de innovación, de investigación y de emprendimiento, pues también es una apuesta muy importante

Juan Pablo Murra: y creo que estamos convencidos todos con la infraestructura. Aunque es mucho dinero, es lo más fácil.

Edgar Barroso: Sí.

Juan Pablo Murra: Ya hicimos expedition ahí, está darle vida a a estos espacios y que realmente estén aquí las empresas, los tomadores de decisiones, los las startups, los emprendedores

Juan Pablo Murra: que quieren aprovechar el ecosistema, que es el campus Monterrey. Su infraestructura, su talento sus ideas para transformar a través de proyectos de innovación tanto en las empresas actuales como en la creación de startups. Yo te diría, es otro tema bien bien importante. No

Juan Pablo Murra: creo que el tema de hacer del campus Monterrey un campus cada vez más global cada vez más internacional.

Juan Pablo Murra: también es relevante. Se tiene que ver reflejado en el perfil de los alumnos y los profesores también en el tipo de proyectos que hacemos en el mindset de de liderazgo del campus, no también, o sea, entenderse y verse como un tema global, pues creo que es bien relevante

Juan Pablo Murra: y, al mismo tiempo, este concepto de local, Este thing o Black local

Juan Pablo Murra: que sea un que sea el campo, es Monterrey, es un actor. Y ya lo es, pero todavía más bien relevante. En Nuevo León y en Monterrey.

Juan Pablo Murra: de alguna manera ya sucede, o sea, Pocas cosas pasan en este pueblo sin creer el campo, sin que el técnico.

Edgar Barroso: Mhm.

Juan Pablo Murra: Pero creo que todavía podríamos hacer más.

Juan Pablo Murra: Oye qué modelo de ciudad queremos? Cómo cuidamos los temas de medio ambiente, temas de agua, calidad del aire, temas de productividad, temas de innovación, temas de transformación de las empresas, temas de gobernanza metropolitana. Te puedo hacer así la lista.

Edgar Barroso: Claro.

Juan Pablo Murra: En los que el el Tec debería de estar influyendo, pues me parece que desde el campus Monterrey es es es bien importante. Y a lo mejor. Quinto.

Juan Pablo Murra: bueno, el tema de posgrados. Creo que es también algo que que que deberíamos de darle más visibilidad y más tema. Y creo que un quinto es otra vez esta narrativa como más integrada

Juan Pablo Murra: de suceden muchas cosas, pero parecen como que no te como que no están hilvanadas, no.

Edgar Barroso: Mhm.

Juan Pablo Murra: A veces no nos nos no, no es porque ¡ay, qué buenos somos y que nos queramos este dar abrazo a nosotros mismos, sino porque creo que si la gente conociera mejor las capacidades y los proyectos y el calibre de los proyectos que se están haciendo, conectaríamos mejor con otras personas, y el y el potencial de impacto sería mayor.

Edgar Barroso: Sí, sin duda. De hecho, yo que llevo viviendo fuera muchos años.

Edgar Barroso: siempre siempre me encuentro. Personas que dicen no en el texto están haciendo. No sé qué todo mundo conoce al texto. Todo el mundo hace referencia a él

Edgar Barroso: y me parece que lo que lo que estás diciendo, esta visión sistémica de cómo cómo, por ejemplo, este proyecto que decíamos al principio, cómo se conecta con medicina, cómo se conecta con salud

Edgar Barroso: y visibilizar eso? A lo mejor sería una prioridad importante a nivel macro, no entender todo lo que estamos diciendo en el Text, sería un proyecto interesante hacia el futuro. Ahora, si te tuviera que preguntar

Edgar Barroso: una característica o algo que tú pudieras destilar de qué área único al campus Monterrey. Y ahí es una cosa súper importante: que no nos clavemos en 2 030, sino que en 2 030 esté la semilla para el día. Dos 1 035, 2 040 que eso se llama superimportante.

Edgar Barroso: ¿qué haría único al campus Monterrey ver sus otros campos del sistema en 2 030 que di que dijeras. Eso es exactamente lo que quería ver.

Juan Pablo Murra: Yo creo que un tema que hace único y muy importante al campus Monterrey es la diversidad de su población estudiantil.

Edgar Barroso: Mhm.

Juan Pablo Murra: Venir a estudiar a Campus Monterrey, aparte de que los temas académicos son son

Juan Pablo Murra: son de alto calibre. También sabes que el 50 por 100 de tus compañeros no van a ser de Monterrey. Van a México Si tomas ahorita los alumnos que es internacionales que están estudiando su programa completo vienen de intercambio.

Juan Pablo Murra: pues ya es más o menos el 10 de la de la población estudiantil. Eso

Juan Pablo Murra: per se lo hace. Lo hace de mucho valor

Juan Pablo Murra: y creo que tendríamos que aspirar a todo. Debe llevarlo al siguiente nivel.

Juan Pablo Murra: Pero de nuevo. Ahora que estuve en imperio el Cole. En Chivas, estas universidades, pues verdaderamente son melting pots globales.

Edgar Barroso: Mhm.

Juan Pablo Murra: Y están personas de Marylist y de Asia y de China y de Francia, y de creo que eso sería súper positivo no va a ser de la noche a la mañana, pero que realmente se sienta aquí. Yo creo que ahorita. Es un buen marting pot de.

Edgar Barroso: Nacional.

Juan Pablo Murra: Este más del norte que que pero nacional. Es un buen mal tiempo. Todavía también más

Juan Pablo Murra: enfocado en las personas que pueden pagar. Cada vez tenemos con líderes del mañana y otras becas talento este que que antes ni siquiera era considerado el techno Monterrey, pero la atracción de alumnos internacionales creo que es algo que debería distinguir al al campus Monterrey de otros campos.

Edgar Barroso: Claro.

Juan Pablo Murra: De posgrados presenciales, no nuestros nuestros doctorados científicos, nuestras residencias médicas de alta especialidad, la Egade, el ego, Nuestro programa de Full Time Nba. Eso es algo que también es distinto a otros campos, entonces creo que el tema de de posgrados es otra característica bien relevante y el tema del distrito. Innovación.

Edgar Barroso: No.

Juan Pablo Murra: Y las capacidades de investigación y no son capacidades de investigación genéricas, son capacidades de investigación para incidir en retos.

Edgar Barroso: Claro.

Juan Pablo Murra: Que es congruente con el modelo. ¿no?

Juan Pablo Murra: Aquí está el Institut Provisity Research, el Institute for Theft of Education en el centro de las ciudades, el centro de primera infancia, origen, lo que viene ahora del M. M Tegnano, lo que viene ahora de inmunología, o sea, cuando vas viendo los pro los proyectos que tenemos, Pues eso sí lo hace único y y y diferente.

Juan Pablo Murra: Yo sí creo también en el que que luego aquí, en el Tec, nos encanta lanzar cosas nuevas.

Edgar Barroso: Mhm.

Juan Pablo Murra: Yo he sido muy cuidadoso. En los 4 o 5 años que he tenido esta posición de liderazgo. Yo no he lanzado cosas nuevas, este

Juan Pablo Murra: de no ver ni en ni en Cuppex ni en off.

Edgar Barroso: Es que.

Juan Pablo Murra: Pero la verdad, yo creo que más bien hay que consolidar.

Edgar Barroso: Consolidar, claro.

Juan Pablo Murra: Hay que consolidar el centro perfecto de las ciudades. Hay que considerar el Instituto, o sea, que que que realmente echen raíces y crezcan y sean este proyectos de impacto, ¿verdad? Porque lanzarlo es bien fácil.

Juan Pablo Murra: anuncias, le pones un logo, haces un Whatsate, ahí tienes redes sociales, nombres, unas personas y les asignes un presupuesto, pues en eso lo haces en 3 min, va.

Edgar Barroso: Sí.

Juan Pablo Murra: O de desarrollar el conocimiento, desarrollar las redes, desarrollar las las capacidades de liderazgo, los espacios de incidencia. Eso está bueno.

Edgar Barroso: No está bueno y toma tiempo que toma tiempo. Me parece muy bien. Ahora Juan Pablo déjame poner un poquito de de tensión que tensiones o contradicciones. Ves ahora hacia 2 030 para para lograr eso que nos estás describiendo? ¿qué te ¿Qué te preocupa? ¿qué tensiones ves ahora mismo que pudiéramos

Edgar Barroso: que pudiéramos tomar en cuenta? Por supuesto.

Juan Pablo Murra: Bueno, yo creo que se me se me ocurren este 2. Edgar. Uno es el cochino dinero.

Juan Pablo Murra: Tenemos. Tenemos, yo creo que más sueños que recursos. Y a veces hablamos como si fuéramos algo que no, que nuestro modelo de financiamiento no no no refleja.

Juan Pablo Murra: Entonces creo que esa es una atención real. Creo que tendríamos que atenderla y entenderla y y ser y ser creativos, no, no de nuevo, ser como que hubo un vengo de revisar el plan de de de los próximos 5 años

Juan Pablo Murra: y de hace un año para acá. Tenemos proyecciones de menos ingresos porque están llegando menos alumnos, no a Campus Monterrey, ¿no? Pero entre menos alumnos se están grabando más rápido y queremos gastar más.

Edgar Barroso: Mhm.

Juan Pablo Murra: Tanto en Apax como en Cappers. ¿vale? Y nadie está diciendo. Por ejemplo, vamos a invertir los próximos 5 años, 16 000 000 000 de pesos en capas.

Juan Pablo Murra: Dije qué porcentaje de esos nos estamos comprometiendo a que venga de donativos

Juan Pablo Murra: cuando sabemos, y cuando me saquen, el número no va a ser ni el 5 por 100.

Juan Pablo Murra: Entonces creo que oye ¿qué porcentaje del ingreso va a venir de educación continua y que realmente se refleje en lo el bien de los campus o de las escuelas. Tampoco sabemos oye qué tanto va a venir de fondos externos captados para investigación.

Juan Pablo Murra: entonces, o sea, el tema de del del modelo financiero. Creo que es una tensión real y hay que y hay que ponernos creativos, y hay que entrarle. Y creo que es un tema de ge más más que de eficiencias en el gasto de generación de nuevos modelos de generación de recursos.

Juan Pablo Murra: y pueden ser recursos que entren al Tec o recursos que se gasten en el ecosistema del Tec. No sé cómo decirlo.

Edgar Barroso: Claro.

Juan Pablo Murra: La feria del libro, o sea, a lo mejor el té que entra en donativos y de 8 o 9 000 000 de pesos, pero en realidad es un evento de 60.

Edgar Barroso: Mhm.

Juan Pablo Murra: Que una parte lo gaste el gobierno, y otra parte entra es intermex y otra parte entra, pero ya es un posaico de porque es tan grande y tan importante. No es por los 5 o 6 000 000 que entran al Text porque es 10 X más grande

Juan Pablo Murra: que lo que entra el Tec. Entonces también, si no entra dinero el Tec, pero están haciendo investigación de vanguardia. En claro.

Juan Pablo Murra: este hay más. Hay más. Happy Comprobad, pero pero la financiera creo que es una es una tensión real.

Juan Pablo Murra: La La segunda es esta capa este este dilema que va a estar siempre en el deck de oye que tantos somos un solo Tec.

Edgar Barroso: No.

Juan Pablo Murra: O como estándares

Juan Pablo Murra: más o menos comunes o compartidos en los diferentes campos versus. Hoy tenemos campos distintos con aspiraciones distintas y capacidades distintas.

Juan Pablo Murra: y logramos más bien un modelo en donde generamos un ecosistema de campus que las diferencias entre los campus es lo que nos complementa. Y como sistema nos hace más fuertes.

Juan Pablo Murra: se dice más fácil de lo que se hace, porque entonces.

Edgar Barroso: Claro.

Juan Pablo Murra: ¿qué implicaciones tienen? ¿oye, Hay personas que dicen, no es que es terrible esto porque el título que le das es el mismo, entonces no, no tienes control de calidad, y no ti, tienes dispersión.

Juan Pablo Murra: Yo no lo veo tan así. Yo más bien, creo eso. Hay ciertos estándares compartidos de calidad académica en procesos de admisión, en procesos de contratación de profesores, en procesos de gestión, en procesos de evaluación, de learning Alcoms en acreditadoras. Pero después puedes tener desviaciones positivas. Es.

Edgar Barroso: En el.

Juan Pablo Murra: Otra vez. No, Esto es el de positive Psycology. Este decía, oye, pues no. A los humanos no no nos gusta la desviación, lo que nos debería molestar la desviación negativa, No, no la.

Edgar Barroso: Es que.

Juan Pablo Murra: Entonces, pero en general, esa narrativa también sintiendo por qué puede ser complicado. Entonces se te va a parar Aquí un papá enfrente este o un periodista filoso a decirte. Ah, entonces los que estudian en Monterrey son mejores que los que estudian en león y empieza la patinar.

Edgar Barroso: Sí, claro.

Juan Pablo Murra: Entonces creo que esa esa tensión entre

Juan Pablo Murra: qué? ¿qué ¿Qué tanto pueden convivir con una misma marca o en un por por usando un término comercial, ¿no? Pero en una misma institución académica, un campus Monterrey, con un campus obregón con un campus sonora con un campus león, pues es, es, es un reto. Es una. O sea, creo que hay que reconocerlo, Es una atención y hay que gestionarlo sin que nos asuste. Y tampoco tampoco nos podemos ir así de repente, tener este bajo

Juan Pablo Murra: la misma marca a M. I, T y al Community College de los Álamos en San Antonio, Pero mientras mantengamos ciertos ciertos elementos compartidos y comunes.

Juan Pablo Murra: creo que es importante.

Juan Pablo Murra: Sí, perdón, me estoy acordando de un tema a lo mejor esto sí no es una atención, pero creo que también es importante, y yo le quiero dar cada vez más peso. Es el tema de la de la filosofía y los principios del Tec.

Edgar Barroso: Okay.

Juan Pablo Murra: Qué parte de lo que hace el Tecalteco ha hecho el Teca, el Tec, pues es la visión original de don Eugenio, y estos empresarios de la importancia de la educación, de la importancia de la libertad de la.

Edgar Barroso: Mhm.

Juan Pablo Murra: Derechos de la importancia de la libre empresa, de la importancia de la corresponsabilidad social, de la de la visión de emprendimiento e innovación. Esa cultura tec de oye este aquí. Creemos que el futuro puede ser mejor y nosotros lo hacemos mejor. No nos esperamos a que el Gobierno o alguien más lo arregle

Juan Pablo Murra: es bien importante. Y de hecho, cuando el tech va a una ciudad, pues lo primero lo que lleva no solo son los alumnos, lleva esta filosofía. Y esta y esta visión.

Juan Pablo Murra: y creo que en los últimos años hemos hablado menos de esto de lo que deberíamos y nos ha jalado mucho el parecernos a otras universidades, y entonces lo más importante es el ranking, el número de papers, el número de citas. Este porcentaje de empleabilidad, la tasa de admisión

Juan Pablo Murra: sí está bien, No sé todos esos, pero pero lo importante es esta visión de de qué tipo de mundo y qué tipo de país queremos y, por lo tanto, ¿qué tipo de personas estamos formando.

Edgar Barroso: Sí, totalmente.

Juan Pablo Murra: Me das el chance de intervenir tantito. Por favor.

Edgar Barroso: Por.

Juan Pablo Murra: Con respecto a esto de los principios que se me hacen muy se me hace muy padre, Juan Pablo que los traigas a colación, porque son cosas que creo que no deben de perderse en el en el tiempo que son muy legítimos. De hecho, muchos de ellos perduran Desde la fundación del Tec de Monterrey. Al día de hoy.

Juan Pablo Murra: adicionalmente a los principios, Pensando en las personas en los liderazgos del campus Monterrey, de todos los que trabajamos en el campus de Monterrey. ¿qué tipo de cultura te gustaría que que se cuidara y que se hiciera énfasis este y que nos distinguiera? No, esa es una una una una pregunta que a lo mejor no, no está en un indicador, pero sí que se refleja. Esa

Juan Pablo Murra: es muy, muy interesante. O sea, sí creo, digo.

Juan Pablo Murra: obviamente estás está la cultura techno que es compartida. Y esta visión que a lo mejor desea, ahorita un poco de de la libre empresa, el Estado de Derecho, la innovación, el emprendimiento, la corresponsabilidad por las comunidades en donde estamos ver, entender a la empresa como un actor social relevante, creador de valor compartido. Todo eso es para Toltek.

Juan Pablo Murra: eso, aunque estés en Chiapas, este todo es válido, ¿no? Yo sí. Creo que Campus Monterrey. Si me dices que que soft de de de cultura o de características deberían de tener las los líderes y las personas que están aquí

Juan Pablo Murra: altos estándares, No, pues búsqueda la búsqueda no solo de la calidad, sino de la excelencia.

Juan Pablo Murra: visión global este de entender no solo lo que está pasando en en en Monterrey, sino como desde Monterrey, que temas son relevantes para para el mundo y traer más de del té que al mundo y más del mundo, a a

Juan Pablo Murra: A, A, Al Al Tech. Creo que pasa por campos Monterrey. Entonces altos estándares sean visión global. Y otro tema que también creo que debería ser de todos. Por el tema de colaboración.

Juan Pablo Murra: Digo estos temas de ver cómo conecta mejor que que no parezca que aquí está gay. Aquí esté go. Aquí está la escuela, ingeniería. Aquí está Expedition. Acá. Está distrito. Tec acá. Está. No sé qué acá. Está. Oye, pues este. Porque creo que muchos, y, de nuevo, porque muchos de los problemas son son complejos, son sistémicos. Entonces necesitas el inter y transdisciplinaridad. Creo

Juan Pablo Murra: que las experiencias formativas serían mejores. Creo que le daríamos más a nuestros alumnos de nuestros profesores.

Juan Pablo Murra: entonces buscar y y nuestra a veces nuestra estructura organizacional no ayuda.

Juan Pablo Murra: Y y porque tienes escuelas, Tienes distractorías. Tienes institutos. Y creo que va a seguir existiendo. Eso no va a ser fácil, pero la unidad que une es el el campus

Juan Pablo Murra: a generar esa esa cultura de de vamos juntos. Pues creo que es algo y jalar también de otros campos, y leer estas conexiones que que estaría padre que en el 20 30 digan, oye, pues yo no sé qué pasa ahí en Monterrey, pero ya colaboran 5 equis más que en el resto del teclado.

Edgar Barroso: Sin duda me gustó mucho esta última conseguiste de la desviación positiva

Edgar Barroso: y de reconocer que es un reto enorme, pero que podría ser interesante. No sólo ver es como la economía. No hay que ver cómo la distribuimos, ¿no? Pues hay que hacer cómo la crecemos. Para que todo el mundo tenga acceso a más de de de más recursos.

Edgar Barroso: oye Juan Pablo y siguiendo con la siguiente bloque de preguntas general que va enfocada en a cómo llegamos ahí, pero yo quisiera adelantar un poquito más de todo lo que has mencionado que no es negociable para ti.

Edgar Barroso: O sea, ¿qué es lo que sí o sí tiene que pasar.

Juan Pablo Murra: Yo creo que ahorita. Retomando otras, yo creo que este tema de la cultura y los valores, eso es no negociable y y 2, el el enfoque y la obsesión de la atracción de talento.

Juan Pablo Murra: o sea, tanto en los alumnos como en los profesores como los directivos, ¿verdad? Yo creo que si traemos buenos alumnos, traemos buenos profesores, y el equipo de liderazgo está alineado. A esto lo demás, se va a acomodar.

Edgar Barroso: Sí.

Juan Pablo Murra: Pero si no logras esto, va a servir, o sea, pues puedes usar un milagro.

Edgar Barroso: No.

Juan Pablo Murra: El sistema te va a empujar. Pero pero las chances of shiditing son pequeñas, creo yo. Si no tienes a las personas adecuadas arriba del camión no.

Edgar Barroso: Sí, sin duda. Y ese es el ejemplo que, como dices tú, en todas las universidades del mundo, esas son las 2 cosas que no pueden faltar: buenas profesoras, buenos alumnos o estudiantes. Ahora

Edgar Barroso: déjame ponerlo en positivo. ¿qué cosas hoy estamos haciendo bien y cuáles deberíamos dejar de hacer.

Juan Pablo Murra: Sí mira. Creo que

Juan Pablo Murra: creo que traemos el el el discurso y la narrativa correcta, ya creo que sí.

Juan Pablo Murra: Después de muchos años en donde oye que que que este, cuando yo llegué aquí al Tec.

Juan Pablo Murra: que eran las 2 cosas que más importaban en el Tec.

Juan Pablo Murra: el número de alumnos y el número de pesos que.

Edgar Barroso: Sí.

Juan Pablo Murra: Y era muy fácil contar cabezas y contar ingresos.

Juan Pablo Murra: y y sigue siendo importante. No digo que.

Edgar Barroso: Claro.

Juan Pablo Murra: No este, como decimos gobernador. Lost, queremos hacer más cosas y requerimos los recursos.

Juan Pablo Murra: pero sí creo que el tema de crecimiento más o menos. Ya está controlado más o menos. Luego también cuando alguien crece, abrimos botellas de champán, ya va. Entonces te habla que este ahí, todavía esa ese ese tema, de que, de de de que más es mejor.

Juan Pablo Murra: Pero yo creo que lo que hemos ido haciendo en los últimos años de más programas de cupo límite, más enfoque en las credenciales, más control en en las admisiones con estándares diferentes. Creo que eso es muy positivo.

Juan Pablo Murra: Yo sí creo que el tema de de la del de creación de distrito Tec Y ahora el distrito de innovación.

Juan Pablo Murra: pues no era obvio que hubiera sucedido, ¿ O sea, la verdad es que.

Edgar Barroso: Mhm.

Juan Pablo Murra: Una visión y un empuje y un compromiso de mucho trabajo del equipo de Mario Adrián, de José Antonio Torre en su momento de del Consejo. Creo que es algo también muy, muy, muy bueno.

Juan Pablo Murra: Creo que la visión de de de ser una institución cada vez más diversa e incluyente

Juan Pablo Murra: en muchos en muchos ámbitos, obviamente.

Edgar Barroso: De la.

Juan Pablo Murra: Internacionales, profesores internacionales, pero también en el perfil del talento que contratamos en las narrativas. En la en la filosofía este de la Institución. Creo que también es algo

Juan Pablo Murra: que vamos bien y que no hay que olvidar.

Juan Pablo Murra: Hace 7 8 años, lo que estaba incendiado aquí en el campus. Eran temas de inclusión de género, violencia de género. Este los temas L. G, B, T, era lo que, o sea, se veía la la la E, C, A, C, que era nuestra encuesta de pues era lo que salía más en rojo. Y ahora lo que sale mejor.

Edgar Barroso: Mhm.

Juan Pablo Murra: Este no. Y pero creo que es bueno porque sí. Creo que para una universidad, los temas de

Juan Pablo Murra: de ser un espacio de diversidad de inclusión en donde podamos aprender este en este mundo tan polarizado. No a dice Well. Este es otro frase que creo que es algo que también hemos hemos mejorado todavía. Ahora podemos este hacer más.

Juan Pablo Murra: pero creo que es algo. Son bases positivas para poder construir sobre eso.

Edgar Barroso: Y por último, mencionabas de del campus como este ente que conector.

Edgar Barroso: ¿cómo lo ves tú? ¿cómo podría el campus conectar estas iniciativas a través del talento de los currículums

Edgar Barroso: de la cultura. ¿cómo lo ves tú? Co: ¿Qué te gustaría ver hacia 2 000. 32 035, 2 040 o dejar las semillas para que esto empiece a suceder y ya no no sea tanto por siglos que, aunque deben de existir, también esta está esto que tú tienes de visión de interconectar todos estos

Edgar Barroso: iniciativas.

Juan Pablo Murra: Fíjate que digo, no, no sé, No tengo la respuesta. Si te soy honesto y sería, yo creo que también una tarea interesante. Decir Oye qué qué, qué qué genera que se den estas culturas y estos espacios de de de de de de conexión, ¿no?

Juan Pablo Murra: ¿

Juan Pablo Murra: En mi. Y Y creo que va a haber elementos muy humanos, oye como detonas, qué grupos de 5 10 personas se sientan a tomar un café y platicar de un tema, y creo que puede haber elementos tecnológicos.

Edgar Barroso: Mhm.

Juan Pablo Murra: No sé cómo va que tanto pudiéramos a a través de inteligencia artificial, redes sociales. Este estrategias de comunicaciones digitales, poder generar estos espacios de encuentro y y y y y conexión que

Juan Pablo Murra: creo que es importante que se den en lo tangible en el mundo real.

Edgar Barroso: No.

Juan Pablo Murra: A ver si se topan en la cafetería, pues no va a ser tan tan sencillo, ¿no? Ahora, en mi

Juan Pablo Murra: En mi mundo previo de de de consultor, este había un framework que se utilizaba mucho en los temas de cambio cultural. Se llamaba el el el influence model.

Edgar Barroso: Mhm.

Juan Pablo Murra: Que ¿cómo haces para que alguien cambie un comportamiento de A a B. Entonces, pues aquí, ¿cómo le haces para que pasemos de operar en silos a vernos como una entidad conectada y colaborativa, ¿verdad? Y había este 4 palancas, 1 hay que decirlo.

Edgar Barroso: Mhm.

Juan Pablo Murra: Entonces

Juan Pablo Murra: lo ponían en un ejemplo sencillo. Si quieres que la gente, en vez de imprimir a color y, por un lado, impriman en blanco y negro y por los 2 lados. Pues 1 Dilo dice a los va porque así.

Edgar Barroso: A la.

Juan Pablo Murra: Yo adivinar, No.

Edgar Barroso: Sí.

Juan Pablo Murra: Eso te detona toda una serie de acciones. No, este lo tendremos que estar incorporando. Se tendría que estar comunicando en el campo. Lo tenemos que estar teniendo en el discurso. No

Juan Pablo Murra: 2.

Juan Pablo Murra: Les tienes que generar las capacidades a las personas para hacerlo.

Juan Pablo Murra: porque te puedes ir, oye, pues este el el Skil Will, No, pues ya te oí, tengo el will, pero si no sé hacerlo.

Edgar Barroso: Claro.

Juan Pablo Murra: Lo mismo que no que no querer hacer, entonces el desarrollo de capacidades. Creo que también es un tema importante, individuales y e institucionales.

Edgar Barroso: Mhm.

Juan Pablo Murra: Eso. Qué significa? Pues no sé, habría que darle una pensada, ¿no? Y luego es oye como alineas las estructuras y los sistemas A

Juan Pablo Murra: para que refuercen este comportamiento.

Edgar Barroso: Mhm.

Juan Pablo Murra: Oye Si aquí este voy y le doy el borrego de oro al mejor departamento que ganó todos los indicadores, y se lo doy enfrente a los demás, pues tú crees que van a colaborar.

Edgar Barroso: No.

Juan Pablo Murra: Les dices, oye, colabora, pero premio al individuo. Entonces oye como como líneas los sistemas y los procesos A

Juan Pablo Murra: pueden ser hasta los espacios físicos. No este digo algo que yo todavía creo que no lo hemos acabado de de de de enten de agarrar al tema. Es, y lo hemos discutido mucho, que es mejor tener espacios físicos en donde hay profesores de las diferentes escuelas o que cada escuela tenga su propio espacio.

Edgar Barroso: No se.

Juan Pablo Murra: Viendo que la escuela tenga su propio espacio.

Edgar Barroso: Mhm.

Juan Pablo Murra: Consciente o inconsciente. Bueno, eso qué implica Entonces, si si nos vamos a ir para allá, entonces ¿cómo generas entornos y sistemas en donde sí convivan y sí se se pueda dar ese tipo de narrativas. Temas a veces tan sencillos como.

Juan Pablo Murra: por ejemplo, yo. Cuando creamos las escuelas, yo hiciste mucho. Las escuelas no son marcas. Son este entidades organizacionales que hoy existen y mañana pueden no existir

Juan Pablo Murra: batalla perdida. Ya son marcas, ¿verdad? Entonces, tú vas ahora a un evento del Tec

Juan Pablo Murra: y A, y aparecen como 7 logos del Tec, en vez de que aparezca el del el Tec de son cosas, pero que que tendrías que alinear de nuevo estructuras, procesos, sistemas, indicadores métricas. Y el cuarto, que luego es el más importante, es role Modeling.

Juan Pablo Murra: Este oye el jefe viene y dice: hay que imprimir en blanco y negro y cambias el setting de la impresora para que imprima blanco y negro y le enseñas a la gente a cambiar de imprimir a color blanco y negro, pero luego llega el jefe, y no, no. A mí me lo ponen a color.

Edgar Barroso: Y en un lado.

Juan Pablo Murra: Se acabó el cuento.

Edgar Barroso: Mhm.

Juan Pablo Murra: Tendríamos que ser. Nos los líderes de la organización ejemplo de la cultura que quisiéramos este generar.

Juan Pablo Murra: Y y la verdad son de estos temas.

Juan Pablo Murra: Yo Yo, ya desde que estaba en el Mckinsey, fui parte de la de la práctica de organización y creo mucho en temas de transformación cultural.

Juan Pablo Murra: Salvador en su momento, pues esto era 1 de sus temas. Sí, creo, y de hecho me Shamon Me y yo me lo que hemos abandonado un poco este este tema. Ahora que está pasando el área de talento de nuevo a la a la rectoría y estoy revisando

Juan Pablo Murra: los planes de trabajo con el equipo de talento con Claudia, velar.

Edgar Barroso: Mhm.

Juan Pablo Murra: Todo es operativo, es todo. Es operativo de echar operativo.

Juan Pablo Murra: ¿cómo vamos a pagar? Cuáles son las prestaciones? ¿cómo vamos a subir el sueldo mínimo con elizondo. Hay que hacerlo, pero cultural, el cambio cultural.

Edgar Barroso: Claro.

Juan Pablo Murra: Pero ni aquí, o sea, das cuenta que por acá nos está pasando. No.

Edgar Barroso: Guau! Oye! Y por último.

Edgar Barroso: ustedes saben que estos modelos de I están avanzando muy rápido, y cada vez están haciendo justo en lugar de hacer cosas operativas. En realidad se están moviendo a hacer cosas mucho más estratégicas de prospectiva y de gobernanza.

Edgar Barroso: Si si tú, si un modelo de 2 030 de ya ya como un sistema robusto, tuviera algo que aprender de esta conversación.

Edgar Barroso: qué le gus? ¿qué te gustaría que fuera? ¿qué le dirías a este? Model Hey, No se te vaya a pasar esto.

Edgar Barroso: ¿qué te gustaría que el modelo aprendiera de esta conversación. Juan Pablo.

Juan Pablo Murra: Yo creo que algo importante para mí ahorita mientras conversábamos a lo mejor me cayó. Este 20 es

Juan Pablo Murra: no, no, no queremos generar una estrategia que sea un copy paste de lo que hace una universidad tradicional

Juan Pablo Murra: de investigación en Boston, Massachusetts.

Juan Pablo Murra: Ti o sea como como generamos un modelo de universidad

Juan Pablo Murra: que desde México y desde Monterrey sirvan para Monterrey y para el mundo, con nuestras fortalezas y nuestras capacidades.

Juan Pablo Murra: y eso inicia por nuestros valores, por nuestra filosofía, por nuestra cultura, por nuestras capacidades de innovación educativa, por nuestras capacidades de emprendimiento por nuestra, por el por el hecho de ser parte de una red de campus por por ser parte de un grupo educativo por contar con tax salud. O sea, hay muchos elementos muy únicos y distintivos de del Tec

Juan Pablo Murra: que son bien importantes que yo quisiera que esta entidad esta entidad de inteligencia artificial no dé por sentado, porque luego, si creo, no no a lo mejor que me perdone la vida. El agente que nos va a estar.

Edgar Barroso: Sí.

Juan Pablo Murra: Luego, pues, l a agarra el promedio de muchas cosas. No sé cómo decirlo.

Edgar Barroso: Sí, Sí, Sí.

Juan Pablo Murra: Datos que están ahí afuera. Entonces, pues, si todo el mundo vamos y le preguntamos a la gente oye cómo hago una mejor universidad, pues te va a dar la misma respuesta. Y creo que.

Edgar Barroso: La misma receta.

Juan Pablo Murra: Que no nos dé una receta, o sea, que nos dé a entender que nos hace únicos diferentes y y que parte de lo que queremos lograr Nosotros, como institución y lo que México y Monterrey necesitan más que tratar de migrar un modelo este que exista en otros lados.

Edgar Barroso: Y justo. Justo. Esa es la idea de estas conversaciones Juan Pablo.

Edgar Barroso: O sea, que no agarre, porque podemos hacer una búsqueda en Internet y te va a decir exactamente lo que acabas de decir. Pero si si vamos al al core, lo que las personas

Edgar Barroso: sienten incluso o han visto o tienen este conocimiento productivo me parece

Edgar Barroso: súper interesante y y y y es un es un es, por ejemplo, es un ancla. O tú eres una palanca, no para nosotros, es que siempre toda la estrategia esté súper anclada a los valores, los principios, y me gustó mucho la idea de no competir por eficiencias, sino por diferenciación.

Juan Pablo Murra: En en.

Edgar Barroso: Y es superimportante.

Juan Pablo Murra: En.

Edgar Barroso: Oye María Adrián, quieres que veamos algunos de los proyectos.

Juan Pablo Murra: Mira yo, yo ahorita si quieres edgar rescatando. Yo creo que prácticamente Juan Pablo cubrió todo.

Edgar Barroso: Sí.

Juan Pablo Murra: Las cosas que yo también traigo en la mente, que hemos estado platicando el plan 20, 30. No veo alguno que que quede que quede fuera este ahorita. Yo rescato 1 que no, no no querer compararnos y ser como alguna otra universidad, sino ser únicos. No, Yo creo que eso es algo muy, muy bueno, que que es importante auto declararlo.

Juan Pablo Murra: La otra es que el 2 030, pues ya está ya.

Edgar Barroso: Mañana.

Juan Pablo Murra: Es más de aquella que no sé si acabemos ya casi vamos a estar a la mitad, verdad, pero.

Edgar Barroso: Exacto.

Juan Pablo Murra: Que estamos sobre el camino trabajando y pensar en esa semilla para el 20, 35, el 40, incluso para para años más más adelante hay otro elemento que a mí me interesa mucho. Este escuchar tu opinión. Juan Pablo de tiene que ver con la vivencia estudiantil.

Juan Pablo Murra: Yo, una de las cosas que que la verdad me da muchísimo gusto, ver con los alumnos

Juan Pablo Murra: y también con algunos de los profesores y equipo. Es que, pues, bueno, tenemos una actividad, por ejemplo, deportiva muy bonita cultural, estudiantiles, pero aparte suceden cosas sin que nosotros las dirijamos. No hay alumnos emprendiendo que no hay que estorbarles. No este que hay que

Juan Pablo Murra: a ver cómo les ayudamos, pero la la vivencia, si es algo muy importante. No sé recuerdas que en un en un trabajo que hicimos con unos alumnos el año pasado. ¿qué es lo que más valoras del Tec? Y Y, pues.

Juan Pablo Murra: pues muchos se refirieron a la vivencia, además de los maestros y las clases. Entonces esa vivencia en Monterrey es de cómo te gustaría que que sucediera. Sé que teman, hay temas de diversidad y otros más, pero

Juan Pablo Murra: que al final del día el alumno te salga, diga, híjole. Lo que viví aquí no lo puede ver también a ver. Digo, si no lo menciono, lo dice lo explícito. Creo que es bien importante.

Juan Pablo Murra: Creo que el cada vez más el conocimiento y técnico o hasta las competencias, las vas a poder.

Edgar Barroso: En el.

Juan Pablo Murra: Diferentes maneras.

Juan Pablo Murra: Pero la oportunidad de tener una experiencia inmersiva de 4 años en una comunidad, en estos espacios en donde tienes la oportunidad de de cuidar tu bienestar en las En las 7 dimensiones que hemos definido de generar una red de amigos, de desarrollarte a través del deporte, de desarrollarte, expresarte a través del arte o la cultura de desarrollar habilidades de liderazgo

Juan Pablo Murra: a través de grupos estudiantiles.

Juan Pablo Murra: Entonces, un lujo, este y un privilegio que tendríamos que entenderlo así, nutrirlo, crearlo y y y celebrarlo. No

Juan Pablo Murra: en creo que con eso de tener que lo los básicos, pues que sea una

Juan Pablo Murra: comunidad segura, comunidad segura en en todos los estilos.

Edgar Barroso: Mhm.

Juan Pablo Murra: Físicos emocionales, que no haya violencia y discriminación la parte que sea diversa e incluyente, que tenga y que se vea y creo que lo tenemos, pero hay que celebrarlo y nutrirlo. No hay padres y madres de familia que me dicen, ay, pues Yo no sé que les dan en el Tec, pero yo tengo un hijo en el Tecco o a un hijo en el Tec y otro en otra universidad. Este, si quiere salir a comer el mundo, ¿verdad? Este, ese ese Dna, ese chico.

Juan Pablo Murra: sea que se sienta aquí en la Comunidad. Creo que es

Juan Pablo Murra: bien bien bien importante, y ese sentido también de comunidad de oye. Yo estoy aquí, me cuida y me acompaña y me reta. Y también creo que es algo que que tendría que ser una una una característica que nos lleve para eso

Juan Pablo Murra: oye y compala. Y finalmente, ya también para cerrar este, Ya ves que me has hemos platicado la narrativa. De hecho, lo tenemos como proyecto del del 20, 30 y a mí se me hace que esta conversación.

Juan Pablo Murra: la verdad, a mí me resulta tan mal, es de las mejores conversaciones con Pablo que que la verdad te he escuchado. Y me da muchísimo gusto. No porque creo que nos va a ayudar muchísimo.

Juan Pablo Murra: La narrativa que que nos has insistido oye, Yo quisiera que aquí no hay oro en Monterrey que el Tec de Monterrey. ¿es esto esto esto? Esto?

Juan Pablo Murra: Esa narrativa? ¿cómo te gustaría que que fuera? Digo, este se repita a ver. Yo 1. Sí, creo este tema de

Juan Pablo Murra: retomar los valores y la filosofía

Juan Pablo Murra: que hace al Tec ser el Tech. No, yo no sé quién va a estar aquí en 20 años o en 30 años.

Juan Pablo Murra: pero que esas personas, pues, de de nuevo sigan creyendo y defendiendo la libertad, el Estado de Derecho, la libre empresa, la capacidad de crear valor, el sentido de corresponsabilidad y los que el respeto a la dignidad de las personas y todos los temas que son torales del Tec. Creo que hay que acabarlos de definir mejor y.

Edgar Barroso: A lo mejor. Modernizar un poco el lenguaje, no porque sales ahorita y le dices a los chavos, no la libre empresa. Y a lo mejor no conecta, va, Sí.

Juan Pablo Murra: Pero hay que hay que hay que esa parte. Creo que es bien importante que esté en la narrativa. Segundo: este tema como de una comunidad de al de de una comunidad transformadora

Juan Pablo Murra: que implica. Oye, pues, para transformarte, es ser muy bueno. No, No, no queremos excluir, pero sí, pues para invitarte, te tienes que que que que ser de de de World Class y y y querer ser parte de esta comunidad y que cada vez tengan. Creo que eso es fundamental.

Juan Pablo Murra: Creo que los temas de innovación, investigación y emprendimiento con impacto se vuelve bien relevante.

Edgar Barroso: Mhm.

Juan Pablo Murra: Esta narrativa de hacer más de lo que venimos haciendo. Está bien, pero no vamos a cambiar a México.

Juan Pablo Murra: Me

Juan Pablo Murra: de nuevo este traigo ahí a un consejero diciéndome. No, No, No es que el tech deberías de hacerlo más chico para que los que salgan sus sueldos sean 3 equis. Lo que ganan hoy.

Juan Pablo Murra: pues no, eso no lo puedo de, o sea, lo puedo. No lo voy a declarar yo.

Edgar Barroso: Claro.

Juan Pablo Murra: Tenemos que cambiar el ecosistema, entonces el el el sí, realmente mover a México a una economía del conocimiento, una economía más productiva. Una economía es es y no es nada más la investigación que haga dentro del Tech. Como vas, transformando el ecosistema, creo que también tendría que ser parte de la narrativa. Eso no va a suceder de aquí al 20 30.

Edgar Barroso: No.

Juan Pablo Murra: Pero pero ¿co qué capacidades y qué en las empresas, en los gobiernos, en la en el Tec, en otras universidades. Tienes que ir desarrollando para para en su momento realmente transformar a México, pues es algo que también tendría que ir desde el Tec sentirse que el tech traía. Esa bandera.

Edgar Barroso: Sí, y es como una nueva generación, también de emprendimiento, No. Si en su momento Monterrey fue una ciudad de empuje, pues, de manufactura exacto. Y ahora que, o sea, el té, creo que podría. Tiene el potencial. Ya me estoy metiendo Mariane, perdón, pero me estoy emocionando mucho.

Edgar Barroso: Pero esta idea de que incluso podamos pensar en esta innovación y emprendimiento de que puedan empezar a salir unicornios del Tec, o sea, empresas con un una capacidad de impacto muy grandota que puede ser sustentable en el tiempo y que pueda tener una influencia enorme en el país

Edgar Barroso: de atracción de talento y al mismo tiempo estar trabajando con el Tec está muy emocionante. Esto ¿ La verdad.

Juan Pablo Murra: Compadre, No, Pues muy bien. Pues yo creo que cerramos Edgar. La idea es hacer lo mismo o algo similar este con David Garza nos recomendaste a memo, Javier. No sé si alguien más te gustaría. Incluso podemos invitar a más a más este líderes no ahí. ¿qué recomendación usarías si seguimos ese camino? Algo Algo

Juan Pablo Murra: creo que sería bueno, este.

Juan Pablo Murra: pero tiene una agenda de locos, pero luego lo que le invitas del taxi dice que sí a José Antonio Fernández.

Edgar Barroso: Mhm.

Juan Pablo Murra: Bueno, sería muy bueno. Sí,

Juan Pablo Murra: Ricardo, saldívar. Si tiene chance, creo que sería sí, sería Sería bueno, ¿no? Excelente, porque Yo creo que son personas que de alguna manera conocen, entienden lo el y es.

Edgar Barroso: En el.

Juan Pablo Murra: Y siempre te expresan, el que todavía no se acaba la película que quieren ver. ¡ay, falta, a pesar de que hemos avanzado. No, pues José Antonio lo dice así como se fundó un en una casa rentada hace 80 años y ahorita el té que es esto? Bueno, esta es la nueva casa rentada, verdad que que tengo.

Edgar Barroso: Claro.

Juan Pablo Murra: Somos 80 años. Muchas gracias. Este, la verdad sí es. Fue muy valiosa. La conversación, una disculpa por el set, no, no, no pasa nada.

Edgar Barroso: No, no, no.

Juan Pablo Murra: No te van a grabar, pero yo pensé que audio.

Edgar Barroso: Sí.

Juan Pablo Murra: Ya mucho. Edgar dice es que tenemos que decir que que es una conversación muy especial, pero y no va, obviamente es privada, no te preocupes. Este va a ser para buen uso y lo vas a ver reflejado en en lo que vamos a estar comunicando buenísimo.

Edgar Barroso: No. Muchas gracias. Juan Pablo. Yo también, como profesor, también fue muy inspirador escucharte la verdad.

Juan Pablo Murra: Gracias.

Edgar Barroso: Venga, que estés muy bien.

Juan Pablo Murra: Escucho.

Edgar Barroso: Gracias. Adrián. Hasta luego.

Juan Pablo Murra: Gracias por palo la película.

Juan Pablo Murra: Muchas gracias.

## Connections
- [[02-community-ncm]]
