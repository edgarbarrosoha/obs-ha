Ricardo Saldívar: Bueno, pues yo creo que vamos aprovechando el el tiempo Edgar Este. Muchísimas gracias. Ricardo como comentaba. Este es, estamos haciendo el plan del campus al 20 30,

Ricardo Saldívar: y no queremos perder de vista las voces importantes líderes

Ricardo Saldívar: para que, si están permeadas en ese plan

Ricardo Saldívar: y la la forma en la que lo estamos haciendo, porque a lo mejor me podrías platicar a mí, pero a veces humanamente, Yo no puedo retener exactamente toda la idea y guerra del Barroso, que es profesor de nosotros de la Escuela de Gobierno.

Ricardo Saldívar: Él radica en Suiza, proviene, viene para acá. Este. Él tiene un startup que tiene vínculo con el Ted, tiene incluso.

Ricardo Saldívar: pues, en vinculación directa. Y él tiene una metodología que se llama arquitectura de horizontes

Ricardo Saldívar: que la que utiliza, pues, para para muchas intervenciones y no está guiando con esta con este plan y y se apoya mucho en su plataforma, incluyendo también el uso de inteligencia artificial. Entonces este es esta conversación más que una grabación como tal

Ricardo Saldívar: se va a utilizar como insumo para el plan 20 y 30 que incluso David lo tiene contemplado para presentarle al Consejo. Paso

Ricardo Saldívar: Este, como como está. El plan del campo es puerto rey. Entonces esto nos va a servir también este insumo que en su momento vas a revisar.

Ricardo Saldívar: creo yo, antes de que llegue al al Consejo. Pero Edgar si quieres proponer presentarte con ricardo y platicar un poquito de de de de esta conversación. La conversación la va la va a llevar este Edgar. Entonces, adelante. Edgar, por favor.

Edgar Barroso: Gracias materia. Muchísimas gracias mucho gusto. Ricardo mira la idea de hoy es muy interesante porque, como como has estado seguramente al tanto de todo lo que está pasando con inteligencia artificial.

Edgar Barroso: el lenguaje o el lenguaje natural, como le llamamos en las técnicas de de aprendizaje de máquina se convierte ahora en algo mucho más poderoso porque, como dice María Adrián, ahora lo podemos guardar. Lo podemos analizar, lo podemos contrastar y, sobre todo, poder entender

Edgar Barroso: la visión de muchas personas al mismo tiempo, es decir, que esta conversación

Edgar Barroso: es mucho más que solamente una grabación. Y una entrevista va a ser literalmente una guía, un que vamos a tener como vectores, como si fuera un vector de hacia dónde quieres que vayamos en los próximos 4 años. Y ya verás que también los próximos 9,

Edgar Barroso: y eso, y Esa información se contrasta con las entrevistas que hemos hecho con David con Juan Pablo, y eso empieza a hacer lo que en en la academia, llamamos inteligencia colectiva, O sea, cómo podemos sumar las ideas, no de manera retórica. Porque, como dicen Adrián, eso es muy difícil de hacer solo con personas a

Edgar Barroso: sino matemáticamente. ¿cómo podemos hacer que esas ideas se conviertan en un vector y esos vectores nos puedan ir llevando hacia hacia donde queremos ir hacia el futuro. Pero tomando en cuenta las ideas de todas las personas, pero no nada más sumándolas, sino de verdad, haciendo un análisis semántico de lo que de lo que la comunidad quisiera ver hacia 2 030

Edgar Barroso: y ver ¿Cómo hacemos que todas esas ideas converjan en una visión que es la que está hablando María Adrián. Entonces te vamos a hacer un par de preguntas. La idea es, pues, documentar cómo piensas, ay, perdón, perdón, ricardo.

Ricardo Saldívar: Disculpa antes de iniciar con las preguntas. Agradecerte

Ricardo Saldívar: edgar por tu tiempo por tu ayuda en este proceso. Me parece muy interesante. Lo que has descrito, la metodología y la tecnología que se está empleando y el cómo la suma de las voces es la que

Ricardo Saldívar: va a ser la que dijéramos: refleje el pensamiento colectivo, el pensamiento institucional. Y gracias más Adrián por por invitarme a este proceso vamos a ver, Espero que sea de valor agregado para ustedes.

Edgar Barroso: Sin duda no tengo la menor duda. Ahora, ricardo siéntete muy relajado, es muy informal. Esto lo que importa es oír cómo piensas qué es lo primero que se te viene a la mente, porque tú, claro, estás muy envuelto en los proyectos, estás en una parte importantísima como Presidente del Consejo, a

Edgar Barroso: pues representas la visión más amplia del tate de Monterrey. En este caso vamos a hablar más del campus, pero sí nos interesa ver esta mirada más de trascendencia de impacto y, sobre todo, de lo que vamos a vivir hacia el futuro con los valores de Don Eugenio.

Edgar Barroso: Entonces la idea es capturar tu pensamiento tal como viene, no te no te preocupes de que si es una respuesta corta, larga, buena, mala, eso no importa. Lo que importa es escucharte. Así que imagínate que estamos en un cafecito, y estamos platicando sobre cómo vamos a ver el 2 030 en el campus. Entonces voy a empezar con una pregunta muy sencilla, que es

Edgar Barroso: Ricardo, ¿Cómo ves o cómo te imaginas al campus en 2 030 y con vistas a 2 035.

Ricardo Saldívar: Pues, quisiera compartir que mi primera reflexión en relación a esta pregunta es un campus insignia, un campus emblemático

Ricardo Saldívar: y que tal vez tiene que ver y y

Ricardo Saldívar: con la con con la génesis, con la historia, con los orígenes.

Edgar Barroso: Mhm.

Ricardo Saldívar: Del Tech, que es fundado en 1 943. Hace 82 años.

Ricardo Saldívar: en la ciudad de Monterrey y al paso de los años de las décadas, incluyendo aquellas en las que

Ricardo Saldívar: decidimos, como institución, ir agregando presencia al tecnológico de Monterrey en otras ciudades del país.

Ricardo Saldívar: pues el campo de Monterrey siempre dijéramos, está a la vanguardia.

Edgar Barroso: Mhm: Claro.

Ricardo Saldívar: En y Y y es así porque porque la sociedad creo que así

Ricardo Saldívar: lo lo lo lo ha querido. Lo ha decidido En entonces veo un campus creciente.

Ricardo Saldívar: Y cuando algo creciente estoy pensando en las huellas de su infraestructura física.

Edgar Barroso: Porque.

Ricardo Saldívar: Todos nosotros sabemos de múltiples proyectos sueños y que tenemos para el campus

Ricardo Saldívar: a raíz, yo diría, de la

Ricardo Saldívar: de la decisión de construir el distrito Tec

Ricardo Saldívar: y que no va a dejar de sorprendernos

Ricardo Saldívar: al paso de los años, cuando dentro de 10 años volteamos hacia atrás y veamos esas huella de infraestructura como continúa cambiando. Así como ha cambiado en la última década, lo seguirá haciendo. Los veo, veo, Veo ahí es donde me refiero a un campo, su insignia.

Edgar Barroso: Mhm.

Ricardo Saldívar: De vista de ser el primero en relación a los demás, sino de asegurar que, como institución.

Ricardo Saldívar: nos estamos exigiendo ir a la vanguardia en técnicas de educación, en experiencia universitaria, en formación de valores y

Ricardo Saldívar: y y, y de nuevo, creo que tiene que ver mucho con el origen fundacional de la institución, los valores bajos, los cuales fue establecida

Ricardo Saldívar: y que, y que hemos mantenido y vivido por décadas, entonces veo también un campus aspiracional.

Edgar Barroso: Mhm.

Ricardo Saldívar: Aspiracional, como lo ha sido por décadas para padres de familia, de que sus alumnos estudien en este campus.

Edgar Barroso: Mhm.

Ricardo Saldívar: Como para los propios estudiantes, ya sea que sean de Monterrey o de otras partes de México o del extranjero. Así lo ha sido. Lo vemos en cada ceremonia de graduación.

Ricardo Saldívar: Cuando se hace la pregunta: pónganse de pie aquellos quienes vinieron de otra ciudad del país se levanta. Tal vez el 70, el 80 por 100 de los muchachos que se están graduando.

Ricardo Saldívar: Entonces, en ese sentido, lo veo también muy global de atraer al mejor talento

Ricardo Saldívar: local, nacional e internacional. También vemos, como siempre aquí, este campus se distingue de nuevo hablando de campos insignia y la vanguardia en base a a a que a que el campus atrae el interés

Ricardo Saldívar: de estudiantes de todo el mundo locales nacionales de Latinoamérica, pero también de otros muchos países de este continente o de otros continentes.

Ricardo Saldívar: y

Ricardo Saldívar: y creo que Quisiera también agregar que veo un campus en donde hemos continuado avanzando en algo que nunca terminaremos de alcanzar

Ricardo Saldívar: la excelencia académica siempre retándonos buscando nuevas y más productivas formas de formar al alumno a raíz de la

Ricardo Saldívar: de lanzamiento del modelo educativo intec 21, Creo que hemos dado un gran paso.

Edgar Barroso: En esta dirección, a comprometernos.

Ricardo Saldívar: O en la sociedad, a formar alumnos

Ricardo Saldívar: que no solamente conocen la disciplina que han decidido estudiar, sino también, y

Ricardo Saldívar: les ha permitido desarrollar una serie de competencias que son fundamentales para el desarrollo de su

Ricardo Saldívar: vida profesional y de su vida en general.

Ricardo Saldívar: Por lo tanto, la capacidad que ellos tengan de transformarse, de transformar a la comunidad.

Ricardo Saldívar: En veo un campus que continúa impulsando la innovación y el emprendimiento.

Edgar Barroso: Mhm.

Ricardo Saldívar: Algo que

Ricardo Saldívar: que por siempre hemos tenido, pero que pienso que hemos buscado reforzar de manera decidida en el pasado reciente

Ricardo Saldívar: y que.

Ricardo Saldívar: y que es fundamental para la transformación de de la vida de la de la sociedad, el el el cómo nuestros egresados sean capaces

Ricardo Saldívar: insertarse en la fuerza laboral, pero también o también de iniciar nuevos emprendimientos.

Edgar Barroso: Claro.

Ricardo Saldívar: Que sean factores multiplicadores de la cantidad de empleos

Ricardo Saldívar: que ese emprendimiento va a ser capaz de generar en donde nuestro egresados busca no solamente él o ella, tener una carrera exitosa en lo individual, sino a través de un esfuerzo emprendimiento eficaz que, al paso del tiempo pueda ser exitoso, sostenible, crece

Ricardo Saldívar: y y multiplica el número de empleos en 10, en 20 en 100 veces no sé cuántas.

Ricardo Saldívar: de tal manera que ahí es donde sea ese efecto multiplicador al cual he hecho referencia. Y por último.

Ricardo Saldívar: veo un campus en donde se viven y se inculcan los valores y de ética.

Edgar Barroso: Mhm.

Ricardo Saldívar: Civilidad, de sustentabilidad, de inclusión de humanismo y en los que creemos

Ricardo Saldívar: que, repito, bajo los cuales lo funda la institución y que

Ricardo Saldívar: y que nuestros egresados no solo salen al mundo y teniendo un dominio.

Edgar Barroso: Mhm.

Ricardo Saldívar: Sino también una serie de competencias adquiridas en

Ricardo Saldívar: con capacidades para insertarse en la fuerza laboral o bien emprender con efectos multiplicador.

Ricardo Saldívar: con una vocación de estar innovando, teniendo pensamiento crítico, curiosidad intelectual y

Ricardo Saldívar: con un alto compromiso con valores con valores éticos de civiles o cívicos y humanistas.

Edgar Barroso: Muchísimas gracias. Ricardo Sí, es completamente de acuerdo, y eso se conecta con la siguiente pregunta que tenemos que es qué representa el campus Monterrey para el Consejo y para, el, sobre todo, para el legado de don Eugenio que viendo la fotografía detrás de ustedes es impresionante. ¿dónde estamos ahora? No

Edgar Barroso: has hablado mucho. También estuve leyendo algunas notas de ti sobreponer la persona al centro. ¿cómo se vive eso en ese campus que queremos ver en 2 030.

Ricardo Saldívar: Y mira, sí, A veces pienso, muchas veces lo he hecho.

Ricardo Saldívar: En qué pes qué pensarías, don eugenio, casada.

Edgar Barroso: Mhm.

Ricardo Saldívar: Si volviera, sí para este mundo y mira lo que ha pasado de y

Ricardo Saldívar: y estoy convencido de que se sorprenderían muy positivamente.

Ricardo Saldívar: Pero, por otro lado, también pienso que él

Ricardo Saldívar: tenía esa esa capacidad de ver a largo plazo. Era un visionario.

Edgar Barroso: Mhm.

Ricardo Saldívar: Que el grado sorpresa a lo mejor no sería total.

Ricardo Saldívar: porque a lo mejor él sabía que era como una una bolita de nieve que había que crear

Ricardo Saldívar: y echarla a rodar por la pendiente y que iba a agarrar tracción, tamaño, velocidad, inercia.

Ricardo Saldívar: Creo que estaría orgulloso. Estaría sorprendido y

Ricardo Saldívar: creo que quienes hemos pasado por aquí en distintas facetas hemos buscado honrar su legado.

Ricardo Saldívar: Este legado me permite formar personas como las que hemos hablado en la pregunta anterior, y

Ricardo Saldívar: y ese asunto de poner la persona al centro es fundamental, pero es fundamental hoy, y lo ha sido siempre, y lo será, espíritu de don eugenio barzada. Cuando él hablaba de que lo más importante era

Ricardo Saldívar: el ser humano.

Edgar Barroso: Mhm.

Ricardo Saldívar: Y creo firmemente que la persona del centro significa que yo no hago nada.

Ricardo Saldívar: que no es relevante para el que está enfrente de mí.

Edgar Barroso: Mhm.

Ricardo Saldívar: Esta misma entrevista el día de hoy, o esta conversación.

Ricardo Saldívar: Yo lo acepté porque es relevante para ustedes.

Ricardo Saldívar: No es relevante para mí también lo es, Pero no lo hice porque es relevante para mí. Lo hago porque es relevante para la institución para que la forman. Para quienes estamos aquí reunidos en esta sala el día de hoy. Entonces la persona del centro es entender

Ricardo Saldívar: y en este caso, la persona del centro en un campus, pues es el estudiante, pero también es el maestro. Es el investigador.

Edgar Barroso: Es.

Ricardo Saldívar: Que nos ayuda en un área de apoyo

Ricardo Saldívar: es que nos ayuda a mantener las instalaciones de la mejor manera. Todos somos personas.

Edgar Barroso: Mhm.

Ricardo Saldívar: Cada quien jugamos un papel distinto

Ricardo Saldívar: en la comunidad, pero todos somos personas y poner la persona del centro significa que quien está junto a mí o frente a mí

Ricardo Saldívar: es más importante que yo.

Edgar Barroso: Y lo que yo.

Ricardo Saldívar: Haga cuando estoy con él o con ella, es en función de servirle de la mejor manera a quien está enfermo si es el alumno, pues entender que le inquieta que le satisface.

Edgar Barroso: Claro.

Ricardo Saldívar: Escuchar sus ideas e innovación, alimentarnos de lo que el estudiante piensa para enriquecer nuestros programas, Lo mismo con los profesores. Pero lo mismo con quien sea de toda persona, tiene ideas.

Ricardo Saldívar: y esas ideas merecen ser escuchadas

Ricardo Saldívar: y valoradas en la medida de lo conducente: puestas en marcha.

Edgar Barroso: Sí. Y y sobre todo, en este momento histórico, no en el que estamos viendo cosas que no nos no habíamos visto en mucho tiempo este el tema de los valores y de de poder entender al otro y de servir al otro me parecen ideas súper relevantes Y y como dices tú a prueba de tiempo.

Edgar Barroso: ahora vamos un poquito a cómo ves la relación entre el campus y el sector productivo y la sociedad en el futuro. ¿cómo te gustaría que cambiara o que mejorara esa relación entre el campus específicamente y el sector productivo y la sociedad.

Ricardo Saldívar: Una gran pregunta. Creo que

Ricardo Saldívar: quisiera empezar diciendo lo que he escuchado en distintas ocasiones en distintos campus, en distintas ciudades.

Ricardo Saldívar: Y lo he escuchado de líderes locales

Ricardo Saldívar: y más o menos la frase es, y

Ricardo Saldívar: hay un Monterrey antes de Tec y otros después del Tec.

Edgar Barroso: Mhm.

Ricardo Saldívar: Yo creo que esto aplica el campus.

Ricardo Saldívar: y muy probablemente todos los campus que tenemos en distintas partes del país, pero enfocándonos, acá pues Monterrey.

Ricardo Saldívar: sin duda

Ricardo Saldívar: el respeto que tiene la institución y nuestro campus, que yo creo que, aunque nadie lo diga o tal vez no lo hayamos escuchado. Creo que sí Se ve como un campus emblemático.

Edgar Barroso: No, claro.

Ricardo Saldívar: Es como imaginarte a la compañía Apple sin imaginarte la manzanita mordida.

Edgar Barroso: Sí, Sí.

Ricardo Saldívar: Yo no me puedo. Yo no puedo pensar como alguien que conoce del Tec que alguna vez escuchó el tec, pudiera imaginarlo sin el campus Monterrey.

Edgar Barroso: Mhm.

Ricardo Saldívar: Eso es ser emblemático.

Edgar Barroso: Mhm.

Ricardo Saldívar: No quiere decir que tenga que ser el único emblema

Ricardo Saldívar: yo. ¿qué más quisiera que todos los campos fueran emblemáticos, pero este lo es.

Edgar Barroso: Sí.

Ricardo Saldívar: Y y y en ese sentido, creo que goza del respeto

Ricardo Saldívar: sobre todo el respeto y la credibilidad.

Edgar Barroso: Mhm.

Ricardo Saldívar: De la comunidad en general en la

Ricardo Saldívar: población civil de las universidades que están en el entorno de la comunidad empresarial

Ricardo Saldívar: del sector público. Yo creo que el cronológico y este campus goza, y ha sido así por muchas décadas.

Ricardo Saldívar: Yo diría desde que inició.

Edgar Barroso: Mhm.

Ricardo Saldívar: Donde nace con un con un gran propósito, un propósito genuino y noble.

Edgar Barroso: Sí.

Ricardo Saldívar: Y que se ha mantenido. Creo que eso le ha dado a a este campus ese halo de respeto de la sociedad en general y de los sectores que la conforman. Creo que

Ricardo Saldívar: hemos sido capaces de vincular

Ricardo Saldívar: muchos esfuerzos de este campus con la comunidad productiva de Nuevo León del Estado de Nuevo León, y

Ricardo Saldívar: creo que cada vez en mayor grado.

Edgar Barroso: Mhm.

Ricardo Saldívar: Y a la vez, pienso que todavía en grado insuficiente.

Ricardo Saldívar: y lo digo no como una crítica, sino como reflejo de una aspiración en donde creo que el nivel de vinculación.

Ricardo Saldívar: el tecnológico Monterrey, a través de este campus puede lograr con la comunidad región Montana en es muy alto.

Ricardo Saldívar: muy alto. ¿por qué? Porque estamos estamos cada vez embarcándonos en nuevos proyectos y estoy pensando en innovación, en investigación

Ricardo Saldívar: que siempre hemos dicho es investigación aplicada que busca resolver un problema específico de la comunidad de la sociedad y, en ese sentido si veo un test, un campus

Ricardo Saldívar: que si lo traslado al 2 030 o al 2 035 a los vínculos

Ricardo Saldívar: por el sector productivo van a ser mucho más numerosos.

Edgar Barroso: Mhm.

Ricardo Saldívar: Y mucho más fuertes ya son el día de hoy.

Edgar Barroso: Muy bien.

Edgar Barroso: Y ya por último, yo tengo una pregunta pequeñita antes de pasar a la siguiente sección de los cómos. Pero una una rápida que sí es importante es que te haría sentir orgulloso de este campus en 2 035

Edgar Barroso: qué qué cosas dirías? Si yo viera esto del campus, estaría súper orgulloso y súper contento.

Ricardo Saldívar: Qué buena pregunta. Y Y en realidad no sé, me Se me vienen a la mente distintas ideas, pero siempre hablamos

Ricardo Saldívar: de que lo que más orgullo nos produce en el Tec son los egresados.

Edgar Barroso: Mhm.

Ricardo Saldívar: Y Y entonces lo que me gustaría es seguir viendo al paso de los años y por décadas

Ricardo Saldívar: cómo los egresados

Ricardo Saldívar: han abrazado y hecho posible el propósito de nuestro grupo educativo de transformar la vida de las personas y de las comunidades a través de la educación, empezando por las de ellos mismos, pero también la de sus comunidades.

Edgar Barroso: Mhm.

Ricardo Saldívar: Y y entonces quisiera ver a un mayor número de emprendiendo negocios.

Ricardo Saldívar: ayudando o involucrándose en proyectos sociales e incorporándose a la fuerza del servicio público. Y en todos esos órdenes, con el más alto código de ética y de valores.

Edgar Barroso: Mhm.

Ricardo Saldívar: Que.

Edgar Barroso: Mhm.

Ricardo Saldívar: Y y muy posiblemente esos egresados

Ricardo Saldívar: que me haría sentir más orgulloso que lo que ya estoy en el 2 000. 30 2 000. 35 ya salieron de este campus.

Edgar Barroso: Mhm.

Ricardo Saldívar: Porque tal vez ese fruto lo están dando cuando están en sus 30.

Edgar Barroso: Mhm.

Ricardo Saldívar: Cuarentas o en sus 50, lo cual significa que se han graduado aquí hace ya algunos años.

Ricardo Saldívar: Pero pero también me va a dar mucho orgullo el saber que los que se siguen formando

Ricardo Saldívar: y que tal vez tendrán impacto hasta el 2 050 2 060 en

Ricardo Saldívar: también están nutriéndose de esta manera, de tal manera que el aporte del Tec

Ricardo Saldívar: de este campus a la sociedad sea continuo.

Edgar Barroso: Sea continuo y creciente.

Ricardo Saldívar: Como lo ha sido por 82 años, pero que lo siga haciendo por muchas

Ricardo Saldívar: por muchos años más.

Edgar Barroso: Qué bonito!

Ricardo Saldívar: Más orgullo. Me daría ver como como nuestros egresados, con sus hechos, con sus trayectorias.

Ricardo Saldívar: nos hacen ver que lo que

Ricardo Saldívar: algún día decidimos que pasase aquí a la institución y sigue dando frutos.

Edgar Barroso: Sí. Qué bonito, Porque es este día de la acumulación y el crecimiento, no del impacto que van dejando. Pues Bueno, yo, como productor del Tec, también me siento parte del Tec. Y Y si lo veo en mis alumnos, y es increíble, la verdad es que es muy bonito.

Edgar Barroso: Ahora pasemos rapidísimo a la parte de cómo llegamos ahí. Como llegamos a esa visión que nos acaba de describir que tendría que pasar, que es lo primero que se te viene a la mente. Ricardo.

Ricardo Saldívar: Mira, también es muy buena pregunta.

Ricardo Saldívar: Siempre todos tienen algo que hacer todas las partes involucradas en algo. Por supuesto, la institución.

Ricardo Saldívar: Hace un momento terminé una reunión con David Garza y hablábamos de cómo nos estamos acercando.

Ricardo Saldívar: Mhm.

Ricardo Saldívar: Estamos incorporando

Ricardo Saldívar: el máximo potencial que la inteligencia artificial nos ofrece al grado que la alcanzamos a comprender y aprovechar.

Edgar Barroso: Mhm.

Ricardo Saldívar: En nuestros modelos de enseñanza.

Ricardo Saldívar: Entonces yo creo que por un lado está la parte del del desarrollo de nuestro contenido académico permanente.

Edgar Barroso: Mhm.

Ricardo Saldívar: Eso nunca termina de estar y concluido.

Ricardo Saldívar: Y siempre siempre hay algo nuevo que incorporarle.

Edgar Barroso: Mhm.

Ricardo Saldívar: Creo que nuestros profesores, que sin duda es algo que nos distingue, nos enorgullece que siguen teniendo esa

Ricardo Saldívar: esa vocación y ese compromiso incondicional con la educación. Lo hemos visto en muchísimos profesores que lo han hecho por décadas y y que siguen entregando su

Ricardo Saldívar: su capacidad y su vida

Ricardo Saldívar: a la educación, haciéndolo de una manera comprometida para continuar incorporando, actualizándose ellos mismos en en en nuevas técnicas de enseñanza, enseñarle al alumno no solo la la materia, disciplinar, pero también

Ricardo Saldívar: modelándole con su actuar. El cómo vivir con estos valores de los que hablábamos más temprano, sentido cívico, alto código de ética con con sentido humanista. Veo al alumno también

Ricardo Saldívar: con más hambre. Fíjate.

Edgar Barroso: Mhm.

Ricardo Saldívar: Quiero ver al alumno con más hambre, siento que la tiene. Yo cada vez inicio un semestre.

Ricardo Saldívar: Ya tengo varios semestres de que tengo una reunión con con jóvenes que están empezando el semestre. Están entrando la carrera, pero también hay muchachos de segundo tercer cuarto semestre y y veo al al estudiante el té con hambre.

Edgar Barroso: Mhm.

Ricardo Saldívar: Hambre, de de hacer las cosas bien, de crecer, de desarrollarse, de comerse el mundo, como dicen en en una

Ricardo Saldívar: en un vocal.

Ricardo Saldívar: Y Y creo que tenemos que seguir teniendo ese alumno con hambre con hambre de de querer transformar al mundo de como tú que estás allá en Suiza, ahorita. No sé dónde está físicamente. Tal vez.

Edgar Barroso: En Suiza.

Ricardo Saldívar: Y y has hecho un desarrollo, un emprendimiento, un startup utilizando tecnología. Bueno, yo quisiera que algún día me entrevistes dentro de 5 años y que me digas por lo mejor que me permitas a mí entrevistarte. Yo.

Edgar Barroso: Sí.

Ricardo Saldívar: Que me digas qué pasó en estos 5 años? Bueno, ese tipo de estudiante que tiene hambre, que tiene empuje, que tiene deseos de hacer algo diferente, de crear.

Edgar Barroso: Mhm.

Ricardo Saldívar: Algo que que que que va a servir mejor a los procesos de una institución o a la humanidad.

Ricardo Saldívar: Yo creo que es la suma de todos quienes, o sea, la comunidad entera. La integramos ex alumnos, alumnos, profesores, investigadores, médicos

Ricardo Saldívar: y todo. Yo creo que el el cómo cómo hacer realidad esta visión es como cada quien, desde el rol que nos toca jugar, estamos quebrandonos la cabeza genuinamente cada día, haciendo nuestro mejor esfuerzo para que lo que mañana pasa, lo que pasa entre algunos meses

Ricardo Saldívar: o años es mejor que lo que antes tenía.

Edgar Barroso: Claro.

Edgar Barroso: Muchísimas gracias. Justo. Eso tiene que ver con la próxima vez sobre prioridades.

Edgar Barroso: Si tú tuvieras que si tú tuvieras que decidir a que apostarle en estos próximos 4 años a 2 030, con miras a 2 035 investigación, salud, emprendimiento, aprendizaje para toda la vida. Sé que también es un tema que te interesa mucho.

Edgar Barroso: Cuáles serían críticos o en qué te gustaría que María Adrián y el campus se fijaran en estos años. ¿cuál serían tus prioridades? Claro.

Ricardo Saldívar: Sí, Pues sí, es es muy importante también esto que tú ahora preguntas y y tiene que ver con

Ricardo Saldívar: Mhm, rasgos distintivos de la institución.

Ricardo Saldívar: como son la innovación y el emprendimiento.

Edgar Barroso: Mhm.

Ricardo Saldívar: Eso es muy importante. Hablaste del aprendizaje para el futuro.

Ricardo Saldívar: Hemos visto que la necesidad de las empresas

Ricardo Saldívar: y de quienes tienen algún trabajo o son emprendedores en materia de adquirir nuevos conocimientos. Está ahí. Lo estamos viendo cómo se acercan más más cada año, pidiéndonos apoyo en continuar avanzando.

Edgar Barroso: Mhm.

Ricardo Saldívar: Aprender nuevas cosas.

Ricardo Saldívar: Yo yo creo que la investigación es fundamental.

Edgar Barroso: Mhm.

Ricardo Saldívar: Este. Somos una institución reconocida globalmente

Ricardo Saldívar: por nuestra capacidad de formación académica o de enseñanza.

Edgar Barroso: Mhm.

Ricardo Saldívar: Debemos continuar manteniendo eso. Debemos de continuar desarrollando nuestro músculo A y de investigación.

Ricardo Saldívar: Nos permite apoyar a la sociedad de una manera a la Comunidad de una mejor manera en resolver necesidades que tienen

Ricardo Saldívar: en soluciones que requieren, que nos va a permitir vincularnos mejor con el sector productivo como hace un rato.

Ricardo Saldívar: no, y que todo ello sumado es lo que nos va a permitir pensar que estamos transformando

Ricardo Saldívar: mejor la vida de la Comunidad.

Ricardo Saldívar: Creo que por ahí va.

Edgar Barroso: Va

Edgar Barroso: y, por ejemplo, en temas de cultura, ¿Qué cambios culturales necesitamos para esa transformación y qué qué? ¿qué ¿Qué podríamos mejorar en temas de cultura en el Tec, según tu visión, Ricardo.

Ricardo Saldívar: Pues mira, Yo creo que el principal reto cultural está en 1 mismo en cada persona.

Ricardo Saldívar: Como decíamos la comunidad Tec, que es la suma de.

Edgar Barroso: Mhm.

Ricardo Saldívar: Cientos de miles de personas y al final del día es como cada persona vive

Ricardo Saldívar: y contribuyen a lo que los demás hacen

Ricardo Saldívar: a que la Comunidad sea más fuerte, a que la Comunidad crezca a que a que la Comunidad aporte a que la Comunidad sea más y más respetada, entonces yo creo que el cambio cultural yo lo veo

Ricardo Saldívar: más centrado en la persona misma. Se pregunta a sí mismo a sí misma con un sentido de autocrítica, de un alto nivel de responsabilidad. El el qué más puedo hacer yo.

Edgar Barroso: Mhm.

Ricardo Saldívar: Por supuesto, como institución, siempre tendremos oportunidades también de mejora en nuestra cultura. Creo que las encuestas

Ricardo Saldívar: que hemos llevado a cabo avalan que

Ricardo Saldívar: nuestra Comunidad cree que contamos con la cultura adecuada, pero sin duda de nuevo, bajo ese matiz, de preguntarnos cómo podemos hacer tal o cual proceso mejor.

Ricardo Saldívar: ¿cómo puedo yo servir a alguien mejor que ayer.

Edgar Barroso: Claro.

Ricardo Saldívar: Esto vamos a hacer que esta cultura continúe desarrollándose y sea única.

Edgar Barroso: Es muy, es muy interesante lo que dices, porque en teoría de sistemas complejos, pues tú no puedes controlar lo que cada agente del sistema puede hacer. Pero lo que sí puedes hacer

Edgar Barroso: es que si nuestros alumnos, nuestra comunidad, tienen los valores, el sistema operativo correcto. En este caso, los valores de don Eugenio. Este aspecto ético cívico que acabas de mencionar.

Edgar Barroso: entonces eso va a hacer que cada persona actúe en favor de todo el sistema. Y es muy interesante verlo al revés, no de plantear una cultura, sino que desde la persona desde el individuo. Se genere esa cultura hacia afuera. Es muy bonita. La idea.

Ricardo Saldívar: Hecho de ver. Yo creo que esto que comenta ricardo y que tú comentas es algo que pues no es nuevo pero ahorita. Se le llama que una persona tiene agencia.

Edgar Barroso: Mhm.

Ricardo Saldívar: Cuando una persona tiene agencia, que es algo que acuña este albert Baldura es esa persona que es capaz de estar reaccionando positivamente al sistema de.

Edgar Barroso: Es el.

Ricardo Saldívar: Inventar entonces. Y eso es una cultura que es un mindset que que hay que desplegar. No.

Edgar Barroso: Exactamente y yo ya nada más. Tengo una pregunta. Y después me gustaría que Adrián te contara un poco de si algunos de los proyectos específicos que tú quisieras mencionar alguna alguna opinión o alguna algo de tu visión también? Ricardo

Edgar Barroso: en 2 cosas, una.

Edgar Barroso: Estos modelos de inteligencia artificial tienen una ventaja sobre nosotros que pueden tener una memoria prácticamente infinita.

Edgar Barroso: Entonces pueden recordar todo, pueden recordar esta conversación en 15 años perfecta desde desde el principio hasta el final, puede analizar las emociones. Puede analizar el contexto todo todo todo.

Edgar Barroso: Si tú, si un modelo de inteligencia artificial en 2 030 tuviera que aprender algo de esta conversación.

Edgar Barroso: ¿Qué principio ético o de liderazgo quisieras transmitirle a ese sistema.

Ricardo Saldívar: ¿

Ricardo Saldívar: El humanismo, el pensar en los demás.

Edgar Barroso: Mhm.

Ricardo Saldívar: En servir a a los demás.

Edgar Barroso: Pua.

Ricardo Saldívar: Muy bien, muy conciso y superpoderoso.

Edgar Barroso: Hay algo que no hayamos tocado Ricardo que te gustaría mencionar en este yo es la última pregunta. María Adrián, para que tú ya también puedas mencionar lo de los proyectos. Pues si hay algo que no, no te pregunté, pero que es súper importante, por favor.

Ricardo Saldívar: Bueno, mira, ya ya estamos concluyendo Ricardo, Sólo comentarte que el plan de campus Monterrey hay 4 pilares transformadores que hemos visto con David y Juan Pablo.

Ricardo Saldívar: Uno de ellos tiene que ver con la innovación, la investigación del emprendimiento

Ricardo Saldívar: que se viva dentro del campus. Y con el distrito de innovación. Ahora, con expedición del Pop, lo queremos que pase alrededor del distrito Tec. Ese es un pilar. El segundo: queremos que los posgrados presenciales

Ricardo Saldívar: en el campus Monterrey evolucionen y todavía tengan mayor presencia, porque son los que nos pueden ayudar mucho a pensar en ser una prueba del tipo para para Estados Unidos, los posgrados presenciales.

Ricardo Saldívar: El otro tercero fue el tercero es la selectividad en la selectividad. Queremos atraer al mejor talento de estudiantes y al mejor talento también de profesores

Ricardo Saldívar: como ejemplo ahorita en en cumbres en la prepa cumbres.

Ricardo Saldívar: ya topamos. Ya llegamos en primero de enero a la meta de tamaño, ya la detuvimos

Ricardo Saldívar: y seleccionamos solo los mejores. Primero

Ricardo Saldívar: que resultó la prepa cumbres es la mejor en la cruz de todo el país.

Ricardo Saldívar: Tienen un 50 por 100 de producciones muy arriba. El promedio es 40.

Ricardo Saldívar: Y con esto que hicimos subió el 67

Ricardo Saldívar: que va, y ya está. Ya no hay ya no hay cuope.

Ricardo Saldívar: Entonces vamos a ir atrayendo estratégicamente más talento. Ese es el tercer pilar. Y vamos con proyectos de este año hacia el 2 030 que queremos seguir incrementando más.

Ricardo Saldívar: y el cuarto en la facultad que Juan Pablo nos pidió también la facultad de excelencia

Ricardo Saldívar: con los profesores que tenemos este David no se decía, quiero que cambien su maine zeta que se coman el mundo, los profesores, tú le dijiste, Ahorita. También quiero que el alumno se coma el mundo, entonces también el profesor queremos que eso lo contagie

Ricardo Saldívar: y traer también, por supuesto, profesores extranjeros y tener una diversidad de facultad, entonces son 4: el distrito de innovación

Ricardo Saldívar: posgrados presenciales: la selectividad y la facultad. Esos son los pilares transformadores que queremos que se que muevan a este campus insignia del 2 030.

Ricardo Saldívar: Sobre eso. Qué te parece? Es algo más que quieras arreglar. Eso es muy completo. Parecen muy completos esos 4 pilares.

Ricardo Saldívar: Creo que engloban las estrategias de la institución, que son perfectamente aplicables al campus de alguna manera. Por ejemplo, pensaba ahorita que hablabas del tercero de esos 4 factores de la selectividad, que es algo que la institución a nivel global hemos venido haciendo ya desde hace más de 10 años pero que.

Ricardo Saldívar: y no por el ejemplo que me ponías de la prepa cumbres. Se comprueba.

Edgar Barroso: Mhm.

Ricardo Saldívar: Una vez que llegas concierto número

Ricardo Saldívar: de matrícula total o de nuevos ingresos, la oportunidad está en asegurar

Ricardo Saldívar: que vienen los mejores. Yo nunca hablábamos más temprano de que

Ricardo Saldívar: del cambio cultural de cada persona buscar ser mejor.

Ricardo Saldívar: Hablábamos también de la excelencia académica. Yo creo que estos 4 pilares, Mhm.

Ricardo Saldívar: Pues es un auto, es un mandato autoimpuesto

Ricardo Saldívar: de buscar avanzar en la dirección correcta.

Ricardo Saldívar: o sea, cuando habla de innovación, investigación y emprendimiento, no cabe duda que que

Ricardo Saldívar: es una evidencia estratégica aprobada por el Consejo, que tenemos que perseguir y abrazar, y que hemos habilitado la infraestructura necesaria en el campus para pensar que eso lo vamos a seguir haciendo.

Ricardo Saldívar: lo de ser un Air One Time University De nuevo está en línea con la investigación, y para eso sabemos que requerimos un cierto número de estudiantes.

Ricardo Saldívar: el posgrado

Ricardo Saldívar: que que que nos dan la seguridad de que estamos avanzando en la dimensión, la facultad de excelencia y que todos los maestros, todos los profesores

Ricardo Saldívar: transmitan esa hambre a los alumnos me parece fundamental, Y la cuarta ya son con la selectividad. Ya entra, es el distrito innovación, posgrados, selectividad y la facultad son esas cosas.

Ricardo Saldívar: Yo lo veo muy completo y fíjate que va de la mano porque lo estamos viendo en la visión, 20 30

Ricardo Saldívar: para ir alineados Este, y, además, quiero comentarte que el valor que tiene esta conversación contigo ricardo aparte que lo que tú pienses digas, pues por supuesto que siempre se va a ser tomado en cuenta, pero coincide mucho con las visiones de Juan Pablo y David.

Ricardo Saldívar: Este, Pero sí quiero rescatar que en este momento, particularmente aparecen los valores.

Ricardo Saldívar: la ética, la ciudadanía y el urbanismo.

Ricardo Saldívar: Este es este elemento.

Ricardo Saldívar: Sí, es muy valioso y y no está tan presente como

Ricardo Saldívar: entonces ahorita, Lo estás dejando un elemento que se me hace muy importante. Gente que hay que gestionar, ¿verdad? Me ha dicho que haya salido esto en la conversación.

Ricardo Saldívar: porque creo que el Ted ya hacemos mucho al respecto.

Ricardo Saldívar: pero pudiera parecer que es suficiente, y tal vez no lo es

Ricardo Saldívar: Yo, en ocasiones, de manera anecdótica. Fuera del Tech

Ricardo Saldívar: habido personas que me piden órganos asegúrense del tecnológico. Esta universidad tan prestigiada en México, asegúrense estar formando gente

Ricardo Saldívar: con valores.

Ricardo Saldívar: Y a veces esta petición que me hacen, La siento

Ricardo Saldívar: como si fuese un reclamo que no lo estamos haciendo.

Edgar Barroso: Mhm.

Ricardo Saldívar: Y yo lo que sí lo estamos haciendo. Yo he tenido conversaciones con Juan Pablo no

Ricardo Saldívar: tendientes a entender cómo es que en todas las escuelas hay

Ricardo Saldívar: contenidos académicos que nos permiten pensar que estamos despertando en nuestros alumnos. Este compromiso con la ética con la ciudadanía. Y

Ricardo Saldívar: y es que

Ricardo Saldívar: el otro decíamos: sí, la la el humanismo, la ciudadanía y el humanismo en

Ricardo Saldívar: Y y aunque no lo puedo ahorita, ejemplificar de manera detallada.

Ricardo Saldívar: Cuando he tenido este tipo de pláticas con gente como Juan Pablo, me quedo tranquilo que lo estamos haciendo.

Ricardo Saldívar: pero pero sí creo que pudiera haber espacios para preguntarnos si es

Ricardo Saldívar: en suficiente grado o debiéramos, como dicen, subir una Rayita en

Ricardo Saldívar: yo creo que el test lo tiene.

Ricardo Saldívar: Creo que nuestros alumnos y egresados lo tienen.

Ricardo Saldívar: pero tenemos que seguir buscándolo, porque estamos estamos hoy en un mundo tan individualista.

Edgar Barroso: Tan autónomo.

Ricardo Saldívar: Que que pienso que es fácil, quiso asociarse claro

Ricardo Saldívar: que las personas que están a nuestro alrededor fíjate que, en efecto, sí se hacen, se viven.

Ricardo Saldívar: pero el el estudiante vive en un sistema

Ricardo Saldívar: en una vida de este caso del campus y la vida del campus no solo es lo que venimos de clase.

Ricardo Saldívar: sino todo lo que se ven alrededor hasta en los equipos representativos, en los eventos y en los congresos.

Edgar Barroso: Claro.

Ricardo Saldívar: Consagraron. Dicen qué es lo que más te gustó el Tec es la vida estudiar la vida como estudiante, y y también lo las clases, entonces tiene que ser una una gestión del del sistema que lo viva que lo vean.

Ricardo Saldívar: Eso es algo, entonces creo que sí. Hay que subir la la rayita y hacerlo más como una cultura, no como una parte solamente académica. La otra es que yo también escuchando a la comunidad.

Ricardo Saldívar: nos creen. Todos los creen que hablamos de liderazgo, que formamos líderes nos creen de rendimiento, innovación, ciencia.

Ricardo Saldívar: pero no nos creen tan rápidamente

Ricardo Saldívar: que formamos personas con valores humanistas.

Ricardo Saldívar: Tenemos argumentos para decir que sí,

Ricardo Saldívar: pero fíjate cómo cómo que, pero ese gato, como que muchas cosas no el entorno, nos dice.

Ricardo Saldívar: pueden hacer más. Así es.

Ricardo Saldívar: Y lo que yo creo que hay que hacer lo que está en su visión, pero también tenemos que permear con los hechos

Ricardo Saldívar: que estamos moviéndonos en una parte sana ética ciudadana, porque el mundo lo está reclamando.

Ricardo Saldívar: Y este, esos son los egresados que tú dijiste que quieres ver que no solo sean exitosos, pero que también sean personas que inspiren a más.

Ricardo Saldívar: Pero eso hay que hay que gestionar esa vivencia de sus partes. Este es el que yo creo que nos dejas. Me hago. Me gusta más el show que ya estoy bien hecho referencia a la experiencia estudiantil, la vida hostil.

Ricardo Saldívar: Alejándonos tal vez de los modelos de hace décadas, en donde el alumno venía a aprender nuevas materias.

Ricardo Saldívar: sacar sus calificaciones, conseguir su título. Hoy, el tenónimo Monterrey. Este campus lo hace a nivel de excelencia.

Ricardo Saldívar: Ofrece un portafolio de actividades extracurriculares

Ricardo Saldívar: y complementarias que son importantísimas para el desarrollo emocional de la persona en cuanto a saber, desenvolverse en distintos sectores.

Ricardo Saldívar: Desarrollar distintas capacidades, no solo en la academia en el deporte, en la en el arte, en lo que cada quien vaya eligiendo como

Ricardo Saldívar: vida estudiantil. Pero hay que fomentar en nuestros alumnos que aprovechen estos años en el Tec para

Ricardo Saldívar: tener ese deseo, ese esa curiosidad intelectual, esa energía, esa vitalidad para para

Ricardo Saldívar: hacer más y más cosas, porque al final de cuentas, ellos se están formando mejor.

Ricardo Saldívar: Entonces, ¿qué bueno que lo menciones, y me parece muy

Ricardo Saldívar: Ricardo. Ya no te quitamos más tiempo este edgar algo que quieras incluir.

Edgar Barroso: Simplemente agradecerte ricardo. Yo, como como miembro de la comunidad, también como profesor, me voy muy inspirado y muy agradecido de tus palabras. Creo que una cosa que a mí yo me llevo también mucho. María Adriana es la idea del génesis.

Edgar Barroso: Es el campus donde todo inició. Fue así. Empezó Ricardo. La entrevista dice: no es la génesis. Es aquí es donde empezó todo.

Edgar Barroso: Y creo que esa idea de decir que nuestros estudiantes, nuestra comunidad, se sienta que ahí empezó y que y que puedes venir a este campus También creo que es increíble. Muchísimas gracias. Ricardo. Te agradezco mucho la oportunidad de platicar contigo.

Ricardo Saldívar: Muchas gracias también por tu tiempo por tu guía, y ha sido una gran oportunidad para mí de hacer esto en equipo.

Edgar Barroso: Muchas gracias gracias a todos.

Ricardo Saldívar: Muchas gracias, Ricardo por tu tiempo y que te mejores. Gracias.

Edgar Barroso: Que estoy muy bien, hasta luego.

Ricardo Saldívar: Gracias hasta luego buen fin a por los

Ricardo Saldívar: muy mal. Esos tan personas que tienen mesita.

## Connections
- [[02-community-ncm]]
