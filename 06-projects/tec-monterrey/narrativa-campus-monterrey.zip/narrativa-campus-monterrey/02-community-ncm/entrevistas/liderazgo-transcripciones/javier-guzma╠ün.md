Javier Guzmán: Bueno, pues ya estamos por aquí. Edgar está Ahorita, José Luis Suiza es donde resido muy Bien, Edgar es profesor de la Escuela de Ciencias Sociales y Gobierno. Este, Y bueno, está viene varias veces a México.

Javier Guzmán: Voy a decir un poquito de cosas, pero tú me corriges. Y digo algo que no es Edgar.

Edgar Barroso Systems: Claro.

Javier Guzmán: Ser. Gracias.

Javier Guzmán: Edgar. Y él es.

Javier Guzmán: pues es músico en un doctorado en composición en Harvard, este y pero es 1 de los profesores que más ha usado la inteligencia artificial de la tecnología.

Javier Guzmán: Este es una de las empresas de L. S. T. Este es un estado ligada al Tec y, desde mi punto de vista, estos profesores desde hace años

Javier Guzmán: tiene mucho más

Javier Guzmán: y tiene una plataforma que es de propia arquitectura de horizontes, que es la base del Escarot. Un poquito de presencia real. Pero yo te dejo a ti la la la voz. Este, la idea es escucharte de una manera muy libre.

Javier Guzmán: no para manejo de vídeos ni redes ni nada. Es uso interno.

Javier Guzmán: Pero bueno, este Edgar conduce la conversación. Y y, bueno, se nos queda como un registro muy, muy valioso para para Tec, en este caso para para el campus. Entonces Edgar te desea la palabra y al.

Edgar Barroso Systems: Sí. Muchísimas Muchísimas gracias. María Adrián, por esa introducción tan amable. Hola, Javier. Ya tengo ganas de conocerte. Joel Canon me ha platicado mucho de ti.

Edgar Barroso Systems: Y bueno, sí, como dice Mari Adrián, estamos, fuimos de la primera generación de V, C, T, de una tecnología que después hicimos una startup. Y la verdad es que nos ha ido muy bien.

Edgar Barroso Systems: Luego te contaré con más calma, pero hoy. Lo más importante es que entiendas por qué estamos aquí, Como sabes, hoy en día

Edgar Barroso Systems: el lenguaje se convirtió en data. Esta información. Ahora son vectores. Funciona. Básicamente son vectores que están por todos lados. Y una de las cosas que está haciendo María Adrián, justo para ver cuál va a ser la estrategia en el campus Monterrey hacia 2 030. Y una de las cosas que ha surgido de estas conversaciones es

Edgar Barroso Systems: también plantear la base para 2 035, no el 2 030 en 4 años que, como sabemos, esto se va súper rápido y más que tener esta entrevista como algo anecdótico o como una entrevista donde vamos a sacar bullet points de aquí. Lo que es importante es que vamos a obtener

Edgar Barroso Systems: tu guía. Y tus vectores de cuáles son las ideas principales, sobre todo en temas, por supuesto, de investigación.

Edgar Barroso Systems: Y una de las cosas que queremos es ver cómo tu experiencia sé que estuviste en Exxon. Te estuvimos estoqueando un poco en el buen sentido, no para para poder tener una conversación más interesante. Pero bueno, como creo que has dicho, y te parafraseo. La educación y la investigación son motores muy poderosos para transformar las sociedades. Nosotros lo que queremos es escucharte, como dice Marian.

Edgar Barroso Systems: ¿a dónde estamos en el café? No, no, no hay ninguna. Es una, es una entrevista semiestructurada y es, y lo hemos hecho con David Garza, con Juan Pablo Murra, con Ricardo Zaldívar, tú eres el cuarto, la cuarta persona con quien lo hacemos.

Edgar Barroso Systems: Y la idea es entender cuáles son esos vectores de todas estas opiniones, de todas estas personas. Además, lo estamos haciendo con estudiantes con el liderazgo está quedando una cosa súper interesante.

Edgar Barroso Systems: Pero bueno, vamos a empezar de directo Javier. Tú que tienes toda esta experiencia y que estás viendo hacia hacia el 2 030, hacia el 2 035,

Edgar Barroso Systems: como imaginas el ecosistema de investigación en el campus Monterrey. Esto ha sido 1 de los temas más recurrentes. Todo mundo ha dicho la importancia que tiene la investigación para el Tec de Monterrey, pero queremos oír desde tu perspectiva, como imaginas el ecosistema de investigación en 2 030.

Javier Guzmán: Bueno, primero que nada, Gracias. Edgar. Gracias. Mario por la invitación. Ya sé que no es formal, pero lo voy a hacer lo más formal que pueda que te podáis.

Edgar Barroso Systems: Me encanta. Me encanta.

Javier Guzmán: Mira, yo te diría que me gusta soñar, y me gusta imaginar cómo esto va a pasar, y veo al 2 030

Javier Guzmán: como un punto en el camino más, no el destino.

Edgar Barroso Systems: Mhm.

Javier Guzmán: Lo que veo en el 2 030, en investigación en Camps Monterrey. Es una comunidad, un ecosistema consolidado en investigación.

Javier Guzmán: Va a haber una realidad en la cual nuestra investigación aplicada no.

Javier Guzmán: Nuestra investigación, que se hace con la iniciativa privada va a estar consolidada.

Javier Guzmán: O sea, creo que en ese tiempo ya me puedo permitir soñar que todas estas cosas que hemos venido plantando van a crecer. Y ya se van a ver a la distancia

Javier Guzmán: expedición, fensa el club de innovación.

Javier Guzmán: todo el ecosistema de las apuestas que estamos haciendo con empresas de startups. La acercamiento que vengo a dar Internet y empujar con la iniciativa privada con las industrias

Javier Guzmán: ya se va a ver, no va a ser un sueño En el 2 030

Javier Guzmán: va a estar consolidada. Obviamente, nos va a faltar crecer muchísimo, no. Y mi analogía de pa, Lo que ya se va a ver, ya va a estar plantado. Ya va a estar ahí. Todavía falta que crezca y se vuelva algo impresionante.

Javier Guzmán: Por eso creo que el 2 035 2 040 es donde todas estas cosas que se están plantando ahora se.

Edgar Barroso Systems: Mhm.

Javier Guzmán: Si lo veo como un punto en el camino, un punto crítico

Javier Guzmán: en el cual a lo mejor a veces haces cosas, y las haces por por fe, porque crees que es lo correcto, pero no ves los resultados inmediatos. Y hay gente que se cuestiona. No, ese es el camino. No es el camino.

Javier Guzmán: Es indudable que investigación es una apuesta que hemos hecho como grupo educativo, ya desde hace varios años.

Javier Guzmán: pero también es sin duda algo que tenemos que empezar a ver, que se den resultados.

Edgar Barroso Systems: Esto va a ser obvio y claro, y no va a quedar la mayor duda que esto ya se está dando que esto ya pasó.

Javier Guzmán: Y que ahora lo que queremos es que siga creciendo y volviéndose exponencial. Entonces

Javier Guzmán: ese sería mi mi sueño para el 2 030.

Edgar Barroso Systems: Para Pen, pensando en el campus Monterrey como hob de innovación o de investigación

Edgar Barroso Systems: que lo hace. Único? ¿qué quisieras que fuera algo que, ¿cuál es nuestra ventaja comparativa contra otras universidades o no? Quiero decir, contra pero con otras universidades, o incluso con otros campus. ¿qué hace al ecosistema del campus Monterrey especial y único.

Javier Guzmán: Sí. Yo creo que muchas cosas que lo hacen único, y voy a empezar con el talento, el talento que este cambio es capaz de atraer no solo de México, pero de todo Latinoamérica, del mundo Tenemos estudiantes de muchos lugares.

Javier Guzmán: Es conocido que este campus es nuestro campus. Nuestro flashhip es nuestro campo icónico. Es nuestro campus que donde la gente, cuando dice Tech Monterrey.

Javier Guzmán: Este es el campus del tecnoterrey, No, o sea.

Javier Guzmán: me gustan los demás campos que tenemos, no Es por decir que los demás no son, pero Este es nuestro nuestro campo icónico.

Javier Guzmán: y eso hace que el talento quiera venir el talento tanto de estudiantes como de profesores, y creo que tenemos esa gran diversidad, ese gran talento, cuando ves de dónde vienen nuestros profesores donde estudiarlo vienen aquí ¿no? Y tenemos. Pero este es el magneto. Este es el lugar.

Javier Guzmán: dicen en Estados Unidos, que éxito llama más éxito. Esto es lo que ha pasado a Monterrey. Se ha creado esa semilla. Y entonces llega todo este talento: estudiantes, profesores.

Javier Guzmán: ¿qué otra cosa lo hace único, Y creo que son las cosas que desde la parte de investigación quiero potenciar es que tenemos una relación tan estrecha y próxima con Estados Unidos que somos la llave de Latinoamérica. Para el el norte, no el norte desarrollado, el norte de poder económico.

Javier Guzmán: Podemos fungir, lo hacemos, pero lo podemos hacer todavía más

Javier Guzmán: que seamos esa llave de acceso a Latinoamérica, y eso es algo que nos vuelve únicos por posición geográfica, proximidad cultural, pues con el sur de Estados Unidos con Texas en particular, nos vuelve esa llave de reyes, esa llave para poder entrar a ese ecosistema.

Javier Guzmán: Y bueno, no solo Estados Unidos, Europa también.

Javier Guzmán: Pero al mismo tiempo. Y estas son las cosas que a mí me encanta de ser mexicano, vivimos en la dualidad, vivimos en esta en este conflicto eterno Y aunque estamos tan próximos, Estados unidos con estos beneficios, también estamos viviendo la realidad de ser un país latinoamericano, con todo lo que ello implica.

Javier Guzmán: Entonces tenemos esta otra oportunidad de ser esta llave que trascienda para que puedan comunicarse y puedan ser eficientes en todo. En particular, a mí me interesa por la investigación, por supuesto, pero pues toda la parte de educación que, como ya mencionaste hace rato.

Javier Guzmán: yo lo veo como parte de la misma moneda, simplemente dependiendo de donde la veas. A veces esa educación, a veces de esa investigación, pero es parte de la misión que estamos haciendo. No son cosas independientes.

Javier Guzmán: La una buena investigación se nutre de la educación de lo que se está dando en las clases de los estudiantes. Y, al revés, una muy buena educación la pueden dar gente que a veces está trabajando en cosas de punta, investigación.

Javier Guzmán: cosas innovadoras, cosas novedosas para el mundo que se las enseñas a los alumnos para que para que ellos sean el siguiente la siguiente generación que lo que lo haga.

Edgar Barroso Systems: Y justo parte de lo que ha pasado en estas entrevistas

Edgar Barroso Systems: es esta conexión. ¿cómo podríamos hacer que el campus

Edgar Barroso Systems: pudiera aumentar su densidad de talento como bien decías, y que esa densidad de talento también esté interconectada

Edgar Barroso Systems: desde tu perspectiva. ¿cómo se ve en la práctica, ¿cómo te imaginas que podríamos ejemplificar esta conexión entre investigación, formación de estudiantes y transferencia a la industria o al mercado.

Javier Guzmán: Creo que es muy importante que

Javier Guzmán: primero tengamos la convicción de hacerlo, que esto es lo correcto. No creo que eso todos estamos de acuerdo.

Javier Guzmán: Segundo, tenemos que tener ejemplos donde estos éxitos que esto pase, y aquí es donde otra vez somos afortunados en Monterrey. Esto pasa Esto se da. Hay estudiantes a todos los niveles de todos sus

Javier Guzmán: niveles de educación que participan en investigación, participan en ellos

Javier Guzmán: y llevan a crear empresas, colaboraciones con otras que ya están formadas, servicios que se dan.

Javier Guzmán: Todo esto ya pasa.

Javier Guzmán: Y el tercer ingrediente, te diría, ese es el que a lo mejor no estamos tan bien alineados y tendríamos que hacer un esfuerzo mayor.

Javier Guzmán: porque puede que pasen estos 2 ingredientes que te acabo de mencionar, pero si no lo comunicas, el mundo no será que pasa

Javier Guzmán: si no lo proyectamos. Y lo hablamos. Si somos orgullosos, si somos los primeros campeones del siglo.

Javier Guzmán: es difícil que la gente lo sepa orgánicamente. Yo te diría que las 2 primeras fases hay que reforzarles el el que los estudiantes colaboren en la investigación en el que se haga esta vinculación que ya está pasando.

Edgar Barroso Systems: Mhm.

Javier Guzmán: Lo que tenemos que mejorar es nuestra comunicación hacia el exterior. Tenemos que que

Javier Guzmán: ser orgullosos de lo que estamos haciendo y decírselo al mundo. Y esto va a implicar tener que tener posturas y tener posturas claras que sean consistentes con lo que hacemos.

Javier Guzmán: pero que no nos debe de dar miedo, tener una postura y hablarlo, y decirlo porque es muy importante para México, para el mundo que se entere de lo que está pasando.

Javier Guzmán: Y creo que a veces somos un poco muy cómo se dice modestos

Javier Guzmán: que lo que que creemos que es presunción a lo mejor, pero no es

Javier Guzmán: cuando yo veo instituciones en el mundo. Lo que mejor hacen es venderse.

Edgar Barroso Systems: Mhm.

Javier Guzmán: Y a veces no aceptan bien las otras 2 cosas que te acabo de decir.

Edgar Barroso Systems: Es verdad.

Edgar Barroso Systems: Es verdad. Es verdad. Oye Y cuéntame un poco sobre esas fueron las cosas

Edgar Barroso Systems: que ves desde tu perspectiva, pero también déjame preguntarte sobre cosas un poquito más sobre tensiones, no como que tensiones o contradicciones. Ves en esta visión.

Edgar Barroso Systems: por ejemplo, entre investigación básica versus investigación aplicada, publicaciones versus patentes, escala local, impacto global, incidencias versus investigación pura. Este, cuáles son algunas de estas tensiones o las mencioné solo para darte ejemplos.

Edgar Barroso Systems: Pero ¿cuál sería algunas de las tensiones que tú crees que debemos de atender para que justo se pueda lograr esta visión de la que nos estás hablando.

Javier Guzmán: Sí. Mira. Yo creo que muchas de estas canciones que mencionas son buenos ejemplos porque son reales. La gente las percibe.

Edgar Barroso Systems: Mhm.

Javier Guzmán: Yo creo que voy a usar esa palabra. No son son percibidas a lo mejor no son tan reales de fondo. Y aquí es donde voy a explicar por qué

Javier Guzmán: nosotros hemos hecho una apuesta por hacer investigación aplicada.

Javier Guzmán: porque no tenemos todos los recursos para poder hacer todo tipo de investigación. Tenemos que apostar por algo.

Javier Guzmán: y lo que creemos que vale la pena apostar. Para nosotros es la investigación aplicada, algo que tenga una transferencia y una incidencia en la sociedad.

Javier Guzmán: Eso no significa que la investigación básica no sea buena hacerse o que la vamos a prohibir se va a seguir generando. Es simplemente dónde vas a potencializar y qué es lo.

Edgar Barroso Systems: En los.

Javier Guzmán: Tocaba hacer más en el camino de esta investigación aplicada

Javier Guzmán: fin, un propósito, algo que quieres impactar.

Javier Guzmán: Te aseguro que en toda mi vida que he visto investigación aplicada siempre se ha hecho de la mano la investigación básica en el proceso. Siempre hay algo nuevo que se descubre. Siempre hay algo nuevo que puedes pensar que

Javier Guzmán: a lo mejor para este proyecto, que era muy enfocado a producir X, lo puedo usar este conocimiento ahora para hacer un avance del conocimiento en el área X o Whi en otra.

Edgar Barroso Systems: Mhm.

Javier Guzmán: Esto siempre será,

Javier Guzmán: y esto no significa que entonces no vayamos a contribuir con la innovación en la nueva generación de conocimiento. Y esta esta investigación básica.

Edgar Barroso Systems: Mhm.

Javier Guzmán: Simplemente que vamos a decidir que el motivo por el que queremos hacerlo, el final, el propósito es una investigación aplicada que tenga incidencia.

Javier Guzmán: Entonces te diría que cuando lo empiezo a ver así, esa tensión empieza a desaparecer.

Edgar Barroso Systems: Estamos haciendo que no hagas investigación básica.

Javier Guzmán: Sino que la enfoques que busques un propósito, un fin, un valor

Javier Guzmán: y que una vez que la hagas, pues úsalo para aprender para esta curiosidad que todos tenemos como científicos y generen nuevo conocimiento.

Javier Guzmán: El tema, por ejemplo, de las patentes y las publicaciones que yo te diría, más allá solo de patentes al uso de la patente y creación de la empresa.

Javier Guzmán: A veces gente lo puede ver como un conflicto como una tensión.

Edgar Barroso Systems: Mhm.

Javier Guzmán: Yo lo veo como parte del proceso en el continuo de la generación de conocimiento.

Javier Guzmán: Los artículos son de divulgación. Son para poder compartir que se hace. También se usan como estrategia en en protección de.

Edgar Barroso Systems: Propiedad intelectual.

Javier Guzmán: Intelectual, porque lo que estás haciendo es que ya nadie la puede tener cuando las haces públicas y la patente, lo que te hace es la habilidad de restringir un espacio para que tú lo puedas explotar. No estás diciendo que alguien más no lo puede hacer, sino simplemente estás llamando ese espacio.

Javier Guzmán: Y eso es parte de continuo. Es parte de la estrategia del continuo de cómo generas

Javier Guzmán: y la el siguiente etapa, que es la de creación de empresas.

Javier Guzmán: pues es la la el volver práctica, lo que enseñas volver práctica lo que investigas el final último del propósito que a veces lo harás a través de una startups. A veces lo harás con otra compañía que ya tienes todo eso hecho y lo tratas de hacer con ellos.

Javier Guzmán: Entonces yo lo veo como un continuo, y entonces no tiene por qué estar peleado o decir a una u otra materia. No es parte de, a veces trabajar en un espacio. A veces me moveré al otro o a veces ya estoy terminando el proyecto y tengo que hacer esto.

Edgar Barroso Systems: Mhm.

Javier Guzmán: Es parte de cómo entender la investigación como un proceso más que como un solo evento, te diría yo.

Edgar Barroso Systems: Para que termine en una publicación, como normalmente pasa una cosa que ha salido también de las entrevistas que podría ser internacional.

Javier Guzmán: El que.

Edgar Barroso Systems: Dime, dime.

Javier Guzmán: Me darías cáncer de.

Edgar Barroso Systems: Claro. Por favor.

Javier Guzmán: Hay una. No sé si llamar la atención.

Javier Guzmán: pero javier ahorita de esto, que hablas, la verdad se me hace muy padre. Y Y bueno, 1 de los retos es

Javier Guzmán: el tail de Monterrey.

Javier Guzmán: Hoy en día, el Tec de Monterrey, pues tenemos una configuración, una estructura. Están las escuelas con proyectos de investigación, este algunos enfocados, pero también hay hay profesores con doctorado que, independientemente de de para donde vaya la estrategia de pues ellos quieren hacer investigación. Porque, pues, para eso estudian un doctorado. Y muchos no están en los grupos de investigación.

Javier Guzmán: ¿cómo ¿Cómo lograr esa? ¿vamos a llamarle armonía alineación

Javier Guzmán: para cumplir el propósito de la visión del 20 30, que es como el mandato superior. Pero como que necesitamos esa alineación y armonización en donde esos egos este nos permitan ver más el ecosistema, o sea pasar del ego al ecosistema.

Javier Guzmán: Y no es fácil. ¿no? Entonces, ¿cómo ¿cómo visualizas, ¿Qué tenemos que hacer para poder hacer que se cumpla lo que tú estás este manifestando y declarando. Pero bueno, en el día a día y pensando básicamente en el campus motora, es, Yo creo que es muy importante. María Antonia, y te diría que

Javier Guzmán: hay varias formas de tocar ese punto. Uno

Javier Guzmán: tiene que ver con el liderazgo del grupo educativo. Tenemos que ser claros, como ahora. Un grupo educativo que nos hemos conformado.

Javier Guzmán: y ahora hay una vicepresidencia de investigación que va a ayudar a coordinar todas estas cosas, a decidir por dónde decidir conjuntamente. Pero no estoy diciendo que la vicepresidencia sola en una torre de cristal decide que seas, sino que es responsable de que esto se dé. Entonces tiene que

Javier Guzmán: convocar los actores, llegar a un consenso y avanzar hacia un lugar. Y una vez que se decide ese lugar, pues todos tenemos que ir marchando hacia allá.

Javier Guzmán: Creo que lo que ha pasado es que hemos tenido varias direcciones, varias, pues a lo mejor iniciativas que nos jalan en diferentes direcciones. Por eso es tan importante tener un grupo que consolide todo, y esto es lo que el Grupo quiere hacer. Vamos para allá, todos todos tenemos que manejar

Javier Guzmán: esto, y este mensaje tiene que bajar a toda la organización para que nos comportemos como un grupo educativo

Javier Guzmán: y evolucionemos realmente a hacer ese flujo creativo.

Javier Guzmán: Por el otro lado, también creo que es importante reconocer que, como una universidad de primer mundo que tenemos que tener la diversidad de tolerar, que haya digo yo, ovejas que se van un poco fuera del camino.

Javier Guzmán: porque esos a veces son las que crean estas spams de innovación y que a lo mejor son muy, muy atractivas.

Javier Guzmán: Ahora, no puedes tener a todo tu rebaño de ovejas cada quien por donde quiere, porque entonces no vas a donde quieres ir.

Javier Guzmán: y nuestra dirección es clara, entonces tenemos que tener la mayor cantidad de gente trabajando en estas áreas

Javier Guzmán: sin prohibir cosas sin decir. Bueno, estas temas no las vestíamos en la entera. Bueno.

Javier Guzmán: es algo que a lo mejor ese profesor o esa profesora tiene una pasión increíble y genera recursos, o si lo puede hacer. Y

Javier Guzmán: no hay por qué no hacerlo.

Javier Guzmán: Pero la mayoría de las cosas sí deben ir encaminadas a ese lugar, o sea, los ríos normalmente llegan a un lugar, pero hay pequeñas líneas que a veces se salen y más mueren. Otras llegan formando sus pequeños caudales, pero tenemos que tener muy claro la dirección y si reforzarla desde el concepto de grupo educativo.

Javier Guzmán: permitiendo estas es

Javier Guzmán: iniciativas, Yo lo que he encontrado con el campus Monterrey. Este yo me voy a comer a centrales camino por los pasillos y normalmente ando interesado en conocer a los investigadores si y y me he encontrado sorpresas que yo no había visto. Por eso lo comento porque, pues

Javier Guzmán: si están y de repente no se ven, pero están vivos. ¿no? Yo me encuentro un profesor. No, Yo tengo 10 patentes caray y pos algo que yo no sabía ¿no? Y luego me encuentro, ¿no? Pues yo también puedo hacer cosas para solucionar el problema del aire. ¿no? Entonces

Javier Guzmán: yo creo que te fui de acuerdo. Creo que estratégicamente tenemos que tener la energía y los recursos hacia una dirección. Creo que eso es lo lo lo mejor que le puede pasar al Tec Este, pero también vivir bien con con esos brotes que a lo mejor son brotes.

Javier Guzmán: que puede ser que no genere un nuevo caudal.

Javier Guzmán: pero que ayudan a la cultura de la innovación y la investigación y el emprendimiento. Entonces, como que no, no está tapando las fugas de agua, sino vivir con las fugas porque, pues es parte de un ecosistema, entonces yo creo que es una tensión, pero hay que la podemos ser positiva. No sé.

Javier Guzmán: Hay muchas teorías, no en todo esto, de la innovación que realmente estas señales

Javier Guzmán: muy débiles son las que realmente transforman cosas. No.

Edgar Barroso Systems: Y hay que estar.

Javier Guzmán: Abierto a que exista totalmente de acuerdo. Eso Eso

Javier Guzmán: es es muy importante para el ecosistema universitario como el que tenemos, y especialmente Aqui en Monterrey. Y de hecho, hay veces que ni en la propia escuela, sabe, o sea, te digo que es lo lo interesante, pero a mí me da gusto que que esté esa energía, pero sí hay que canalizarla totalmente como nuestra

Javier Guzmán: perdón, ya eso eso.

Edgar Barroso Systems: Nombre maravilla cuando quieras. Justo hablando de caudales, una de las cosas que ha surgido, Javier, que creo que tu perspectiva sería muy importante. Es.

Edgar Barroso Systems: y

Edgar Barroso Systems: como lo hemos planteado María Adrián hasta ahora, es disciplinarmente. Vamos, digamos, en una dirección, ¿no? Y vamos bien hay que subir las publicaciones, hay que ir como, o sea, como lo lo lo básico, la base, y son estas líneas disciplinares.

Edgar Barroso Systems: Pero una de las cosas que ha surgido de varias personas que hemos entrevistado es cómo empezamos a hacer intersecciones que se den de manera más natural. Tú decías algo súper interesante. Hace unos momentos decías, es que cuando haces investigación aplicada, cuando te enfrentas al problema real, que normalmente es más complejo de lo que parecía descubres nuevas cosas. Y después esas cosas las puedes aplicar en otras disciplinas.

Edgar Barroso Systems: Y justo esa traslación, ya sea de metodologías, ya sea de técnicas de tecnología, lo que sea que se puedan empezar a cruzar más.

Edgar Barroso Systems: ¿cómo ¿Cómo crees. Aquí empezamos a pensar en el cómo, cómo te imaginas que podríamos incentivar a que haya más colaboración entre distintas disciplinas dentro del Tec, que es una que creo que es una de las tensiones que también han han sido mencionadas. Me gustaría mucho escuchar tu perspectiva. Javier.

Javier Guzmán: Creo que tenemos que generar espacios para que la gente conozca.

Javier Guzmán: porque es sorprendente. Cuando los humanos nos conocemos la oralidad que encontramos y el propósito compartido que descubrimos.

Javier Guzmán: Pero cuando nos dan esos choques, esas colisiones que he mencionado en algunas otras entrevistas, como químico que soy.

Edgar Barroso Systems: Ya.

Javier Guzmán: De choques moleculares. Si las personas no se encuentran, pues no se van a conocer ni van a crear esta interacción.

Javier Guzmán: entonces sí es una responsabilidad de nosotros, como líderes de la institución generar esos espacios, esas formas para que puedan encontrarse en el campus en centrales, en lugares, No, porque si no se conoce la gente, pues no, no surgen este tipo de eventos. No.

Javier Guzmán: ahora eso no es suficiente. Tienes que motivarlos. Tienes que incentivarlos. Tienes que decir, bueno, hay mecanismos para que cuando alguien de diferentes escuelas que ya trabajan juntos, lo haga.

Javier Guzmán: y y yo aquí vengo también con una perspectiva que a lo mejor esto es lo que lo que ayuda. Yo yo no pienso en escuelas. Yo pienso en problemas reales del mundo.

Edgar Barroso Systems: Mhm.

Javier Guzmán: Yo pienso en los problemas que la gente necesita solución.

Javier Guzmán: Y cuando un equipo interdisciplinario altamente eficiente en el mundo real, no el académico, el mundo del trabajo. Quiero resolver un problema.

Javier Guzmán: Llama a la Mesa a los que tengan algo que contribuir al problema y respectivamente, de dónde son? ¿qué escuela vienen? ¿de qué es nacionalidad bárgara?

Javier Guzmán: Porque lo que quieres es resolver un problema.

Edgar Barroso Systems: Mhm.

Javier Guzmán: Necesita saber diferentes perspectivas.

Javier Guzmán: y creo que si empezamos a cambiar nuestra forma de ver la investigación aplicada a problemas que estamos tratando de resolver. Nos vamos a dar cuenta que una sola escuela no puede resolver ese problema. Necesita miembros de múltiples escuelas.

Javier Guzmán: institutos, inclusive a lo mejor ni siquiera de nuestra comunidad. Y tenemos que salir a buscar a esos partners para poder resolver los problemas.

Edgar Barroso Systems: Mhm.

Javier Guzmán: Es algo de lo que he venido empujando mucho en esta transformación que tenemos que escuchar a la sociedad en los problemas que la sociedad necesita resolver.

Javier Guzmán: no los problemas que yo me entrené para resolver hace 30 años, y la más ya son irrelevantes

Javier Guzmán: y a veces nos queremos conformar o mantener nuestro confort sound de seguir resolviendo los problemas que era relevante. Hace 30 años, el mundo ya no funciona así y cada vez cambia más rápido. Tenemos que evolucionar a a juntarnos en la mesa para resolver problemas.

Edgar Barroso Systems: Mi escuela resuelve un problema en particular.

Javier Guzmán: Es otra forma de ver las.

Edgar Barroso Systems: Sí es más bien partir del problema real, que es complejo y que requiere interdisciplina y que a partir de ahí se forman los grupos, No.

Javier Guzmán: Siete cargas. Ya lo entendiste, lo de las líneas de la de las disciplinas como una línea vertical.

Javier Guzmán: y cómo tenemos que buscar las intersecciones este porque, por ejemplo, disciplinas como biotecnología, ingeniería química, pues son como como una línea vertical de enfoque

Javier Guzmán: y las líneas verticales que tú deseas sacar por por por naturaleza o geometría. Nunca se van a juntar.

Edgar Barroso Systems: Mhm.

Javier Guzmán: Y tenemos que buscar esas líneas, curvas e intersecciones. Y ahorita. Me está cayendo el 20 que, pues esas intersecciones, muchas las va a marcar la vicepresidencia de investigación

Javier Guzmán: y también está la expedición, el job hablando de Monterrey, que son esos puntos de encuentro que no sean centrales solamente, sino que sea por diseño y por estrategia.

Edgar Barroso Systems: Claro.

Javier Guzmán: Perdón, pero me está cayendo eso como algo algo interesante. Estos espacios de migración son sin duda esos espacios donde queremos que la gente se encuentre y encuentre sus choques, estas dinámicas, estas ideas, que llama la gente de un café un viernes por la tarde.

Edgar Barroso Systems: Mhm.

Javier Guzmán: Se vuelven de nuevo. Las cosas son proyectos que necesitamos para salvar.

Edgar Barroso Systems: Que vienen de ese ese término viene de París, de los de los cafés, no donde se juntaba Chopin y se juntaban las y los poetas y intercambiaban ideas. Y bueno, que siempre pueden surgir estas cosas muy prolíficas.

Edgar Barroso Systems: Ahora vamos un poquito a ¿Cómo llegamos ahí? Javier en esta visión que describes en qué has pensado? ¿cómo llegamos ahí? ¿qué tiene que pasar? ¿qué rol juega el campus Monterrey para que te ayude a que esta visión pueda ser posible.

Javier Guzmán: Sí. Mira, Yo yo creo que algo que tenemos que que hacer rápidamente es transformar esta visión a a pasos a a metas a objetivos claros de año por año.

Javier Guzmán: porque creo que que necesitamos algo más que una una mente, un objetivo es un roadman.

Edgar Barroso Systems: Mhm.

Javier Guzmán: De valores.

Javier Guzmán: Y el campus Monterrey es clave para esto, pues es nuestro nuestro campus. Nuestro Flaxhip es donde pasan muchas cosas, no el 70 por 100 de la investigación de los fondos de aena aquí y los números que estoy viendo. Entonces, es impresionante lo que hacemos en Camps Monterrey.

Javier Guzmán: Bueno.

Javier Guzmán: tenemos que hacer varias cosas, y esto siempre lo he pensado en cualquier cosa que hagamos en la vida.

Javier Guzmán: Y eso significa que ¿qué valor tiene esto para alguien que puede que lo haga algo. Pero porque me divierte, no. Y pues también eso es una validez de hacer las cosas.

Javier Guzmán: Pero en este mundo profesional en el que vivimos tiene que darle valor a alguien.

Javier Guzmán: no, entonces que hagamos investigación. No es nada más por hacer investigación. Lo queremos hacer porque tiene un valor para alguien para aquí lo tienen, pues empezamos desde la casa para nuestros estudiantes. Tiene un gran valor.

Edgar Barroso Systems: Que iban y que entiendan cómo se hace la investigación que que sepan que así es como ahora tenemos teléfonos que hay satélites que hay en Internet.

Javier Guzmán: Inteligencia artificial no vino de abrir un sobrecito vino de que ocurrió y empezó a trabajar. Y evolucionó todo este tipo de cosas. Tenemos que volvérselas a enseñar a los estudiantes. La tecnología al final, es el resultado de nuestra educación, investigación, este ciclo.

Javier Guzmán: Luego tenemos que darle valor a la gente que quiere usar investigación con ellos, a nuestros socios, a nuestra gente que trabaja con nosotros. Las empresas, las industrias, los fondeadores, el gobierno, las fundaciones.

Javier Guzmán: todos estos actores de la sociedad que tienen problemas para ser resueltos, problemas que necesitan investigación, necesitan tiempo y espacio para entender. Y eso es lo que la investigación hace. A final de cuentas, trata de entender el porqué.

Edgar Barroso Systems: Para dar una excursión.

Javier Guzmán: Entonces tenemos que tener muy clara nuestra propuesta de valor. El porqué hacemos esto

Javier Guzmán: y luego tenemos que comunicar por qué es bueno que hagan esto nuestros socios con nosotros y no con la Universidad X o Ye.

Edgar Barroso Systems: Porque nosotros somos los indicados para hacer eso.

Javier Guzmán: Tenemos que ser capaces de responder esas respuestas, y eso tenemos que hacerlo porque Monterrey, ¿Por qué Camps Monterrey, por qué, cuando traíamos la empresa más grande del mundo o de cualquier nombre.

Javier Guzmán: esa empresa quiera trabajar con nosotros en Monterrey, tenemos que dar esa propuesta. Obviamente, tenemos el talento. La cantidad de talento que tenemos en México es impresionante.

Javier Guzmán: Yo se lo he dicho a toda la gente. Cuando me reúno, me impresiono siempre de los los Bakras que tiene la gente Aquí, nuestros profesores, los alumnos, nuestros alumnos van a las mejores universidades del mundo. Cuando se gradúan, tienen los mejores trabajos.

Edgar Barroso Systems: Mhm.

Javier Guzmán: Vuelven líderes de donde se van. Nuestros profesores han sido entrenados en las mejores escuelas del mundo. Tenemos que decírselo al mundo y.

Edgar Barroso Systems: Es un.

Javier Guzmán: Es la

Javier Guzmán: aparte de todo eso, somos super eficientes para hacer las cosas. Y no quiero decir baratos, porque barato soy a veces como que que es algo de baja calidad.

Edgar Barroso Systems: Somos y eficientes para hacer investigación.

Javier Guzmán: Con los recursos que tenemos en México. Hacemos una gran cantidad de investigación a nivel mundial. Las publicaciones que se hacen las patentes, las spin offs que tenemos

Javier Guzmán: cuando ves la cantidad de recursos invertidos por lo que se produce.

Javier Guzmán: Es mejor que en muchos lugares del mundo.

Javier Guzmán: Esta historia no la hemos contado bien. Esta historia. La hemos contado porque somos baratos porque somos un lugar en el que pagar un estudiante en el Tech, pues cuesta a lo mejor la mitad de pagarlo en una universidad americana. No es por eso que quiero que vengan. Quiero que vengan porque somos muy eficientes.

Javier Guzmán: Y aquí es donde trato de ligar conceptos que cuando yo me fui de México. Siempre me gustaba presumir de los agentes de México. El mexicano es una persona muy ingeniosa.

Edgar Barroso Systems: Mhm: Claro.

Javier Guzmán: Mexicano con poco hace mucho.

Javier Guzmán: Bueno, pues, ¿por qué no podemos trasladar eso a la investigación? Ya se da si se hace, pero no lo hablamos. No lo decimos. El ingenio que tenemos como mexicanos para hacer. Piensen en cualquier ejemplo

Javier Guzmán: que han hecho desde que eran niños. La gente en México jugaba fútbol, no tenía pelota y jugaban con una piedra, agarraban un este, una de esas cosas donde vendían agua y las damas

Javier Guzmán: o no tenías este.

Edgar Barroso Systems: Portería, pero ponías unas este mochilas.

Javier Guzmán: Piezas así a hablar.

Javier Guzmán: Y te das cuenta que la gente exitosa, los mexicanos exitosos en el mundo. Eso es parte de lo que comparten.

Edgar Barroso Systems: Que sabe, como con pocos recursos.

Javier Guzmán: Hacer lo que otros a lo mejor hubieran querido, un presupuesto de 1 000 000 de dólares.

Javier Guzmán: Y hay ejemplos. Hay gente que hace eso. Nosotros tenemos ejemplos de lo que estamos haciendo hoy en investigación. En otros lugares, costaría un dineral hacer.

Javier Guzmán: Nosotros damos igual mejores resultados. Esta historia de eficiencia de ingenio. Tenemos que venderla al mundo.

Javier Guzmán: y eso es lo que nos va a hacer únicos. Tenemos que encontrar esto, que nos hace únicos y tanto. Y esas son de las cosas que tenemos que hacer vender eso. Eso. Me encanta lápico. A diferencia de otras entrevistas, he estado intervendiendo un poquito más, porque es un tema que me apasiona.

Javier Guzmán: pero me gusta mucho eso que estás diciendo, Javier porque, en efecto.

Javier Guzmán: yo soy un reflejo de esa mexicanidad creativa y espontánea.

Javier Guzmán: Y lo digo con algo que en la entrevista de David. Este

Javier Guzmán: me encantó porque todos han tenido algo distinto pero conectado.

Javier Guzmán: pero dijo, para mí, las tensiones son los Mindsets y dijo: a mí me encantaría que cada profesor no

Javier Guzmán: se quiera comer el mundo y no encontrar porque nomás escuchas. No tengo tiempo y no tengo recursos.

Javier Guzmán: o sea, cómo abandonar esas y y nosotros lo demostramos, y creo que incluso podemos tener mayor valor que otras regiones ya no tanto por lo que esto dices porque cuesta menos, pues si cuesta menos es una ventaja.

Javier Guzmán: pero la ventaja no va a ser eso. ¿va a ser que, aparte un investigador que se preparó al más alto nivel

Javier Guzmán: o tiene esa característica de ser creativo, innovador y con orden, hacer cosas más sorprendentes. Me encanta eso que dices y hay que traducirlo en una ventaja de valor. Y yo creo que tenemos que en brace nuestra mexicanidad, nuestra, o sea, que nos vuelve únicos

Javier Guzmán: porque eso nadie más lo va a tener.

Javier Guzmán: Pero vender la parte, que es lo que realmente es bueno. A veces todos vemos los defectos

Javier Guzmán: y no vemos la gran gran virtudes que tenemos. Tenemos que ser. Y aquí regreso a mi punto de hace rato, tenemos que ser coherentes y consistentes en nuestra comunicación para poder dar ese mensaje.

Edgar Barroso Systems: Si no es una idea.

Javier Guzmán: Pues que se te ocurre vienes en la tarde en un café, pero no lo vuelves a repetir, y es algo en lo que tenemos que ser consistentes, dar el mensaje y que nos creamos. Esto. Yo le digo a David y a otros

Javier Guzmán: que yo vengo acostumbrado de jugar en la primera división.

Javier Guzmán: Yo no vine aquí a jugar a la segunda temporada y vengo a ganar en la primera edición. Y esa es la mentalidad que todos tenemos que tener. O sea, no porque estemos en un país con la complejidad que tenemos.

Javier Guzmán: No nos tenemos que limitar, porque realmente nuestra institución es una institución que podría estar en cualquier lugar y tener los resultados que estamos dando es una institución de alta calidad desde nuestros estudiantes, los profesores, la gente que trabaja aquí.

Edgar Barroso Systems: Sí, sin duda.

Javier Guzmán: muy valioso y lo va a ligar. Y a lo mejor no quiero que esto se convierta en un

Javier Guzmán: Bueno, pues una conversación de café, pero pero va más allá, ¿no?

Javier Guzmán: El viernes pasado, un profesor se me acercó de aquí del campus

Javier Guzmán: y me dijo oye madre Adrián.

Javier Guzmán: Ya están vendiendo acciones del Tec a Estados Unidos en la ninguno. ¿por qué

Javier Guzmán: dice es que acaban de nombrar 3 Vicepresidentes de Estados Unidos.

Javier Guzmán: Este, le digo: mira, tú no te preocupes porque el Tec no se puede vender. Es una C, entonces tú, por ese lado, nunca te preocupes por el técnico. No se puede vender.

Edgar Barroso Systems: Sí.

Javier Guzmán: Pero gente que que padre que llegue gente de otras partes del mundo, eso porque yo y tú

Javier Guzmán: somos muy buenos.

Javier Guzmán: Y yo en particular, creo que no a nivel que tú quieras ser internacional. Entonces, con el gran valor que tienes, tú que tengo yo, y que llegue gente de otro país nos va a enriquecer más.

Javier Guzmán: y fue una forma de hacerme cargo de la inquietud del profesor, pero lo afirme.

Javier Guzmán: le di su valor al nivel más alto que se quiera dar. Yo sí tengo un valor

Javier Guzmán: que no cabe en el mundo. Yo sí me siento con esa humildad que me caracteriza, pero tengo que decir: a mí no me preocupa estar sentado estando en las Naciones Unidas del emprendimiento con 10 países

Javier Guzmán: y no me siento menos, y ese es un mind y el otro es enriquecernos con la gente que llegue de otros países y de otra mentalidad, no al revés. Sentir que yo no puedo. Entonces ese Mind

Javier Guzmán: de manera recurrente. Creo que es el que tenemos que trabajar y hacerlo este de mucho valor. Y bueno, entonces, ¿qué piensas y Y Y la idea es esta de

Javier Guzmán: verlo por el otro lado, no También Imagínate que podemos atraer este tipo de talento al Tech. Es un ejemplo de lo que ya tenemos. Hace que esa gente quiera trabajar con nosotros. Esa es la Esa A lo mejor no hubieran venido porque no era atractivo.

Javier Guzmán: Ahora, los que ya estamos, lo volvemos atractivos para este tipo de gente, de eso debería sentirse orgulloso. Todo lo que trabaja en el tema.

Javier Guzmán: Claro, guay.

Edgar Barroso Systems: Oye y justo En ese sentido, Javier una pregunta que siempre les hacemos es de todo lo que has mencionado hasta ahora.

Edgar Barroso Systems: que que es no negociable. O sea, qué cosa tiene que pasar, sí o sí en tu estrategia y en el campus Monterrey. Para lograr esta visión.

Javier Guzmán: Mhm: Nada más. Una me lo puedo poner más.

Edgar Barroso Systems: Pueden ser un par, no te preocupes, pero ¿qué es algo que dices? No sé si voy a lograr todo lo que quiero. Pero estas 2 3 cosas tienen que pasar.

Javier Guzmán: Creo que algo que tenemos que dar el brinco son 2 cosas. Te voy a decir 2 cosas.

Edgar Barroso Systems: Total.

Javier Guzmán: Estos están relacionados, pero son, creo yo, parte de la razón razón por la que me trajeron a sentarme a esta silla.

Javier Guzmán: Una tiene que ver con que nuestra investigación aplicada

Javier Guzmán: se financie con fondeo externos de empresas, fundaciones

Javier Guzmán: que la investigación sea tan atractiva para nuestros socios que quieran pagar por ello.

Javier Guzmán: O sea, eso es un no negociable para mí. Tenemos que no depender de fondos gubernamentales para hacer nuestra investigación.

Javier Guzmán: Me gustaría que pudiéramos usar fondos gubernamentales. Si vamos a buscar esos fondos, pero no tenemos que depender de esos fondos, y te doy un dato.

Javier Guzmán: Hace 10 años, el 80 por 100 de nuestro fondeo para la investigación venía de fondos del gobierno mayoritariamente federales.

Javier Guzmán: Hoy esa figura ha cambiado.

Javier Guzmán: El 80 por 100 de nuestro fondo viene de la iniciativa privada, incluyendo fundaciones.

Edgar Barroso Systems: Guau!

Javier Guzmán: Y esto tiene que seguir.

Edgar Barroso Systems: Es el camino correcto.

Javier Guzmán: Eso no es negociable. No podemos regresar a ese modelo anterior.

Edgar Barroso Systems: En la.

Javier Guzmán: Compradores.

Javier Guzmán: Punto Número 2, que no es negociable para mí, y

Javier Guzmán: este, siendo el primero verdadero. La segunda premisa debe de ser también verdadera.

Javier Guzmán: Hay recursos limitados en México.

Javier Guzmán: hay recursos limitados para poder financiar la investigación que vamos a ir a buscar. Todos vamos a formar alianzas, Vamos a hacer todo lo que se pueda, pero estos recursos son limitados.

Javier Guzmán: Y, como universidad global, tenemos que actuar como una universidad global e ir por financiamiento internacional.

Edgar Barroso Systems: Mhm.

Javier Guzmán: Tenemos que dejar de pescar en el mismo lago. Tenemos que ir a pescar al mar.

Edgar Barroso Systems: Mhm.

Javier Guzmán: Si queremos tener más recursos.

Javier Guzmán: entonces para mí algo no negociable es trabajar y buscar el financiamiento de empresas multinacionales corporativos que a lo mejor no habían querido invertir en nosotros.

Javier Guzmán: que ahora nos vean como un socio de valor único. Por todas estas características que hemos discutido y que apuesten a hacer investigación con nosotros.

Javier Guzmán: Eso es otra de las cosas de visión, de dirección estratégica que no son negociables. Tenemos que movernos hacia allá.

Edgar Barroso Systems: Sí, sin duda, y creo que esta parte, María Adriana ha surgido mucho de la internacionalización en todos los sentidos, no desde atraer talento de todo el mundo a traer fondos de todo el mundo y hacer del campus Monterrey la insignia de la génesis, como decía Ricardo.

Edgar Barroso Systems: de la internacionalización. Ahora, para lograr esto.

Edgar Barroso Systems: ¿qué capacidades críticas, o sea, qué elementos

Edgar Barroso Systems: tendríamos que aprender en el Tec desde el Tec o desde el campus Monterrey para poder traer justamente este talento que mencionas mejorar la infraestructura, el financiamiento, las alianzas.

Edgar Barroso Systems: ¿qué capacidades nos faltan, ¿Con qué podemos aprender que nos coloque o qué debemos de aprender para llegar a esta visión.

Javier Guzmán: Creo que, y hacemos muchas cosas que son las correctas. El camino correcto, pero sí creo que una de estas es es el marketing.

Javier Guzmán: O sea, tenemos mucho trabajo que hacer en nuestro.

Edgar Barroso Systems: Tenemos que vender nuestra historia. Mejor.

Edgar Barroso Systems: Mhm.

Javier Guzmán: Yo siempre le digo a la gente que cuando traemos invitados internacionales.

Javier Guzmán: yo me reúno con ellos por por una videollamada.

Javier Guzmán: A veces no saben dónde está Monterrey. No piensan que es California, les digo, no, ese va con una R. No es el Monterrey de México.

Edgar Barroso Systems: Sí.

Javier Guzmán: Pues eso se ponen curiosos y quieren saber más y demás, pero no están convencidos de que esto es una universidad a nivel mundial.

Javier Guzmán: Cuando los invito a que vengan a Monterrey, conocen el campus Monterrey. Caminan. Ven a nuestros estudiantes, hablan con ellos, hablan con nuestros profesores, Van a Expedition, vienen a rectoría. Hablan con nuestros líderes. Con todo esto se van impresionados y me preguntan cómo podemos trabajar juntos.

Javier Guzmán: cómo podemos avanzar y el interés se voltea totalmente.

Edgar Barroso Systems: Mhm Mhm.

Javier Guzmán: ¿por qué no puedo hacer eso de una forma más virtual en este mundo que está conectado? ¿por qué tengo que traerlos a Monterrey para que vivan eso y se convenzan de que somos una universidad de primer nivel

Javier Guzmán: ahorita. Me cuesta trabajo porque tengo que pagar los boletos.

Edgar Barroso Systems: Ya.

Javier Guzmán: Bueno, eso se hace. Está bien, pero a lo que me refiero es que tenemos que tener este alcance global proyectando lo que tenemos en el Monterrey de una manera muy accesible, muy simple para que cualquiera lo pueda ver y se queden impresionados, porque cuando viene a Monterrey, se van impresionados de.

Edgar Barroso Systems: Es verdad, es verdad. Yo tengo varios colegas que han venido justo de aquí, de Suiza o de cualquier lugar Europeo. De hecho, ahora voy a hacer una pequeña residencia en Inglaterra y ellos vinieron a a Monterrey en junio y se fueron muy impresionados, o sea, del del tamaño de

Edgar Barroso Systems: de los profesores, de la investigación, etcétera, María Adriana. No sé si quieres ahora este es el momento de si quieres mencionar algunos proyectos específicos del plan. Dos 1 030

Edgar Barroso Systems: que quisieras rebotar aquí con con Javier.

Javier Guzmán: Sí, Yo creo que de alguna manera ya conoces mucho el plan del campus. Dos 1 030, Hay 4 elementos transformadores que con David hemos definido.

Javier Guzmán: y también con Juan Pablo, y también mucho de la mano contigo. Este 1 de ellos es el distrito de innovación, en donde la investigación, la innovación y el emprendimiento van a poder expresarse y ser un mecanismo hacia el campus, pero también de incidencia a la Comunidad Y más allá de de México, entonces es una columna.

Javier Guzmán: Este. El segundo son los posgrados presenciales que está definido como transformacional, O sea, y ahí vamos de la mano como lo impulsamos este. El tercero es la selectividad

Javier Guzmán: de estudiantes y también de profesores, pero particularmente en cuanto a estudiantes. Estamos ya teniendo programas de cupo límite en inglés y con estándares de selectividad. Ya este. Tenemos una respuesta en la prepa cumbres y también en programas de negocios en donde el el aceptar solo los mejores está resultando

Javier Guzmán: muy atractivo y estamos llegando rápidamente a las metas. Y el cuarto es la facultad de excelencia.

Javier Guzmán: Entonces, esos son los 4 pilares de la facultad, la selectividad, los posgrados presenciales y el distrito de innovación.

Javier Guzmán: Además, hay términos de calidad académica, vivencias estudiantil que tenemos este considerados, pero esos son los 4 pilares. No sé si eso te siga haciendo sentido. Hay algo que quisieras que que no se nos pase muchas cosas ya las dijiste, pero nada más para dejar. No se olviden de esto o

Javier Guzmán: vamos ahí en el camino. Sí, mira, te voy a contar los 4. Creo que son correctos, que es que tenemos que seguir impulsando. Te diría que los matices son importantes en todas estas artes, y ahí es donde aportado mi perspectiva en cada 1 de los matices.

Javier Guzmán: Voy a empezar con el que decías de innovación. Sin duda, este para mí es el más importante de los distritos de innovación. Es la conexión de investigación aplicada hasta el hasta el la sociedad

Javier Guzmán: con actores de todo tipo.

Javier Guzmán: y eso es algo que investigación aplicada, pues es es su panding de agua. No, Esto es lo que nosotros queremos hacer con investigación aplicada. Sin duda hay que ver cómo lo coordinamos. Creo que es muy interesante tener una estrategia y luego una operación y distinguir muy bien. Y es una de las cosas que yo, cuando llegué a ella, le di un mensaje al Consejo

Javier Guzmán: fue esto. A veces nos confundimos con que es estratégico y que es operativo. Son cosas diferentes las 2 importantes, pero tenemos que tener claridad de cómo las ligamos.

Javier Guzmán: porque si no solo hacemos estrategia, pero no operamos operamos, pero no es, no se estrategia.

Javier Guzmán: Los tenemos que tener esto muy bien entendido.

Javier Guzmán: Luego, en la parte, por ejemplo, de selectividad de estudiantes. Esto es sin duda importante porque queremos elevar nuestro estatus. Y para muchas otras cosas nos sirve.

Javier Guzmán: Creo que aquí el matiz que le daría es que para poder ser realmente internacionales. Tenemos que ofrecer más carreras en inglés. Tenemos que ofrecer más cursos en inglés para que realmente nuestros clientes internacionales quieran venir estar acá

Javier Guzmán: más allá de la selectividad interna. También es una selectividad para después quien se va y quién viene. Entonces eso nos tendría que ayudar.

Javier Guzmán: Y cuando ves a nuestros profesores dónde fueron educados y lo que son capaces de hacer, pues no veo por qué no puedan dar una clase de inglés. Y si nos comparas con institutos como India, que todos están en inglés a nivel profesional posgrado, pues a lo mejor podemos hacer algo ahí. Y a lo mejor podríamos empezar con programas aquí vivo con la parte de posgrados

Javier Guzmán: que decías de de los poblados de vivencias presenciales.

Javier Guzmán: A lo mejor podemos empezar a producir nuestros posgrados a cierto nivel. Todos son en inglés

Javier Guzmán: porque así competimos con todas las universidades del mundo

Javier Guzmán: en muchos otros lugares también. Estos postgrados son en inglés, no universidades europeas, en inglés, no en Zúrich y, de hecho.

Edgar Barroso Systems: Y tech.

Javier Guzmán: También también era alemán, ¿no? Pero es básicamente inglés.

Edgar Barroso Systems: ¿no? Pero en posgrados. Tienes razón, Está en inglés, No todos las maestrías son en alemán, pero los doctorados, casi casi todos son en inglés. Sí.

Javier Guzmán: Exactamente entonces a bordo, de empezar a hacer esas pruebas, es decir, nuestros doctorados científicos, todos tienen que ser inglés.

Javier Guzmán: y eso nos va entonces a abrir las puertas a otro mercado a otro tipo de calidad de estudiantes y nuestros estudiantes van a estar mejor preparados. Una de las grandes virtudes que yo siempre he visto en el Tecla Monterrey es que nuestros estudiantes son bilingües. Realmente son bilingües, van estudian y lo pueden hacer, Pues, ¿por qué no? Entonces, damos las clases en inglés.

Javier Guzmán: y eso es algo sencillo, pero que nos pone un reto

Javier Guzmán: no es a lo mejor es tan sencillo hacerlo, pero son direccionalmente hacia donde vamos.

Javier Guzmán: Luego el tema de los profesores de talento excepcional de estos que queremos traer. Me parece que es es sin duda algo que tenemos que fortalecer.

Javier Guzmán: pero aquí es donde yo sí Creo que tenemos que poner mucho cuidado en cómo definimos esto. Se puede decir por qué,

Javier Guzmán: en un análisis que estuvimos haciendo hace poco en ciertas escuelas estaban trayendo profesores con un perfil impresionante estudiando en las mejores escuelas parte de la de de de gobierno, ciencias sociales.

Javier Guzmán: Es impresionante la calidad de los profesores que están trayendo, pero muchos de ellos no son profesores que tú dirías son de estos consagrados ya y que los quieres traer.

Javier Guzmán: Y Y yo tengo mis Philips en esta idea de traer profesores que ya son consagrados, super buenos y traerlos a nuestro ecosistema de México, porque no es lo mismo hacer investigación en Katek con todo el dinero que tiene Katek ayudar con nuestra

Javier Guzmán: de retos que tenemos, acá y eso no es garantía de éxito. Traer un profesor así.

Javier Guzmán: Yo prefería traer un profesor que defiende que es exitoso, que a lo mejor se acaba de graduar de carne, pero es de Latinoamérica y que tiene un potencial tremendo para ser un profesor estrella.

Javier Guzmán: Entonces ahí es donde tengo mis matices de lo que entendemos como estos profesores sobresalientes distinguidos que traemos, porque no sé qué tan efectivo es traer a alguien así consagrado en todo esto, pero que no va a aportar al ecosistema que no lo va a vivir aquí.

Javier Guzmán: Entonces creo que ahí es donde tenemos que ponernos de acuerdo en que se y qué no, para no? Yo creo que canta lo que dices Javier. Porque los matices son importantes y de hecho, ahí están, pues ahí realmente es donde donde se hace la diferencia, porque los 3

Javier Guzmán: coincidimos, han coincidido todos.

Javier Guzmán: pero los comos y los matices Creo que ahí está la la gran diferencia y también no hay que dejar de pensar

Javier Guzmán: en el no solo, o sea, yo estoy muy de acuerdo, y la prioridad es traer profesores del Top, 50, el top del Top, 100,

Javier Guzmán: pero no dejar de de validar y afirmar

Javier Guzmán: a la gran mayoría de profesores que son, que estudiaron en México

Javier Guzmán: y a los profesores de cátedra

Javier Guzmán: que de ellos dependemos. Casi el 50 60 por 100 de las clases. Entonces, ¿cómo crear ese ecosistema? O sea, sin duda esa es la apuesta, como si tú

Javier Guzmán: no siempre, el ya consagrado va a funcionar como atraer latinos. Me encanta ahorita de Lynx de las principales universidades, pero también preocuparnos de que el resto.

Javier Guzmán: pues no esté viéndolo todos desde la barrera, sino se aparte del ecosistema y contagiarlo y afirmar, Y una labor es que son mindsets que queremos. No importa si es profesor de cátedra, si terminaste aquí o terminaste allá.

Javier Guzmán: Este es el maíz el que queremos como Tec, y lo podemos hacer único como tú lo dijiste, y que nos dé más relevancia, este y prestigio internacional. Así es. Sí. Bueno, Perdone, estoy muy padre.

Edgar Barroso Systems: No ya estamos terminando nada más. Falta algo muy sencillo. Si tú pudieras hablar con un modelo de inteligencia artificial en 2 030?

Edgar Barroso Systems: ¿qué te gustaría que hubiese aprendido de esta conversación? ¿cuál sería el principio que querrías transmitirle sobre investigación y transformación en el Tec en estos años.

Javier Guzmán: Mhm.

Javier Guzmán: Creo que empezaría por que entendiera la pasión que tenemos todos en el Tec de Monterrey por hacer investigación.

Javier Guzmán: Me gustaría que pudiera haber entendido que investigación de excelencia va de la mano con educación de excelencia.

Javier Guzmán: que no son caminos diferentes, Son simplemente aristas diferentes del mismo plano.

Javier Guzmán: Me gustaría que hubiera entendido esta inteligencia artificial que la apuesta que queremos hacer es de investigación aplicada.

Javier Guzmán: pero que eso no significa que no creamos una investigación básica de frontera.

Edgar Barroso Systems: Mhm.

Javier Guzmán: Lo que vamos a poder hacer

Javier Guzmán: es simplemente el primer paso. Lo vamos a dar con investigación aplicada

Javier Guzmán: y lo demás vendrá vendrá por sí solo.

Javier Guzmán: Me gustaría que entendiera que

Javier Guzmán: en el grupo educativo, el Camps Monterrey es nuestro flagship y lo seguirá siendo y lo tenemos que saber vender internacionalmente.

Javier Guzmán: Yo comento que hay otras universidades en el mundo a nivel top.

Javier Guzmán: que no tienen miles de campos tienen 1 o 2.

Javier Guzmán: Nosotros tenemos una diversidad de campos.

Javier Guzmán: lo cual está bien para muchos propósitos, pero tenemos que

Javier Guzmán: confirmar y reforzar que Carlos Monterrey es y seguirá siendo nuestro campo insignia

Javier Guzmán: para investigación, para educación, de excelencia.

Edgar Barroso Systems: Mhm.

Javier Guzmán: Me gustaría que entendiera que es solo el principio del camino donde va a haber resultados.

Javier Guzmán: pero no es el destino el 20 30 es un punto en el camino que marca una trayectoria que marca, cons que consolida una apuesta.

Javier Guzmán: y me gustaría que entendiera también que.

Javier Guzmán: así como hay estrategias que marcan Direcciones.

Javier Guzmán: hay estrategias que marcan renuncias, y hoy no hablamos mucho de eso.

Javier Guzmán: pero la estrategia implica renuncias y tenemos que tener el valor de aceptar esas renuncias.

Javier Guzmán: consistencia y congruencia en nuestras acciones.

Javier Guzmán: y esto a veces nos gana por la pasión de querer hacer todo y tenemos que elegir.

Javier Guzmán: Creo que eso me gustaría que lo entendiéramos, que lo que se viera reflejado

Javier Guzmán: en los resultados y en las acciones que vamos tomando.

Edgar Barroso Systems: Feliz a ver qué bonita forma de terminar de mi parte. Es todo. Muchísimas gracias por tu tiempo. Y pues Ahora, Sí, María María Adrián. Tú tú nos dices.

Javier Guzmán: No, no. Yo creo que estuvo una conversación muy, muy bonita, muy buena, la verdad.

Javier Guzmán: El compromiso que yo le desea David a cargo de este.

Javier Guzmán: pues tú me lo has dicho, me puedes decir más cosas, pero capacidad humana, pues de repente se me olvida algo o lo pierdo. Pero con el apoyo de este vídeo que se va a llevar a a la gente ahí, no se le va a olvidar nada, entonces.

Edgar Barroso Systems: Es que.

Javier Guzmán: Que no podremos dejar a un lado todo ese valor de lo que nos has compartido. Esa es la intención de esta de esta de esta sesión, de que lo que tú pienses no se nos pegue en el planeta. Sabes que sería muy bueno que en el 20, 30 nos enseñes lo que la gente dijo que está.

Edgar Barroso Systems: Mal Exacto, Javier. De hecho, una de las cosas que estamos haciendo es

Edgar Barroso Systems: visibilizar. ¿cómo tomamos decisión, no nada más, cuál fue la decisión, sino, Y es que estas decisiones se tomaron porque en el 2 026 María Adriana organizó estas pequeñas conversaciones que se subieron a un modelo de inteligencia artificial que a lo mejor te suena arcaico porque es 2 030, pero poco, pero no se tomó la decisión.

Edgar Barroso Systems: sabes, por un grupo de personas reducidos. Fue un proceso, está basado en evidencia. Está basado en datos. Está basado en la inteligencia colectiva, no en retórica, sino matemática del Tec. Y creo que somos el Tec. Nosotros podemos hacer estas cosas no nada más de manera retórica. Insisto, no.

Javier Guzmán: Pero, por ejemplo, esto mismo que hablamos, el que pudiéramos comunicar que esto estamos haciendo sería súper impacto, o sea, que un ejercicio como este se hace con inteligencia artificial para pasar decisiones.

Javier Guzmán: Yo creo que el mundo lo debería saber. Bueno, yo creo que va para allá, porque este pero ahorita no me quiero adelantar, pero vamos a tener a la gente con sus evoluciones tecnológicas, pues va a ser como la sombra que los va a acompañar al 20 30.

Edgar Barroso Systems: Claro.

Javier Guzmán: Esto sí fue retórica, pero porque no veo, no veo nada artificial.

Edgar Barroso Systems: Exacto. Estamos haciendo la memoria que la memoria es data, y esa data se puede conectar a sistemas inteligentes. Es lo que estamos. Eso es lo que hacemos en la empresa. Estamos en el sistema de inteligencia colectiva de querétaro, por ejemplo.

Edgar Barroso Systems: de todo el Estado con toda la data de secretarías de economía. Y otra vez, eso es lo que podemos hacer en el Tec.

Edgar Barroso Systems: porque somos el Tec.

Javier Guzmán: Buenísimo. Gracias. Javier. Gracias. Edgar Este y pues, bueno, este pronto vamos a regresar con el liderazgo y luego con el Consejo. Tenemos que armar todos los hijos para que salgan bien las las las lo que vamos a tejer, ¿verdad? Claro.

Edgar Barroso Systems: Venga que estés muy bien. Mucho gusto. Javier que estés muy bien.

Javier Guzmán: Gracias al equipo que no está claro que sí.

Edgar Barroso Systems: Hasta luego.

## Connections
- [[02-community-ncm]]
