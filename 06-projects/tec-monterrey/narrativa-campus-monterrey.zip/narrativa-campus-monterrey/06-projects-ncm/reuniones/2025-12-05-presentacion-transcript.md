WEBVTT

Horizons Architecture Systems: Ahora. Sí.

Horizons Architecture Systems: Listo. Madre.

MAFC17: Y eso delantero. Y.

Rogelio Sandoval: Sí. Muchas gracias, si no, Pues este una vez que que llevamos, pues? Bueno, ya iniciamos como que con el enfoque narrativa, pero lo cambiamos más bien con el tema de consulta estratégica a nuestros líderes en la comunidad.

Horizons Architecture Systems: Mhm.

Rogelio Sandoval: Ya hicimos la consulta de Juan Pablo, esta Agenda, la de David para enero y pues, falta ver el resto de los líderes y los este

Rogelio Sandoval: y los consejeros. Y en paralelo como que ya se aceleró el tema de definir el plan estratégico de Monterrey

Rogelio Sandoval: porque ahorita.

Rogelio Sandoval: pues ya tenemos que presentarlo un avance antes de irnos de vacaciones a Juan Pablo en enero, equipo, liderazgo y en marzo el consejo directivo

Rogelio Sandoval: entonces ha evolucionado un poquito de los 5 pilares que ya conocían.

Rogelio Sandoval: Y ahora estamos como enfocándonos más a 3 diferenciadores que David nos nos guió,

Rogelio Sandoval: que es el distrito de innovación este postgrados presenciales y la alta selectividad del campo Monterrey.

Horizons Architecture Systems: Investigación ya no.

Rogelio Sandoval: Investigación como embedido en innovación y y posgrados presenciales, porque como que tienen relación

Rogelio Sandoval: entonces, pues, bueno, ya como se acomoda no se acomoda. Pues bueno, eso puede esperar un área de oportunidad, pero lo que platicamos ahora y yo es que tenemos todavía la oportunidad de entrevistar con la gente de Cynthia

Rogelio Sandoval: y quedamos como que alinear también

Rogelio Sandoval: cuál es la mejor manera de aprovechar esta herramienta, pues, para que nos ayude a

Rogelio Sandoval: a ser mejor este proyecto del plan mente. 30 verdad.

Horizons Architecture Systems: Ahí se va a ir.

Rogelio Sandoval: Yo platicamos y sugeríamos que tal vez oriarlo un poquito a a la a la ejecución

Rogelio Sandoval: del proyecto como para alimentar.

Rogelio Sandoval: aunque ahorita paralelamente, ya estamos como que hace poquito somos un taller edgar con los los decanos nacionales y pues también agarramos ideas, pero pues falta ahí, cerrar, piensa y amarrar y y ver qué onda y definir metas. Y todo esto no.

Rogelio Sandoval: Entonces, bueno, no se sabe si quieres comentar algo.

Sarahí OM: No, pues eso, o sea, en realidad creo que digo lo que hablamos con Edgar, y ahí sí ya me gustaría más bien pasarle la palabra a édgar de lo que de lo que tenemos ya pensado Con base en esta información que tenemos, digo, o sea, los los próximos pasos, o sea, ya literal, los que siguen entre esta semana y la siguiente

Sarahí OM: es lanzar a Cintia

Sarahí OM: con el tema de la arquitectura de horizontes marinera. No sé si recuerdas que hicimos la el primer, la primera entrevista que propusimos hacerle a Juan Pablo y a todos los líderes. Era Era de Arquitectura de Horizontes. Entonces es como retomar esa estructura para hacerla a tu equipo.

Sarahí OM: Incluso Roger me decía que había cosas que no dependían solo de tu equipo, sino que eran de nacionales de sí. Entonces, como que.

Sarahí OM: como que lo que ha pasado es que del proyecto narrativa, arrastramos a las personas que íbamos a entrevistar.

Sarahí OM: pero ya es otro proyecto, o sea, ya es otra, ya es otro enfoque. Entonces creemos que tenemos que buscar otras otro público a entrevistar, que es más bien las personas

Sarahí OM: que sí están empapadas del plan 20, 30. Las personas que son las encargadas de ejecutar ese plan, y entonces todos esos gaps de información que Roger se ha dado a la tarea de entender. Es como esto sí, pero es que ya de después vamos con nacional a entonces todos esos gaps que ya ha mapeado Roger, o sea, empezar a lo mejor con Cintia, con tu equipo Okay. Este es el plan. Allá vamos. Ya tenemos el legado, o sea, qué onda, con quién, qué hay que aprender.

Sarahí OM: cuáles son las tecnologías que vamos a utilizar y cómo vamos a llegar ahí.

Sarahí OM: Y después podemos hacer la segunda etapa con estas personas que todavía nos falta la información, no que es los de nacional o que no dependen directamente de ti. De este modo, o sea, le decía Roger que es una forma en la que sí podemos llegar a terminar esta etapa de Cynthia. Por lo menos la primera.

Sarahí OM: para ya tener esta información para enero.

Sarahí OM: que es el enfoque que traíamos pensando nosotros Ayer lo rebotamos, o sea, yo con Edgar. Y luego lo hablé con Roger, de enfocarnos a esta presentación de enero con David Garza.

Sarahí OM: Ay No sé Edgar, si tú quieras decir algo.

Horizons Architecture Systems: Si lo que es lo que es importante de hacer la arquitectura María Adrián y Roger es la parte de hacer una base de conocimientos ya más robusta.

Horizons Architecture Systems: Entonces lo que hacemos es como formar un mini cerebro de Cynthia. Entonces Cynthia va a tener todos los talleres con los decanos. Esa información no sé dónde está, y es la que tenemos que integrar en un solo lugar

Horizons Architecture Systems: ese esa información la vamos a vectorizar, que es ponerle números para que la pueda entender. Un sistema de inteligencia artificial que en este caso es Cynthia.

Horizons Architecture Systems: Y con ese sistema, ya, con esa base de conocimientos de arquitectura de horizontes, Con eso podemos hacer la presentación para enero nos puede dar los insumos.

Horizons Architecture Systems: pero ya le puedes pedir tu cosas. Mariano. Y está muy aterrizado, oye, no está muy volado, ¿no? Entonces tú puedes ir haciendo como estas cosas suaves. Nosotros te podemos hacer un reporte de mira de la información que tenemos. Esto fue lo que es lo que salió, que podría ser útil para la presentación. Ahora. María. Adrián, Cuéntame un poquito de cuál es el punto de la presentación es como este va a ser el plan estratégico

Horizons Architecture Systems: del campus para que podamos tener estos 3 diferenciadores. ¿cuál es el Tercero, mi querido Roger era el distrito y noveno.

Rogelio Sandoval: Y bien.

MAFC17: Selectividad.

Horizons Architecture Systems: Selectividad de profesores y alumnos. Supongo, no.

MAFC17: Sí de los 2, y de es como de 3

MAFC17: patas, alumnos, profesores y de programas. Por ejemplo, ¿qué significa programas que hay programas de cupo límite que programas en donde vamos a admitir solo los mejores en bloques. Entonces todo eso va a empezar a mover este. Y Y hay son esas 3.

MAFC17: Mira, yo yo creo que ahorita. Ya hemos estado, pues este a lo mejor pareciera que ya tenemos el plan y los pilares que yo creo que las bases van a ser las mismas, pero a lo mejor lo estamos acomodando de manera diferente. Este hace

MAFC17: 3 semanas tuvimos un toque base con David. Este David. Dijo a ver cuál es que es lo transformacional del campus al 2 030. Y él se respondió diciendo: el distrito de innovación.

MAFC17: donde la investigación está en la vida

MAFC17: este los posgrados presenciales, que también se relacionan con distrito de investigación

MAFC17: y la selectividad. Entonces, y los otros que teníamos también

MAFC17: en el plan también los vamos a integrar. Pero esos no no son los transformacionales y son los de evolución orgánica que hemos estado llamándole acá nosotros no que si si van a estar

MAFC17: nosotros emocionales, entonces bueno, eso es lo que traemos. Ahorita. Tuvimos unión con los decanos y Juan Pablo, que fue muy rica, reforzó el compromiso de algunas escuelas, otras.

MAFC17: Dije otras más o menos que hay que seguir reforzando. Y tenemos el siguiente. Este haz de cuenta

MAFC17: presentación del plan de de de de Monterrey va a ser con el equipo de liderazgo que, es decir, todo el equipo que depende de David, que es como son, como echar punks. Este.

Horizons Architecture Systems: Mhm.

MAFC17: Es una, y eso yo creo que va a ser entre enero y febrero. No lo sé todavía. Y luego, en marzo al Consejo.

MAFC17: Vamos a presentar al Consejo, No, entonces este es como el camino. Yo lo que quisiera es que, pues, que quedara claro.

MAFC17: Clarito sencillo, pero también con mucha carnita de hacia dónde no, Por ejemplo, ahorita, digo a lo mejor no propio del campus, Pero

MAFC17: Pero, pues preguntas, oye en investigación en salud, en que en Monterrey no esté. Y luego aparte, no hay muchas cosas que no dependen solo de nosotros o de mí. No. Este.

Horizons Architecture Systems: Claro.

MAFC17: Pero que sí tenemos que involucrar este. Pero pero, bueno, yo creo que esa es la ruta que traemos ahorita

MAFC17: este. Y Y bueno, creo que en el camino tenemos que usar a Cynthia para ir recolectando los diferentes. Este vistas como la de los alumnos, el equipo de nosotros, la entrevista de David y algunas otras entrevistas que podemos ir

MAFC17: como recogiendo este cómo se llamaba migajitas en el camino, no.

Horizons Architecture Systems: Sí

Horizons Architecture Systems: a ver. Yo creo que lo que lo que sería súper importante, Ay Caray, el 16 de enero, es súper rápido queridos.

Horizons Architecture Systems: O sea, no es en febrero.

MAFC17: Ya se.

Rogelio Sandoval: No con el tipo liderazgo. Es en.

Horizons Architecture Systems: Confirmado Roger.

Rogelio Sandoval: Sí, o sea, es la fecha que traemos, y era como que Ent se juntan más al mes y que después en enero, febrero, pero parece que va a ser en enero.

Horizons Architecture Systems: Okay. Entonces magran si quieres, lo que podemos es que de ahora en adelante, o sea, el plan sigue, o sea que saquen a Cintia que haga las entrevistas para tener más información.

Horizons Architecture Systems: y nosotros, lo que podemos ir adelantando es con la información que ya tenemos. Y Co: Y conforme vayamos metiendo más María Adrián, te podemos empezar a hacer.

MAFC17: Mhm.

Horizons Architecture Systems: Como la estructura de la presentación.

Horizons Architecture Systems: ¿cuánto tiempo tienes para presentar.

MAFC17: Mira, No, No sé, ahorita, Todavía no sé si ya lo tengamos definido Roger, pero pues pensar en una media hora, pero a lo mejor 15 de presentación y 15 de comentarios no. Este perfecto

MAFC17: podría ser todavía ese tiempo. Lo ajustamos.

Rogelio Sandoval: El de.

Horizons Architecture Systems: Sin duda, y te vamos a cuidar que tengas como 2, o sea, un doble clic y un triple clic, o sea, si alguien te dice, oye, pero ¿cómo hacer esto? Ah, mira, no lo puse en la presentación, pero aquí tengo los datos. Aquí tengo la información

Horizons Architecture Systems: en

Horizons Architecture Systems: te parece. Si nos enfocamos de aquí a febrero para que tú estés tranquilo con esa presentación. Obviamente, lo vamos a tener antes. O sea, tiene que estar.

MAFC17: Y no de acuerdo.

Horizons Architecture Systems: De enero, pero ya ahorita todo lo demás lo podemos dejar para después para que tú vayas tranquilo con esa presentación y nosotros te hagamos unas visualizaciones. Te Hagamos una presentación bonita con buen diseño, etcétera. Y Roger. Lo que necesitamos de ti es que le pases toda la información a Sara y en una carpeta.

Horizons Architecture Systems: y que cada carpeta tenga una descripción de qué es, por ejemplo, taller con decanos y este taller se discutieron tal cosa

Horizons Architecture Systems: taller, con no sé quién con lali. No sé quién, y en este taller se discutieron tales cosas. Creo que eso sería muy importante para nosotros. Y a partir de ahí, ya nosotros podemos empezar a buscar una una estructura María Adrián. Ahora, cuéntame un poquito.

Horizons Architecture Systems: o sea, yo lo que lo que había pensado María Adrián es un es algo así como que si tuvieras una narrativa

Horizons Architecture Systems: y

Horizons Architecture Systems: muy, muy basada en, por ejemplo, este este discurso, no decir oigan, miren en los últimos 5 años. Esto es lo que ha pasado en el campus.

Horizons Architecture Systems: y eso es lo que ha pasado en el mundo en el Monterrey, en México, y estamos viviendo un mundo súper incierto con un montón de velocidad y justo. Por eso tenemos que empezar a ver

Horizons Architecture Systems: qué vamos a hacer como tec-monterrey.

MAFC17: Claro.

Horizons Architecture Systems: Que es un es un momento para ser muy audaces. Creo que el Tec necesita ser más audaz y tenemos claridad de qué es lo que queremos lograr. Tenemos estos 3 pilares con estas 3 patitas. El último

Horizons Architecture Systems: y lo que a mí me gustaría decir. Y por eso vamos a hacer 3, o sea, 3, 4, 5 cosas. Porque si no imagínate, serían muchas que pudieras explicar ¿Cómo vas a atacar eso desde el campus? Ahora, como tú dijiste, ahorita. Y eso es una pregunta para ti maradra.

Horizons Architecture Systems: Tú tienes control del campus, pero no tienes control, por ejemplo, de contratar profesores o contratar o hacer selección de estudiantes.

Horizons Architecture Systems: Entonces, ¿qué quieres que nos enfoquemos en el campus.

MAFC17: No, Yo creo que hay que incluir todo

MAFC17: porque, por ejemplo, las escuelas dependen de M de mí también. Entonces tengo cierta incidencia.

Horizons Architecture Systems: Este, el distrito de Innovación, por ejemplo. Hoy comentamos con la ruleta, con con David y todo el equipo, y Juan Pablo.

MAFC17: De que dice a ver este. Las escuelas y los institutos están en expedition y tienen que dar resultados, y sabemos que no dependen de ustedes, pero tienen que hacer esa bronca suya.

MAFC17: Pues, bueno, o sea, en otras palabras, este lo que pase es mi responsabilidad. Aunque no esté en mi creencia directa, hay cosas que sí están muy directamente

MAFC17: y otras no tanto. Entonces hay que articular

MAFC17: con el actor correspondiente, pero no lo puedo dejar fuera. No.

Horizons Architecture Systems: Okay? Perfecto.

Horizons Architecture Systems: Vale, pues mira si quieres lo que podemos hacer es, hagamos, saquemos a cintia, siguientes pasos: serían sacar a Cintia, recopilar la información, Roger, integrar toda la información que tienes hasta ahorita. Toda O sea, no nos da resúmenes danos tíranos, todo nomás, explícanos qué es cada cosa, brevemente, o sea, esto es un taller de no sé qué. Esto es una presentación de, no sé quién.

Horizons Architecture Systems: etcétera, y dan los puros documentos que estén validados por María Adrián, por ejemplo, que la versión

Horizons Architecture Systems: sea adecuada, etcétera. Y también, Y Una cosa es que no conecte María, empresa.

Horizons Architecture Systems: En este mundo incierto, los principios de don Eugenio Garza Sada son más relevantes que nunca, y ahí conectas con lo que decía Juan Pablo. No que quiero regresar a los principios de Don Eugenio Entonces.

Horizons Architecture Systems: o sea, el chiste, es tomar en cuenta las opiniones, principalmente de Juan Pablo y del liderazgo, pero también de las otras personas

Horizons Architecture Systems: y que tú, naturalmente, integres todo esto en un sistema y no en silos, que es lo que ya hemos hablado varias veces.

MAFC17: ¿de acuerdo? Edgar? No, pues me parece muy bien este la verdad. Muchas gracias. Yo ahorita, no. De acuerdo a Edgar. Y Y bueno, ahí les pido, no sé si cierran la conversación, este ahorita. Voy a entrar a

MAFC17: que haya seguridad y y hierro ahí con Roger que lo que recordamos no.

Horizons Architecture Systems: Vale perfecto desde que estés Muy bien.

MAFC17: Es mucho.

Sarahí OM: De a.

Horizons Architecture Systems: Bien hasta luego.

Horizons Architecture Systems: pues eso, Roller ahorita. Ya estamos en modo a ser presenta. O sea, tenemos que tener a Cintia, a la Cintia, que lo sabe todo.

Rogelio Sandoval: Mhm.

Horizons Architecture Systems: Entonces estamos, ya que nos digas estas presentaciones, todas son actualizadas. Están las personas que tienen que estar, porque luego lo que nos pasó alguna vez es. Ah, sí, esa presentación que te mandé esa no porque esa persona ya ni trabaja aquí, no.

Sarahí OM: Tenemos que actualizar los pilares. O sea, como que creo que lo más sencillo es que ya tengamos las versiones finales, que creo que es la presunción que me estás que me estás pasando. No estás metiendo todo en una, según yo.

Rogelio Sandoval: Sí ejecutivamente, pero obviamente hay bases de datos y cosas de cada punto.

Rogelio Sandoval: Entonces, Pues sí, yo creo que

Rogelio Sandoval: si valdría la pena tener todo eso. Ordenadito en una sola carpeta, como dicen.

Horizons Architecture Systems: Sí.

Rogelio Sandoval: De toda la información que yo creo que es relevante, que va a tener a la mano, verdad.

Horizons Architecture Systems: Exacto.

Rogelio Sandoval: Este.

Rogelio Sandoval: Creo que ya quedamos entonces que si estaría padre entrevistar con Cynthia al equipo Mar Adrián como primera idea.

Horizons Architecture Systems: Sí, Sí.

Rogelio Sandoval: Y a la par, vamos identificando como Keepersons de oye, pues, por ejemplo, los posgrados ahorita, pues dependen de no sé quién y sí, bueno, esa persona, y que también diga: oye cómo y por qué y que cuáles vayas.

Sarahí OM: En las entrevistas Roger, porque a la hora que le digamos boycoo quién necesitas para sacar esto, ¿Con quién vas a sacar esto. La gente va a decir no, pues es que yo necesito trabajar con el nacional de comunicación o con posgrados o con tu lastraes.

Sarahí OM: No, Pues es que la gente de no sé de becas, o sea, entonces ahí podemos empezar a mapear como toda la gente que en realidad toda la comunidad que va a hacer que pase todo eso. Y ya de ahí decidimos

Sarahí OM: a quién más entrevistamos nomás, que pasó. Gracias. Oye el acuérdate que necesitamos

Sarahí OM: el nombre, el puesto, el puesto y la semblanza.

Rogelio Sandoval: Sí que el equipo de Adrián, o sea, ese no hay problema.

Horizons Architecture Systems: Sin broncar.

Rogelio Sandoval: Ajá de que esta tarde lo tenemos. No.

Horizons Architecture Systems: Vale.

Rogelio Sandoval: Este, bueno entonces va a entrevistar a Cintia y la info de todo de toda la carpeta.

Horizons Architecture Systems: Todo el.

Rogelio Sandoval: Bueno okay, pues yo creo que

Rogelio Sandoval: también, pues yo creo que entre pues hoy voy a estar metiendo todo.

Horizons Architecture Systems: Perfecto.

Rogelio Sandoval: Este.

Rogelio Sandoval: Tal vez me ocupo. Me tome un poco más de tiempo, también mañana un ratito, o sea, como que, Pues sí es así, entonces no sé que igual me puedo comprometer a que

Rogelio Sandoval: ya esté todo el enfoque.

Rogelio Sandoval: qué qué opin qué cree que sea lo mejor, obviamente, ya, pero puede ser mañana al mediodía o.

Sarahí OM: Puede ser el lunes si quieres.

Rogelio Sandoval: Un es.

Horizons Architecture Systems: Y el lunes sin problemas.

Rogelio Sandoval: Es el.

Horizons Architecture Systems: Carlos, ya estamos trabajando en la narrativa, independientemente del detalle de la información o se.

Rogelio Sandoval: Sí.

Horizons Architecture Systems: Que la narrativa se puede ir construyendo. Por eso te digo, Por ejemplo, Juan Pablo nos decía mucho en su entrevista, no si te acuerdas que él quería regresar a los principios de.

Rogelio Sandoval: Sí.

Horizons Architecture Systems: No. Entonces, por ejemplo, decir y justo en este entorno en el que la inteligencia artificial y Trump y las guerras, y todo está de la chingada. Este es el momento en que necesitamos esos principios y valores con una nueva perspectiva, porque sí. Luego se me quedó medio poquito anticuado en algunas cosas.

Horizons Architecture Systems: No lo vamos a decir, no lo vamos a decir. Pero como como retomar ese valor, esos esos valores tan importantes en este momento histórico.

Horizons Architecture Systems: Ahora, lo que es importante es comunicarle esto también a nuestra Comunidad, que eso es una parte importantísima, porque si no, no se va a poder hacer todo esto de colaboración y algo que no hemos podido hacer porque Juan Pablo también lo dijo en una entrevista: es nunca hemos podido hacer que trabaje que con los institutos colaboren entre sí te acuerdas que también.

Rogelio Sandoval: Dijo y.

Horizons Architecture Systems: Le pregunté y dijo, eso nunca lo hemos logrado. O sea, dijo algo así, ¿no? Entonces creo que sea. La idea es empezar a lograr lo que no se ha logrado, no sea ese es el nuevo plan. Eso es lo que es nuevo. No, no es que vamos a empezar de 0,

Horizons Architecture Systems: es que ya tenemos un montón de institutos de escuelas, de proyectos diferenciadores como el expedition y a partir de ahí, y próximamente el hub de innovación. Entonces ahí el chiste es que mara de tome lo que ya tiene

Horizons Architecture Systems: y lo haga mejor. Por ejemplo, te pongo un ejemplo de una idea, pero yo lo que diría es, no nos metamos a poner proyectos, pero, por ejemplo, decir establecer un programa de Platicaba Saray, un programa de

Horizons Architecture Systems: sabáticos, o sea, cualquier universidad buena en el mundo. Como profesor, te da cada 4 años, Te da un sabático y tú te puedes ir a donde tú quieras hacer un libro o a escribir un paper o o a pensar. No. Entonces imagínate que el Tec de Ca: El campus Monterrey hace un programa de sabáticos

Horizons Architecture Systems: para que la gente diga, ah, me voy a hacer mi sabático a Monterrey porque está increíble. Me dan Esto me dan lo otro. Me ofrecen. No sé qué en el campus, y no sé qué, entonces podríamos atraer profesores gratis de muy buenas universidades a que pasen su años sabático, porque el año sabático se los pagan.

Horizons Architecture Systems: o sea, la universidad, se los paga. Entonces, en lugar de estar en, no sé. Cambridge, que es carísimo, pues te vienes a tra a a trabajar en tu libro un año al campus, te dan.

Rogelio Sandoval: Y aquí vamos a tener residencias para ese tipo de gente. Exactamente.

Horizons Architecture Systems: Residencias nuevas pueden vivir en el campo si quieren o pueden vivir en un departamento, da igual, pero el chiste es que les ofreces un espacio en la biblioteca. Hablar con alumnos asistentes de investigación, se imagínate si a mí me dijeras vente a hacer tu sabático aquí. Güey y te va a poner a 3 estudiantes a que te ayuden a escribir tu libro Doood.

Horizons Architecture Systems: Y te voy a dar una biblioteca y te voy a dar un espacio. Y te voy a dar todo lo que necesites para que tú escribas tu libro

Horizons Architecture Systems: está Chingón. Entonces.

Rogelio Sandoval: En China No.

Horizons Architecture Systems: No. Entonces.

Horizons Architecture Systems: o sea como ese hoy tenemos con 25 ideas ya, Pero el chiste es como las hilamos para que no sean como cosas separadas, por ejemplo.

Rogelio Sandoval: Ya.

Horizons Architecture Systems: Y pensamos en los posgrados, no en los posgrados. Son el punto de convergencia presencial, ahí convergen profesores, estudiantes, etcétera.

Horizons Architecture Systems: to y e industria. Y la entonces hay que ver cómo traemos a la industria a través de posgrados y educación continua para que vengan y se junten.

Horizons Architecture Systems: Y entonces, a partir de ahí, poder empezar a atraer a mejores alumnos a través de los posgrados y de la selectividad de estas 3 patitas que nos decías. Tú me faltaba ese dato de información.

Horizons Architecture Systems: Y luego de ahí como poder convencer a ciertos estudiantes que se vengan a hacer investigación al expedition o a los institutos ¿no? Y cómo la expedición juega esta parte tan importante. No sé cómo le ha ido a la expedición. Tengo que hablar con Lali y con Edgar.

Rogelio Sandoval: Ahí tengo reportes de eso también. Entonces estuvo.

Horizons Architecture Systems: Sí.

Rogelio Sandoval: Un año ya fue un año y pues

Rogelio Sandoval: padre, o sea, sí, ha habido de que hay gente ahí recitada al 2 por 100 mundial Este se han vendido los proyectos, pues bastante buenos.

Horizons Architecture Systems: Mhm.

Rogelio Sandoval: Ya ahí cuando empieza esa colaboración entre escuelas e institutos. O sea, como que anecdóticamente sale como que hay. Y yo conocí a alguien de diseño y a ver y cómo me hice como que ya se está dando esta colaboración.

Horizons Architecture Systems: Colisiones. No.

Rogelio Sandoval: Esas colisiones que antes decía ayer fui a una charla y económica. Es que no estamos de que en el sótano del centro de tecnología como Harry Potter. Abajo, las escaleras.

Horizons Architecture Systems: En el.

Rogelio Sandoval: General dijo, y acá recibe gente, y están los recorridos, y o sea, más como open bien diferente. Y aparte, o sea, cosas de locas. Como

Rogelio Sandoval: oye, es que estoy loco que pueda estar su super entrega. Al final, no mi máquina genómica de 1 000 000 de dólares y pueda bajar al oxxo y echarme un café y subir, o sea.

Horizons Architecture Systems: Sí.

Rogelio Sandoval: En donde pasa eso o.

Horizons Architecture Systems: De acuerdo.

Rogelio Sandoval: Ni en otras universidades. Está tan mezclado el.

Horizons Architecture Systems: De arquitectura.

Rogelio Sandoval: Altura, ¿sabes? Pero bueno, les ha ido bien. Puede ir mejor.

Rogelio Sandoval: Va un año perfecto.

Rogelio Sandoval: Y bueno, creo que me encanta esto

Rogelio Sandoval: también ahí. Les voy a compartir también como que una presentación que hizo Ciudad de México como referencia del

Rogelio Sandoval: Ahorita, Juan Pablo está, como en modo muy pragmático

Rogelio Sandoval: en este sentido, como que o Okay chido, programas, ¿Pero cuánto Ya siento? Ahorita? ¿está diciendo números así con

Rogelio Sandoval: lo que dijeron las escuelas en taller y que no, y que falta y les echamos coco no

Rogelio Sandoval: este esta innovación ya va avanzado El presente humano de esa presentación también se las doy y selectividad. Hay ciertas disyuntivas. Este

Rogelio Sandoval: como que también grabé voz del taller, entonces también.

Rogelio Sandoval: De los.

Horizons Architecture Systems: Sí.

Rogelio Sandoval: Este. Y tengo algunas notas de voz que digo malamente, No, no pregunto, pero ya esté acá entre nos y

Rogelio Sandoval: este. Y bueno, creo que todo eso va a ayudar.

Rogelio Sandoval: Yo les comento. Ahorita. Estoy también en modo pragmático y pues el martes vamos a ver a Juan Pablo que puedes hacer el taller, y pues estás en las metas posibles. No sé qué,

Rogelio Sandoval: pero yo creo que, como dicen, vamos a ir construyendo como para estar más armaditos en el aire, tener con lo que diga la raza. Y así, entonces eso me deja más tranquilo.

Rogelio Sandoval: Pero pues seguimos avanzando, ¿verdad? Este como quiera y también en tiempo real, Ahí va a estar viendo, Van a estar viendo cómo van avanzando. Y cada que tenga hoy presentamos esto, pum. Ahí lo subes.

Horizons Architecture Systems: Súbelo ahí a esa carpeta.

Rogelio Sandoval: Y bueno, este le hacemos así. Y me parece bien arrancar con el equipo Adrián como

Rogelio Sandoval: piloto de Cynthia y y darle.

Horizons Architecture Systems: Lo oyes.

Rogelio Sandoval: Que el.

Horizons Architecture Systems: Tenemos que enfocarnos en que se tiene que decir.

Horizons Architecture Systems: O sea, en esa presentación a David Garza, tú también nos puedes ayudar a decir Güey, yo lo que he visto de todo esto porque tú, porque nosotros estamos viendo desde afuera, y solo se a través de documentos, pero tú que has estado ahí

Horizons Architecture Systems: y me dijo, Yo creo que lo que más le gustó a Juan Pablo fue esto lo que más le ha gustado David. Lo que más le ha llamado la atención es, por ejemplo, que Cynthia pueda ser Cynthia o como se vaya a llamar

Horizons Architecture Systems: un agente de inteligencia artificial del campus. Es básico. O sea, eso es cualquier universidad razonable, ya lo está pensando, cuál cuál inteligencia artificial de la universidad? Y como la gente puede tener

Horizons Architecture Systems: interacciones con él para que me diga qué eventos. Hay donde puedo encontrar cosas con quién me puedo juntar todo eso? Eventualmente va a ser normal. No es como tener.

Rogelio Sandoval: Como el como la hora del Street.

Horizons Architecture Systems: Como el ahora, exactamente entonces.

Horizons Architecture Systems: En fin, o sea, lo que te quiero decir, es

Horizons Architecture Systems: también nos ayuda mucho la síntesis, cosas que María Adrián. Diga esto. Sí lo tengo que decir, porque él tiene más contexto que ninguno de los que estamos en esta llamada. Tú tienes más contexto que sale y yo. Entonces tienes que ver como cuáles son las reacciones. Yo te preguntara cuáles han sido las cosas que han presentado

Horizons Architecture Systems: no nada más ustedes, sino en general, y que Juan Pablo y David dicen ándale. Eso es lo que quiero. Por ejemplo, no sé si te suena algo así.

Horizons Architecture Systems: Te acuerdas de.

Rogelio Sandoval: Si hay algo que sí le llamó, así como que el

Rogelio Sandoval: hicimos una visualización de los programas de alta selectividad.

Horizons Architecture Systems: Mhm.

Rogelio Sandoval: Y como que había muy claro de que a Ok, puedo subir de estos programas a estos programas como.

Horizons Architecture Systems: En el.

Rogelio Sandoval: Historias. Eso le este ya en.

Sarahí OM: Y a Ciudad de México. ¿cómo le fue en esa presentación Roger la que nos vas a compartir, que no podemos compartir.

Horizons Architecture Systems: De Mcinroe Mhm.

Rogelio Sandoval: No, no, No tengo que decir de hace cuenta lo que vamos a ser nosotros, pero lo hizo la autoridades Ciudad de México.

Rogelio Sandoval: Y bien, o sea, como que yo creo que

Rogelio Sandoval: un ten comentario que le dijeron fue porque en Ciudad México ahorita. La estrategia es oye, pues ahí hay un chorro de potencial de oportunidad. Y está todo de verdad. Y nosotros, pues no somos tan relevantes. Entonces, ¿cómo nos hacemos más relevantes en, por ejemplo, investigación que nos ven fuerte y en salud que nos ven fuerte. Y así,

Rogelio Sandoval: Entonces estamos apostando a lo que no estamos fuertes.

Rogelio Sandoval: Entonces el Consejo dijo: oye, pues, chido. Pero

Rogelio Sandoval: pues, para que lo apuestas con el fuerte mejor apuesta en lo que sí. El fuerte también, o sea, no te olvides de eso.

Rogelio Sandoval: como que ese tipo de comentarios hacen.

Rogelio Sandoval: este. Y creo que sí. Les pidieron de que oye, pues vengan más acá y hagan más presencia. Y la verdad.

Horizons Architecture Systems: Mhm.

Rogelio Sandoval: Así que les fue horrible. Superbién, No sé,

Rogelio Sandoval: pero pues también si consigo algo de info, pues lo pongo ahí como.

Horizons Architecture Systems: No te.

Rogelio Sandoval: De lo que sé, o sí.

Horizons Architecture Systems: Dime.

Rogelio Sandoval: Es que, por ejemplo, en Ciudad de México, sa comparativamente Ciudad de México, este

Rogelio Sandoval: pues, como está haciendo Catshot a lo que hoy tiene Monterrey.

Horizons Architecture Systems: Mhm.

Rogelio Sandoval: Profesores con equis doctorado en selectividad de alumnos. O sea.

Rogelio Sandoval: estaba Bihind, y está haciendo Cachop.

Rogelio Sandoval: Y acá más bien la perspectiva más que comparte con otros campos, porque eso, pues siempre es mañanas. De hecho, algo importante es tener cuidado en

Rogelio Sandoval: es que yo sé mejor que tú mejor que

Rogelio Sandoval: no. O sea, más bien pensar más en hay que ser punta de lanza

Rogelio Sandoval: y, por ejemplo, Juan Pablo se ha dicho es que

Rogelio Sandoval: en Monterrey, más que retos, es un tema de oportunidades.

Rogelio Sandoval: O sea, como que tengo la oportunidad de ir más para allá.

Rogelio Sandoval: Este es la punta de lanza

Rogelio Sandoval: este, porque en teoría, también ya se ha declarado de que

Rogelio Sandoval: en su momento también están como discutiendo si Monterrey, el campus o no es algo así. Pero como causan dañoras y quiten eso. Más bien, va a ser campus insignia.

Rogelio Sandoval: como el flagship. Entonces, como que eso ya se está como socializando y con palos No, sí que sin insignia, así mejor. Llegan así posicionarlo así.

Rogelio Sandoval: Casi la gente no cuestiona tantas como, pues sí, ese es nuestro nuestro campus insignia de habla, en, o sea, el origen el que quiera, ¿no?

Rogelio Sandoval: Entonces eso también va.

Rogelio Sandoval: De hecho, creo que hay.

Rogelio Sandoval: Yo his tenía una propuesta de como narrativa.

Rogelio Sandoval: Este, obviamente creo que va a salir cosas mejores con todo lo que investigamos.

Rogelio Sandoval: pero era un poco inspirada en en la de Ciudad de México.

Rogelio Sandoval: Pero con la perspectiva de Monterrey.

Rogelio Sandoval: este igual y puede ser bueno, y también te los pongo este.

Rogelio Sandoval: ¿qué otras cosas dijeron más importantes.

Rogelio Sandoval: O sea, también creo que una complejidad de Monterrey siempre es eso. O sea, como que

Rogelio Sandoval: la colaboración es un reto, Y aquí es como, pues, el tema de que posee el capital. Pero también

Rogelio Sandoval: es como está el gobierno federal, pues también el Gobierno Ciudad de México. Sabes

Rogelio Sandoval: que es el caso de Mario Adrián y pues las potencias.

Rogelio Sandoval: Entonces, pues sí, esa colaboración es es retadora

Rogelio Sandoval: y también. Algo que siempre escucho Es como que es que Monterrey le quedamos tirar a todo

Rogelio Sandoval: respirator. No hay enfoque.

Rogelio Sandoval: y eso es un tema que voy a tener una investigación como que, pues a ver, hacemos

Rogelio Sandoval: un poco o no.

Rogelio Sandoval: Digo, en paralelo también Investigación y Javier guzmán tiene su track, entonces también voy a buscar que podamos entrevistar a Javier Guzmán porque, pues él nos va a dar también un buen insight de esa parte, que es súper relevante.

Horizons Architecture Systems: Sí.

Rogelio Sandoval: Este. Y pues, bueno, ¿verdad? Yo creo que sería muy bueno.

Rogelio Sandoval: Ahorita. No se me ocurre otra cosa así como esto, pero siempre que me acuerde.

Horizons Architecture Systems: Ándale apúntalo, lo que sea.

Rogelio Sandoval: No sé, éste lo mandó a Ti y Saray.

Rogelio Sandoval: o lo pongo en la carpeta, como en.

Sarahí OM: ¿y sabes qué? Te voy a ser un excelente para los 2? Si te parece, es así como este es el documento. Esta es la Liga y una breve descripción así de esto es, o sea, eso nos ha servido mucho a nosotros con cuando estamos construyendo bases de conocimiento.

Sarahí OM: porque ya todo mundo tiene acceso y sabe qué es cada cosa. Y ya lo vas. Metiendo. Y ahí lo vamos actualizando. ¿sí? Si quieres, ahorita, lo hago.

Sarahí OM: O sea, no sé si lo vamos a hacer una carpeta de onedrive tuya o lo hago en un drive nuestro para que no te porque yo sé que ustedes ya no tienen espacio en el drive, ¿verdad?

Rogelio Sandoval: Y pues, mira, no sé qué mejor para efectos de yo también. Por seguridad siempre me piden que esté como en en cuando aire. Todo eso.

Sarahí OM: No está bien en en tu Android, y ya yo nada más. Me das acceso a la carpeta.

Rogelio Sandoval: Sí, ahí puedo ir sumando todo. Y te hago dueña de de esto y para que tú pongas edi edits y todo, no

Rogelio Sandoval: de acuerdo aquí, si tengo un chorro de información, pero pues

Rogelio Sandoval: creo que lo mejor es que ponga información limpia y ordenada Ahí, pues de aquí el lunes, pues ya sea como la base de conocimiento de todo lo que se ha avanzado, Verdad que también task que tengo aquí que quiero hacer, pues ya.

Horizons Architecture Systems: A que lo.

Rogelio Sandoval: Una situación perfecta la agarra exactamente.

Rogelio Sandoval: pero, bueno, chicos. Este me parece bien

Rogelio Sandoval: darse conocimiento en la carpeta y perfiles de los el equipo Mont, Adrián.

Sarahí OM: Y es.

Rogelio Sandoval: Y.

Sarahí OM: Los transcripts de Juan Pablo y de las estudiantes que entrevistó Betty también.

Rogelio Sandoval: Ándale perfecto.

Rogelio Sandoval: Y también voy a poner como que propuestas de quién vas a entrevistar.

Rogelio Sandoval: Pero como por tu tu fin y validados, no.

Sarahí OM: Mhm.

Rogelio Sandoval: Y y bueno, voy a seguir con la presentación este para el martes.

Rogelio Sandoval: Y y ahí vamos, como va avanzando, no si quieres.

Rogelio Sandoval: O sea que tocamos, va a ser un poco seguido Saray, si quieres de que próxima semana y cualquier cosa nos dices edgar como quiera. Ya hice una sesión, tenemos otra sesión. El 16 de diciembre

Rogelio Sandoval: nos consiguió espacio, está está sushi y vi que está disponible edgar entonces, pues el ejercicio se mandala ahí. Nos vemos, si les parece, se puede puede ser otro toque básico. Me adrián en un par de semanas.

Rogelio Sandoval: Este.

Horizons Architecture Systems: Vale.

Rogelio Sandoval: Incluso ahí podemos tener algún draft. O sea, es que estoy haciendo la presentación. Entonces, pues, vamos rebotando la junta.

Horizons Architecture Systems: No, la presentación debe ser texto, o sea, de primero decir esto, lo vamos. Ire, esto lo vamos, y de esto y ver qué le parece a María Adrián. Si yo voy a empezar a trabajar en eso, incluso a ver si el fin de semana. Puedo, o el lunes o martes, más bien

Horizons Architecture Systems: y lo antes posible, Y hay que recibir retro de María Adriana no seas maldito. Avísale ya no le alcancé a decir yo, pero dile que vamos a tener que estar en contacto con él, mucho, o sea, a lo mejor un mensaje por Whatsapp o lo.

Rogelio Sandoval: No el Whatsapp siempre lo lee y correos siempre lo lee. O sea, eso.

Horizons Architecture Systems: Ah, Vale.

Rogelio Sandoval: Tú le demandas, eventualmente lo te lee y te contesta. Eso no.

Horizons Architecture Systems: Aj.

Rogelio Sandoval: Perfecto colega, soy bien. Yo tengo que correr, pero me dio mucho gusto verles y estamos a estamos hablando.

Rogelio Sandoval: Perfecto. Muchas gracias. Gracias Y gracias. Nos vemos Edgar.

## Connections
- [[06-projects-ncm]]
