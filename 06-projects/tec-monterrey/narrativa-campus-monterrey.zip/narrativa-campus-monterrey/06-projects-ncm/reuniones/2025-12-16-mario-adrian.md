
AI-generated content may be incorrect

Juan Rogelio Sandoval González started transcription

Mario Adrián Flores Castro
0 minutes 3 seconds0:03
Mario Adrián Flores Castro 0 minutes 3 seconds
Si le interesa.
Mario Adrián Flores Castro 0 minutes 5 seconds
Pues colaborar ahí dando algunas opiniones sobre este tema, entonces sí.

Edgar Arturo Barroso Merino
0 minutes 8 seconds0:08
Edgar Arturo Barroso Merino 0 minutes 8 seconds
Sí, claro, es un tema que me encanta, claro que sí, María Adrián.

Mario Adrián Flores Castro
0 minutes 14 seconds0:14
Mario Adrián Flores Castro 0 minutes 14 seconds
¿Cómo ves, Edgar? Sí, ayudarías a.

Edgar Arturo Barroso Merino
0 minutes 16 seconds0:16
Edgar Arturo Barroso Merino 0 minutes 16 seconds
Y fíjate que te va a dar risa, pero mi yo di la clase de ética el año pasado y la voy a volver a dar de ética en la inteligencia artificial, la ciencia de datos y la última clase hablamos de religión y AI.

Mario Adrián Flores Castro
0 minutes 21 seconds0:21
Mario Adrián Flores Castro 0 minutes 21 seconds
Super.
Mario Adrián Flores Castro 0 minutes 29 seconds
Pues ahorita, ahorita este es el tema. De hecho, aquí hay al lado del campus hay una iglesia que se llama San Juan Bosco, que nació junto con el TEC y de hecho es un iglesia universitario. Ahí el , ahí van a comer los 200 alumnos todos los lunes y bueno.
M

(MTY//CMTY//Rectoria//4 Empatia e Inclusion (Proy.,Pint.,Cap.4))
0 minutes 29 seconds0:29
0 minutes 29 seconds
Vale.

Edgar Arturo Barroso Merino
0 minutes 37 seconds0:37
Edgar Arturo Barroso Merino 0 minutes 37 seconds
Mhm.
Edgar Arturo Barroso Merino 0 minutes 38 seconds
Mhm.

Mario Adrián Flores Castro
43 minutes 36 seconds43:36
Mario Adrián Flores Castro 43 minutes 36 seconds
No, sí importa, este sí importa, importa mucho. Fíjate que me decía Carles que Hugo Garza, que lo conoces, hizo un agente para ver cómo dialogar con los con el equipo de liderazgo, todos los que dependen David, porque o sea, imagínate Juan Pablo, Bruno o Zepeda.

Edgar Arturo Barroso Merino
43 minutes 38 seconds43:38
Edgar Arturo Barroso Merino 43 minutes 38 seconds
No importa muchísimo.
Edgar Arturo Barroso Merino 43 minutes 45 seconds
Sí.

Mario Adrián Flores Castro
43 minutes 54 seconds43:54
Mario Adrián Flores Castro 43 minutes 54 seconds
O sea, son todos unos este egos y son agente para saber cómo va a dialogar con ellos porque no se puede poner de acuerdo, ¿no? Pues algo así.

Edgar Arturo Barroso Merino
43 minutes 58 seconds43:58
Edgar Arturo Barroso Merino 43 minutes 58 seconds
Sí.
Edgar Arturo Barroso Merino 44 minutes 5 seconds
Exactamente exacto, algo así, podemos hacer algo así, sí.
Edgar Arturo Barroso Merino 44 minutes 11 seconds
Va.

Mario Adrián Flores Castro
44 minutes 11 seconds44:11
Mario Adrián Flores Castro 44 minutes 11 seconds
No muy bien, sale Edgar, pues este.

Edgar Arturo Barroso Merino
44 minutes 13 seconds44:13
Edgar Arturo Barroso Merino 44 minutes 13 seconds
Pues listo, si quiere nomás Roger, nomás hay que meterle el acelerador para aunque ya podamos empujar un poquito, que está muy bien 2 semanas, si me gustaría, yo ni le voy a decir a mi equipo, o sea, les voy a decir que para el 9 tenemos que tener algo muy claro, al menos la narrativa ya para que esté listo para que ustedes o nosotros hagamos la presentación bonita.

Mario Adrián Flores Castro
44 minutes 25 seconds44:25
Mario Adrián Flores Castro 44 minutes 25 seconds
Órales.
Mario Adrián Flores Castro 44 minutes 28 seconds
Sí.

Edgar Arturo Barroso Merino
44 minutes 34 seconds44:34
Edgar Arturo Barroso Merino 44 minutes 34 seconds
Y tú ya te sientas tranquilo para que para que sepas la puedas practicar, la puedas mejorar, la puedas pinchar a 23 gentes de tu confianza para que está bueno, pero quítale, ponle, cámbiale, sácale y ya te quedes tranquilo, María, para que no te la van a dar un día antes de tu presentación.

Mario Adrián Flores Castro
44 minutes 40 seconds44:40
Mario Adrián Flores Castro 44 minutes 40 seconds
So.
Mario Adrián Flores Castro 44 minutes 49 seconds
No, excelente Edgar, oye, por aquí iría a Sarahí estos días, este la yo la hasta le daba un tour ahí la traía bien, vamos para acá, vamos para acá, vamos para acá. Dijo, estaría ahí, así como que traía pendientes este, pero ahí la traía mostrándole y le y creo que presentan mañana en el demo de ahí algo así o el jueves.

Edgar Arturo Barroso Merino
45 minutes 7 seconds45:07
Edgar Arturo Barroso Merino 45 minutes 7 seconds
Sí, creo que el jueves, el jueves.

Mario Adrián Flores Castro
45 minutes 8 seconds45:08
Mario Adrián Flores Castro 45 minutes 8 seconds
¿Este jueves y Edgar, este cómo le hacemos para tener una sucursal de arquitectura aquí? Este o una, pues que sea un agente el que esté para que no batalles este y ya nos quitamos el problema de lo que estén físicamente acá.

Edgar Arturo Barroso Merino
45 minutes 17 seconds45:17
Edgar Arturo Barroso Merino 45 minutes 17 seconds
Mira.
Edgar Arturo Barroso Merino 45 minutes 22 seconds
Ándale.

Mario Adrián Flores Castro
45 minutes 27 seconds45:27
Mario Adrián Flores Castro 45 minutes 27 seconds
Pero si lo necesitamos y yo quiero decir que Arquitectura Horizontes es parte porque ya tenemos 20 startups que se están juntando con nosotros, este, pero me gustaría decir que sí, pero necesito no solo tus sí, pero cómo respaldar ese sí.

Edgar Arturo Barroso Merino
45 minutes 29 seconds45:29
Edgar Arturo Barroso Merino 45 minutes 29 seconds
Sí.
Edgar Arturo Barroso Merino 45 minutes 36 seconds
Sí.
Edgar Arturo Barroso Merino 45 minutes 45 seconds
Mira, nosotros tenemos ahorita 2 leads como muy avanzadas, uno con Signux y otro con Proeza.
Edgar Arturo Barroso Merino 45 minutes 53 seconds
Esas 2 empresas parece que vamos a firmar algún tipo de contrato el próximo año.
Edgar Arturo Barroso Merino 45 minutes 59 seconds
Si nos dan uno de los 2, incluso ya nos alcanza para contratar a alguien en Monterrey, o sea, una persona, o sea, física.

Mario Adrián Flores Castro
46 minutes 9 seconds46:09
Mario Adrián Flores Castro 46 minutes 9 seconds
Y le damos espacio acá en el expedition del hub de innovación, este para que también esté conectado al ecosistema y donde no ande no ande solo por ahí bailando. Le comenté a Sarahí que en expedition está Singer, su centro de innovación, no sabía, no sabía Sarahí dije, caray.

Edgar Arturo Barroso Merino
46 minutes 18 seconds46:18
Edgar Arturo Barroso Merino 46 minutes 18 seconds
100%.
Edgar Arturo Barroso Merino 46 minutes 24 seconds
Mhm.

Mario Adrián Flores Castro
46 minutes 28 seconds46:28
Mario Adrián Flores Castro 46 minutes 28 seconds
Yo aquí está, tienen la oficina de innovación de signos aquí con nosotros. Entonces digo, digo, eso pues dice, caray, entonces aquí andan negociando y no sabía que estaba aquí en la empresa dentro de Expedition.

Edgar Arturo Barroso Merino
46 minutes 41 seconds46:41
Edgar Arturo Barroso Merino 46 minutes 41 seconds
Sí, es ese proyecto lo traigo yo. Por eso Sarahí no sabía, pero claro, hemos salvado con Héctor y con todos y ya estábamos a puntito porque se le hizo caro. O sea, me dijo, ay, está muy caro.

Mario Adrián Flores Castro
46 minutes 46 seconds46:46
Mario Adrián Flores Castro 46 minutes 46 seconds
Sí, Héctor.
Mario Adrián Flores Castro 46 minutes 51 seconds
No, pero es pero si les encanta gastar en Harvard y MIT y este no, y obviamente allá no está barato, ¿verdad?

Edgar Arturo Barroso Merino
46 minutes 55 seconds46:55
Edgar Arturo Barroso Merino 46 minutes 55 seconds
Exacto, sí, y no está caro, no está caro, de verdad no está caro.
Edgar Arturo Barroso Merino 47 minutes 2 seconds
Exacto. y.
Edgar Arturo Barroso Merino 47 minutes 6 seconds
Pero sí, incluso Sarahí misma me dijo, oye, pues es Monterrey, hay mucho mercado y no sé qué y no sé cuánto. Entonces, pues sí, también sabes quién me habló María, no sé si estoy, no debería estar en la llamada, queridos, pero.

Mario Adrián Flores Castro
47 minutes 18 seconds47:18
Mario Adrián Flores Castro 47 minutes 18 seconds
Yeah.
M
(MTY//CMTY//Rectoria//4 Empatia e Inclusion (Proy.,Pint.,Cap.4))
47 minutes 19 seconds47:19
47 minutes 19 seconds
Gracias.

Edgar Arturo Barroso Merino
47 minutes 21 seconds47:21
Edgar Arturo Barroso Merino 47 minutes 21 seconds
Sí, deja de quedar para que rapidísimo, ella se que se acabó en estos minutos, pero este.
M
(MTY//CMTY//Rectoria//4 Empatia e Inclusion (Proy.,Pint.,Cap.4))
47 minutes 27 seconds47:27
47 minutes 27 seconds
Me voy a Terra.

Edgar Arturo Barroso Merino
47 minutes 29 seconds47:29
Edgar Arturo Barroso Merino 47 minutes 29 seconds
Thank you, thank you.

## Connections
- [[06-projects-ncm]]
